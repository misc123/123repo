﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT News
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTnews'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Entry point
def run():
    plugintools.log("YTnews.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTnews.main_list "+repr(params))


    plugintools.add_item( 
        #action="", 
        title="每日谈Lei Talk",
        url="plugin://plugin.video.youtube/channel/UCD_gy8DWV_DhjJ-bQXF5dGQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzP1GROhwHnIioy4TVg0Xvbbqu7kfLKXQJpGA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="冼師傅講場",
        url="plugin://plugin.video.youtube/channel/UCFRBCHEqZNJ2Rb1IjrCC8Zw/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_Qg35rIi0wFPrOGCObxPdm5k2y8qSAX6a4Og=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="环球新视野",
        url="plugin://plugin.video.youtube/channel/UC6aT6m2WuXUfzoahv1hDIaw/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJz0ihZHbWZdPNZBcM7bc9HUIO6K_XrvyQcLGA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
                 
    plugintools.add_item( 
        #action="", 
        title="点亮历史",
        url="plugin://plugin.video.youtube/channel/UCvYes_0afVM6GeTTFzELW4Q/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJx3GN3TninemlBAP2e46jL11ZqBMfHMk-aimYca=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )
                   
    plugintools.add_item( 
        #action="", 
        title="直播港澳台",
        url="plugin://plugin.video.youtube/channel/UC-UFD2pRujktkSyAD999mFg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngpu2fFPt98ST7y5VteaNW7jqfM40n6lyQgnLn6=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
            
    plugintools.add_item( 
        #action="", 
        title="全球大視野",
        url="plugin://plugin.video.youtube/channel/UCiwt1aanVMoPYUt_CQYCPQg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnj2DjFWmKz2gqvNpgy5ElO_Zd25NGbbapBy-0mEFw=s176-c-k-c0x00ffffff-no-rj-mo",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="军政速递",
        url="plugin://plugin.video.youtube/channel/UCdyh01hxhKg6uTurnLdickQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngx1r4JjslB2Q8aVBbn1pVCFyK6hu1vb7zlIDX1=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="杨风時評",
        url="plugin://plugin.video.youtube/channel/UCE05tYKEsEk7Qmhwg5pqcKw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngr3CJnciQrh3Hw2p_QM68a6Qpdli_yzt_MPNCj=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="德国知事",
        url="plugin://plugin.video.youtube/channel/UCdXqCN_HtF_RjlsHzDSnJIQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngI4Tqs-riZXHMT_gyiwolO9ogPdbXSsGdqaRCqoQ=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="国际时评",
        url="plugin://plugin.video.youtube/channel/UC8HvBg9Rw-cUz0tqKdkKkNg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnguzTBHPbmCvhN3yhwdkFZ-Z_Fy5Hsb-GsB2vnG=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
               
    plugintools.add_item( 
        #action="", 
        title="環球諜報",
        url="plugin://plugin.video.youtube/channel/UCDNXgJEIJx8IiUo2-X6Amdw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwniDyBqarPSVANm6-SNpNrIUoq14G8MRAIxRvgff0Q=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="诚阅 ChengYue",
        url="plugin://plugin.video.youtube/channel/UCd6umYVQpBZ9CIyCwe8Kg7w/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJxgeqxuisbDAlXj9v7wI6b_1z-pYW8wHRYjAylu=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="快看资讯",
        url="plugin://plugin.video.youtube/channel/UCgkHTZsCdH8P9z7lazTXN3g/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzB-L487V6_1Q5-qx5hw2xrsMsZVqF0BLE9fg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Guan Video观视频工作室",
        url="plugin://plugin.video.youtube/channel/UCYfJG6cGfW84FVLuy7semEg/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwKOxGSxCKBl_sKK7LdP7J_7ReLWlkjf_1Pyb4Hgg=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GuanchaNews观察者网",
        url="plugin://plugin.video.youtube/channel/UCJncdiH3BQUBgCroBmhsUhQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwvzvyNXchJysT6OZQ-KEnsxUjZRtjjs0gPZaZixw=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="點新聞",
        url="plugin://plugin.video.youtube/channel/UCcrnNcl12onXCeS_3Bi0a2Q/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l79aat4yF9qy5E0uqRiFt4d4t40Q4VZknha4IA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="新聞龍捲風",
        url="plugin://plugin.video.youtube/channel/UCMetIbaFeT7AzX1K_YOGEjA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyyauxR_0Vz_1Lp2ZmgWfou9ve-VOqrkaZU0A=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="新潮民",
        url="plugin://plugin.video.youtube/channel/UCzV8ytvWEGtMWk0wt9zA1Ng/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnjxUU5eZLp-MAoU7hJDFSlJMmRT2O5KrSc1XO38cw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="陳穎欣Joephy Chan",
        url="plugin://plugin.video.youtube/channel/UCvlBe-TQfjLFINSSYQt9Tjg/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyelSSdVCQhptmAxwrUMmVMVSO13zueU_mOnQ=s144-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="大樹與木頭 ‧Y2K Channel",
        url="plugin://plugin.video.youtube/channel/UCFfLWSnUCblI4Lpsph7H1lA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJymkSjncCTZJiz3q8Vpss4LVzKnfX5KctTyPmteRA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="有聲專欄",
        url="plugin://plugin.video.youtube/playlist/PL50ryNxlMBN5kwOJ_DvTeNXhBrQRbm9N6/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyGzUS1KUF4yZ1VnwWZI8UxEU-4KJhHLr1Lf_dwfA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寒國人",
        url="plugin://plugin.video.youtube/channel/UCXkOTZJ743JgVhJWmNV8F3Q/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJx5ztsRguSX2MSTYREOEg-YnKrXYt9_r8hI6g=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="火鍋大王Nathan Rich",
        url="plugin://plugin.video.youtube/channel/UCaSlyjhR4WC7QhYuaivxb6g/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l78ngY4lsF1M-z5fRTQxaHGjsHEOJ5Ly2gpjyQ=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="總編輯時間-梁建鋒",
        url="plugin://plugin.video.youtube/search/?q=總編輯時間/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
        
run()