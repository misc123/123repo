﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT News
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTnews'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Entry point
def run():
    plugintools.log("YTnews.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTnews.main_list "+repr(params))

                
    plugintools.add_item( 
        #action="", 
        title="杨风時評",
        url="plugin://plugin.video.youtube/channel/UCE05tYKEsEk7Qmhwg5pqcKw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngr3CJnciQrh3Hw2p_QM68a6Qpdli_yzt_MPNCj=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Bastille Post巴士的報",
        url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnhub9qdg-gC-HVcqH6zhr9kCNf31qsocRmBoDEYqA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="東網點評",
        url="plugin://plugin.video.youtube/playlist/PLKF-pTEnmquyxOTnG1gqPo2AmsBEjFjOI/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwniNC13K7MkFYxvSslIs1iPz9oBLje83s1LWGd4Tlw=s88-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="冼師傅講場",
        url="plugin://plugin.video.youtube/channel/UCFRBCHEqZNJ2Rb1IjrCC8Zw/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_Qg35rIi0wFPrOGCObxPdm5k2y8qSAX6a4Og=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="總編輯時間-梁建鋒",
        url="plugin://plugin.video.youtube/search/?q=總編輯時間/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="《看中國》香港頻道 ",
        url="plugin://plugin.video.youtube/channel/UCGAbl3E1aqqgrjwIaiDDdqQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLQ_j9KMO4pGmN8hx8T3ew6vqlDxhG6dnHcpjlNy=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                 
    plugintools.add_item( 
        #action="", 
        title="环球新视野",
        url="plugin://plugin.video.youtube/channel/UC6aT6m2WuXUfzoahv1hDIaw/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJz0ihZHbWZdPNZBcM7bc9HUIO6K_XrvyQcLGA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
                 
    plugintools.add_item( 
        #action="", 
        title="点亮历史",
        url="plugin://plugin.video.youtube/channel/UCvYes_0afVM6GeTTFzELW4Q/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJx3GN3TninemlBAP2e46jL11ZqBMfHMk-aimYca=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="屈機TV",
        url="plugin://plugin.video.youtube/channel/UCN0eCImZY6_OiJbo8cy5bLw/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSgEAGosPXetUZ8L_3eSFfYeTRWV159HSdrqWb7=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Yan Talk 岩论",
        url="plugin://plugin.video.youtube/channel/UCwNGgFvBpxtU8JagZLzztzQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwniH6JQh4uZHOSRAUUV1mAvfjim1Tpr8buqblYEu=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="磊哥聊政经",
        url="plugin://plugin.video.youtube/channel/UCD_gy8DWV_DhjJ-bQXF5dGQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzP1GROhwHnIioy4TVg0Xvbbqu7kfLKXQJpGA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="磊哥聊政经 B站",
        url="plugin://plugin.video.bilibili/up/303981427/1/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzP1GROhwHnIioy4TVg0Xvbbqu7kfLKXQJpGA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寒锋时评",
        url="plugin://plugin.video.youtube/channel/UCNIRnNn6FZ-jWYFjwBhni7A/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTbUC60yxqFJqx2INF4uF1FHexAyZW1Gn_0bD5P=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寰球一线",
        url="plugin://plugin.video.youtube/channel/UC4XQX3UwoCSvNQR0Tq1bGaQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngxHYTx442U1ieiKKfsv1x9LJD9FUFK_zSgk0iM=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                 
    plugintools.add_item( 
        #action="", 
        title="龙之声",
        url="plugin://plugin.video.youtube/channel/UCjpF47XO6JfF9QVmXoRociQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLS2svK55tNextjFxjqpcTSXg7IlpZ3vzOFOu9aq=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="卢克文",
        url="plugin://plugin.video.youtube/channel/UClTVEzPs4aNRXl3xDfMKqaA/",
        thumbnail="https://i2.hdslb.com/bfs/face/c0a1b1f382c68da453f5a273ce069ee46e685364.jpg@225w_225h_1c.webp",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="卢克文工作室 B站",
        url="plugin://plugin.video.bilibili/up/438173577/1/",
        thumbnail="https://i2.hdslb.com/bfs/face/c0a1b1f382c68da453f5a273ce069ee46e685364.jpg@225w_225h_1c.webp",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="新闻247",
        url="plugin://plugin.video.youtube/channel/UCFxClsQDoYv5EqpTWK81_Mw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwniZmeQIzvJPcJrbzHz6E5JZAu7vDRqfl6kTeRWOag=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="最新消息 247",
        url="plugin://plugin.video.youtube/user/sierraevolet/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnjwUfpCAe8E_DkX6A9AQ7qfKbpl5Mh_AJ9LYk-F=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="资讯快线 Hong News",
        url="plugin://plugin.video.youtube/channel/UCoK8i6TNovuOYouvDK97VcQ/",
        thumbnail="https://yt3.ggpht.com/kCycf7KK26Wo1JSCBBO_6IYMY96JyHnGzpMGRFp8qMa3LYNmu7vuSpJb4GQIVQGZXUAT58ty=s176-c-k-c0x00ffffff-no-rj",		
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="理科男士K一米",
        url="plugin://plugin.video.youtube/channel/UCJMEiNh1HvpopPU3n9vJsMQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwni7PXoQGwopk24A5hP9I1Ad7zIVLTZFoOKq0ho9tQ=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="环球观察",
        url="plugin://plugin.video.youtube/channel/UC6iTaivn7fHD8rmPQKcUdQg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnh6ERfeIPeRq8k26myDBqW-n-LGduOBIVELrQgB=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="胡锡进Global Times",
        url="plugin://plugin.video.youtube/channel/UCVD-MGxD71IQUk9_hHq8MdA/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnh07drypjn7U6BZ-3_vW4FTbAZXrU8Q195P0sVO=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="张维为The Chinese Way by Zhang Weiwei",
        url="plugin://plugin.video.youtube/channel/UCtDd5tl977dQrDiNoLhQHkw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnhrumSsFj9FCJH8Pauw52lI5vmURKfLNzWotWOj=s176-c-k-c0x00ffffff-no-rj",		
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="印度三哥MANU马怒",
        url="plugin://plugin.video.youtube/channel/UC9rRTrTFBo-ntv7Cx10D2QA/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwng3LEsnMLW2NJo-fntq-NNLYihved5LdGd9rvs3=s176-c-k-c0x00ffffff-no-rj",		
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="诚阅 ChengYue",
        url="plugin://plugin.video.youtube/channel/UCd6umYVQpBZ9CIyCwe8Kg7w/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJxgeqxuisbDAlXj9v7wI6b_1z-pYW8wHRYjAylu=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                   
    plugintools.add_item( 
        #action="", 
        title="直播港澳台",
        url="plugin://plugin.video.youtube/channel/UC-UFD2pRujktkSyAD999mFg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngpu2fFPt98ST7y5VteaNW7jqfM40n6lyQgnLn6=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
            
    plugintools.add_item( 
        #action="", 
        title="全球大視野",
        url="plugin://plugin.video.youtube/channel/UCiwt1aanVMoPYUt_CQYCPQg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnj2DjFWmKz2gqvNpgy5ElO_Zd25NGbbapBy-0mEFw=s176-c-k-c0x00ffffff-no-rj-mo",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="军政速递",
        url="plugin://plugin.video.youtube/channel/UCdyh01hxhKg6uTurnLdickQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngx1r4JjslB2Q8aVBbn1pVCFyK6hu1vb7zlIDX1=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="德国知事",
        url="plugin://plugin.video.youtube/channel/UCdXqCN_HtF_RjlsHzDSnJIQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngI4Tqs-riZXHMT_gyiwolO9ogPdbXSsGdqaRCqoQ=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="国际时评",
        url="plugin://plugin.video.youtube/channel/UC8HvBg9Rw-cUz0tqKdkKkNg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnguzTBHPbmCvhN3yhwdkFZ-Z_Fy5Hsb-GsB2vnG=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
               
    plugintools.add_item( 
        #action="", 
        title="環球諜報",
        url="plugin://plugin.video.youtube/channel/UCDNXgJEIJx8IiUo2-X6Amdw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwniDyBqarPSVANm6-SNpNrIUoq14G8MRAIxRvgff0Q=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="快看资讯",
        url="plugin://plugin.video.youtube/channel/UCgkHTZsCdH8P9z7lazTXN3g/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzB-L487V6_1Q5-qx5hw2xrsMsZVqF0BLE9fg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Guan Video观视频工作室",
        url="plugin://plugin.video.youtube/channel/UCYfJG6cGfW84FVLuy7semEg/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwKOxGSxCKBl_sKK7LdP7J_7ReLWlkjf_1Pyb4Hgg=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GuanchaNews观察者网",
        url="plugin://plugin.video.youtube/channel/UCJncdiH3BQUBgCroBmhsUhQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwvzvyNXchJysT6OZQ-KEnsxUjZRtjjs0gPZaZixw=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="點新聞",
        url="plugin://plugin.video.youtube/channel/UCcrnNcl12onXCeS_3Bi0a2Q/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l79aat4yF9qy5E0uqRiFt4d4t40Q4VZknha4IA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="新聞龍捲風",
        url="plugin://plugin.video.youtube/channel/UCMetIbaFeT7AzX1K_YOGEjA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyyauxR_0Vz_1Lp2ZmgWfou9ve-VOqrkaZU0A=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="新潮民",
        url="plugin://plugin.video.youtube/channel/UCzV8ytvWEGtMWk0wt9zA1Ng/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnjxUU5eZLp-MAoU7hJDFSlJMmRT2O5KrSc1XO38cw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="KOLHK 時事梓引",
        url="plugin://plugin.video.youtube/channel/UCG6WtLOTXySl1terUhQYWCA/",
        thumbnail="https://yt3.ggpht.com/NDTvGFU50VALAyt8F6jbhS73gSkpgIGRcWMa6umMEgdCSVj7Dwug7552xLCTi6giI6L0ZMpEi5w=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="陳穎欣Joephy Chan",
        url="plugin://plugin.video.youtube/channel/UCvlBe-TQfjLFINSSYQt9Tjg/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyelSSdVCQhptmAxwrUMmVMVSO13zueU_mOnQ=s144-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="大樹與木頭 ‧Y2K Channel",
        url="plugin://plugin.video.youtube/channel/UCFfLWSnUCblI4Lpsph7H1lA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJymkSjncCTZJiz3q8Vpss4LVzKnfX5KctTyPmteRA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="娜娜琳",
        url="plugin://plugin.video.youtube/channel/UCn0Lyn2rx4ZJcHgD-jgNhiw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnjwbRazIvLSThIvvt1Z4auaoaNzlsAafuzot2HN=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="空姐牛肉飯Annie",
        url="plugin://plugin.video.youtube/channel/UCpytXTSrsqbCjmqb6MfMrmw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnjE3Ycu_cj3RRlhLzJc0BkKkthOvAYUeV9HIkhXBg=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Chong San 沖先生",
        url="plugin://plugin.video.youtube/channel/UCsGqE-IVUCwyyi_WRsvVLJg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngM7DJO1yuLEI0KvbMpR6CBSBIys6sI9aD4V-AN=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="有聲專欄",
        url="plugin://plugin.video.youtube/playlist/PL50ryNxlMBN5kwOJ_DvTeNXhBrQRbm9N6/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyGzUS1KUF4yZ1VnwWZI8UxEU-4KJhHLr1Lf_dwfA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寒國人",
        url="plugin://plugin.video.youtube/channel/UCXkOTZJ743JgVhJWmNV8F3Q/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJx5ztsRguSX2MSTYREOEg-YnKrXYt9_r8hI6g=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="火鍋大王Nathan Rich",
        url="plugin://plugin.video.youtube/channel/UCaSlyjhR4WC7QhYuaivxb6g/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l78ngY4lsF1M-z5fRTQxaHGjsHEOJ5Ly2gpjyQ=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="和之梦",
        url="plugin://plugin.video.youtube/channel/UCwHUYtwH5E41O6MiYoC19ng/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSgBajZNqy03PTZe0WjiBSVH_zln38X3yAkTHyMHg=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                 
    plugintools.add_item( 
        #action="", 
        title="维纳狮",
        url="plugin://plugin.video.youtube/channel/UCquxEaSv6TOAUiPVOwEgsIg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngBohgJVOVoIJBzjwQX8iFs704vw_IrqCz5E6yx=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                  
    plugintools.add_item( 
        #action="", 
        title="美國加息 剪中國羊毛",
        url="plugin://plugin.video.youtube/play/?video_id=T6cVPxET77I",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="美国如何印钞收割全球",
        url="plugin://plugin.video.youtube/play/?video_id=Fni8y0TJWOg",
        thumbnail="",
        folder=False )
                   
    plugintools.add_item( 
        #action="", 
        title="美国如何控制全球的糧食",
        url="plugin://plugin.video.youtube/play/?video_id=xf5GnGpDVFc",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="美國房地產次貸危機",
        url="plugin://plugin.video.youtube/play/?video_id=Hjtnxq7qZ7M",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="美國長臂管轄",
        url="plugin://plugin.video.youtube/play/?video_id=bc26Tt5B9Ik",
        thumbnail="",
        folder=False )
	
    plugintools.add_item( 
        #action="", 
        title="南海那场世纪对峙",
        url="plugin://plugin.video.youtube/play/?video_id=WXJ6LC4mvHM",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國佔領一個國家的12個步驟",
        url="plugin://plugin.video.youtube/play/?video_id=qyqKDomSeUk",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國掠奪一個地方的四部曲",
        url="plugin://plugin.video.youtube/play/?video_id=zffGd8RQhTA",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國謀害中國陷入圈套的十個步驟1",
        url="plugin://plugin.video.youtube/play/?video_id=ddlyL6gqffM",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國謀害中國陷入圈套的十個步驟2",
        url="plugin://plugin.video.youtube/play/?video_id=6X4DHDuILIo",
        thumbnail="",
        folder=False )	

    plugintools.add_item( 
        #action="", 
        title="美國謀害中國陷入圈套的十個步驟3",
        url="plugin://plugin.video.youtube/play/?video_id=lxdQPMcxz78",
        thumbnail="",
        folder=False )	

    plugintools.add_item( 
        #action="", 
        title="孟晚舟案",
        url="plugin://plugin.video.youtube/play/?video_id=NOkZeEC5li8",
        thumbnail="",
        folder=False )	

    plugintools.add_item( 
        #action="", 
        title="孟晚舟案全部真相",
        url="plugin://plugin.video.youtube/play/?video_id=6_dhlL5z9kw",
        thumbnail="",
        folder=False )	
       
run()