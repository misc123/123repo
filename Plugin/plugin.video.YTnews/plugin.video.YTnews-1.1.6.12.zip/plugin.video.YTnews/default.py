﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT News
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTnews'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Entry point
def run():
    plugintools.log("YTnews.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTnews.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="有線新聞",
        url="plugin://plugin.video.youtube/channel/UCIV1z0CuMTrLkGQyMJ2y_Lg/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mAKvVh44H5L1wSbE65hqBvcp958Bej1O7HOFA=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="Now 財經 新聞",
        url="plugin://plugin.video.youtube/channel/UCChMBgirwM2nnT3Bbe8METQ/playlists/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mCbXlUdLACVHK8TKu8H6Rqmi1OpHIfW-Y6dIg=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="總編輯時間-梁建鋒",
        url="plugin://plugin.video.youtube/search/?q=總編輯時間/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="冼師傅講場",
        url="plugin://plugin.video.youtube/channel/UCFRBCHEqZNJ2Rb1IjrCC8Zw/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_Qg35rIi0wFPrOGCObxPdm5k2y8qSAX6a4Og=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="今日大新聞",
        url="plugin://plugin.video.youtube/channel/UCOX2lH5Rzf844ykYz5OCV0Q/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7-mnzxbrkSBKcWCgViKhUQiu0mmy1dqfJtvAA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="环球新视野",
        url="plugin://plugin.video.youtube/channel/UC6aT6m2WuXUfzoahv1hDIaw/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJz0ihZHbWZdPNZBcM7bc9HUIO6K_XrvyQcLGA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="新聞龍捲風",
        url="plugin://plugin.video.youtube/channel/UCMetIbaFeT7AzX1K_YOGEjA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyyauxR_0Vz_1Lp2ZmgWfou9ve-VOqrkaZU0A=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="關鍵時刻",
        url="plugin://plugin.video.youtube/channel/UCKQVSNdzGBJSXaUmS4TOWww/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJw9LJc02NG3Ustgw8ZxD5IgXdzKFVP_-D3oNA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="東網電視",
        url="plugin://plugin.video.youtube/channel/UC4NjmIegGw-HyQCmxwAEZBQ/",
        thumbnail="https://yt3.ggpht.com/-RaYcmdVASWQ/AAAAAAAAAAI/AAAAAAAAAAA/fSo0Yjk_GuQ/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="巴士的報",
        url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/",
        thumbnail="http://vignette2.wikia.nocookie.net/evchk/images/c/c8/1518122_130516053785319_320316523_n.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="八八通",
        url="plugin://plugin.video.youtube/channel/UCeFbWIhDj_tjTOTe1P3cVHA/",
        thumbnail="https://yt3.ggpht.com/-16m06v5p7I0/AAAAAAAAAAI/AAAAAAAAAAA/GYFZFRdrU88/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="東Touch",
        url="plugin://plugin.video.youtube/user/EastTOUCHhk/",
        thumbnail="https://yt3.ggpht.com/-2UPyDul4IZk/AAAAAAAAAAI/AAAAAAAAAAA/9sZwPI1aLm8/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="東周網",
        url="plugin://plugin.video.youtube/channel/UCsTeCS6s9YoNn2kbQVAgDsQ/",
        thumbnail="https://yt3.ggpht.com/-Ak12dd6RJWY/AAAAAAAAAAI/AAAAAAAAAAA/Ks4e7PCESzs/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="頭條日報",
        url="plugin://plugin.video.youtube/user/hkheadlinenews/",
        thumbnail="https://yt3.ggpht.com/-Ycjhca-2-8w/AAAAAAAAAAI/AAAAAAAAAAA/f19V5Nz5_x0/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="娱乐新闻百晓生",
        url="plugin://plugin.video.youtube/channel/UCeRqTsOPtOgUKhL7GGuBwTA/",
        thumbnail="https://yt3.ggpht.com/-u0CIkVrNx3Q/AAAAAAAAAAI/AAAAAAAAAAA/D-71GN16Wd8/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="亞洲電視",
        url="plugin://plugin.video.youtube/channel/UCxbLNKdc7VOupXM9SePn1iA/",
        thumbnail="https://yt3.ggpht.com/-AerHOuBOMXQ/AAAAAAAAAAI/AAAAAAAAAAA/6AbD5dZ1K7c/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="娛樂香港新聞透視",
        url="plugin://plugin.video.youtube/channel/UCLtcC8s-2JJ_5iUxcAO462Q/",
        thumbnail="https://yt3.ggpht.com/-SspnPA0LxMY/AAAAAAAAAAI/AAAAAAAAAAA/dhuxokvTOL4/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="今日大新聞",
        url="plugin://plugin.video.youtube/channel/UCOX2lH5Rzf844ykYz5OCV0Q/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7-mnzxbrkSBKcWCgViKhUQiu0mmy1dqfJtvAA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="时事点评",
        url="plugin://plugin.video.youtube/channel/UCOX2lH5Rzf844ykYz5OCV0Q/playlist/PLFoNeMnGXYgpDil-w78bDVPGUBEQeKcMp/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJx9ONyB8utzrscWCVegFjsrmR5oZ057IbFHfQ=s288-c-k-c0xffffffff-no-rj-mo",        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="火鍋大王Nathan Rich",
        url="plugin://plugin.video.youtube/channel/UCaSlyjhR4WC7QhYuaivxb6g/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l78ngY4lsF1M-z5fRTQxaHGjsHEOJ5Ly2gpjyQ=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="點新聞",
        url="plugin://plugin.video.youtube/channel/UCcrnNcl12onXCeS_3Bi0a2Q/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l79aat4yF9qy5E0uqRiFt4d4t40Q4VZknha4IA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
						
    plugintools.add_item( 
        #action="", 
        title="香港本土力量",
        url="plugin://plugin.video.youtube/channel/UC2UcOi6RPQG5J3DovCre1JA/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l785AAlJFlKLFxJTE-Wj9PiE3g8MEbl8_ipQbA=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Albert Ip",
        url="plugin://plugin.video.youtube/user/albertip/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7-RzkVkG32M_qHcOqtMBTIHOWSCIaqzcufWUw=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Simon",
        url="plugin://plugin.video.youtube/channel/UCuNY7uTtTLTCS34YZHdefjA/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_Fsvg_i4KV0nUn4eIKhRPSc47awNp0OTe_DQ=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="華記正能量",
        url="plugin://plugin.video.youtube/channel/UCjQiROcVtb0ZqPpA-xE2flA/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l79gvW2rUc-WXKEJgCxY693MT_xbioH1XBYVpQ=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="美國佔領一個國家的12個步驟",
        url="plugin://plugin.video.youtube/play/?video_id=qyqKDomSeUk",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國掠奪一個地方的四部曲",
        url="plugin://plugin.video.youtube/play/?video_id=zffGd8RQhTA",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國謀害中國陷入圈套的十個步驟1",
        url="plugin://plugin.video.youtube/play/?video_id=b3bBB2OeOvI",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國謀害中國陷入圈套的十個步驟2",
        url="plugin://plugin.video.youtube/play/?video_id=KnnR_21Pbzc",
        thumbnail="",
        folder=False )	

    plugintools.add_item( 
        #action="", 
        title="明報新聞(多倫多,加國及其他)",
        url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/playlists/",
        thumbnail="https://yt3.ggpht.com/-b-yT1RhZyc4/AAAAAAAAAAI/AAAAAAAAAAA/GQUASiScP9w/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="多倫多 WOWtv",
        url="plugin://plugin.video.youtube/channel/UC5kySUzP0p4Q4Y1rnQLX_bw/",
        thumbnail="https://yt3.ggpht.com/-gYZVZ2dGwUk/AAAAAAAAAAI/AAAAAAAAAAA/5rJVdrjlPSE/s176-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
					
    plugintools.add_item( 
        #action="", 
        title="恩雨之聲",
        url="plugin://plugin.video.youtube/channel/UCgwOhn9ghL2jY5qJEzpzSzw/",
        thumbnail="https://yt3.ggpht.com/-g4j3jPE-tcg/AAAAAAAAAAI/AAAAAAAAAAA/-qthveptCm8/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
run()