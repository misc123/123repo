﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT News
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTnews'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Entry point
def run():
    plugintools.log("YTnews.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTnews.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="TVB NEWS 無綫新聞",
        url="plugin://plugin.video.youtube/playlist/PLKoXXVQa3yxCbgfZiuq61w9UhEI085PHu/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyid1soOElgq9HnTXEL6OZ074mWD1QR9W-niwhD=s88-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="i-Cable News 有線新聞",
        url="plugin://plugin.video.youtube/playlist/PLIpRvnEkgEeVUPzeLS6JraRwmD3YcWkMz/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJxrVgKwGe9J-8K-rkrIrX9TL9QRRBGBBysxuSXt=s88-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="TVB (official)",
        url="plugin://plugin.video.youtube/channel/UCD2SNRlEjxJODlwaKx-BoRw/playlists/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyrcChFpzJm3kpa_inzd0JZARIi_MLD-iiOcQ=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="東網點評",
        url="plugin://plugin.video.youtube/playlist/PLKF-pTEnmquyxOTnG1gqPo2AmsBEjFjOI/",
        thumbnail="https://yt3.ggpht.com/-RaYcmdVASWQ/AAAAAAAAAAI/AAAAAAAAAAA/fSo0Yjk_GuQ/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="巴士的報",
        url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/",
        thumbnail="http://vignette2.wikia.nocookie.net/evchk/images/c/c8/1518122_130516053785319_320316523_n.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="八八通",
        url="plugin://plugin.video.youtube/channel/UCeFbWIhDj_tjTOTe1P3cVHA/",
        thumbnail="https://yt3.ggpht.com/-16m06v5p7I0/AAAAAAAAAAI/AAAAAAAAAAA/GYFZFRdrU88/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="東Touch",
        url="plugin://plugin.video.youtube/user/EastTOUCHhk/",
        thumbnail="https://yt3.ggpht.com/-2UPyDul4IZk/AAAAAAAAAAI/AAAAAAAAAAA/9sZwPI1aLm8/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="東周網",
        url="plugin://plugin.video.youtube/channel/UCsTeCS6s9YoNn2kbQVAgDsQ/",
        thumbnail="https://yt3.ggpht.com/-Ak12dd6RJWY/AAAAAAAAAAI/AAAAAAAAAAA/Ks4e7PCESzs/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="頭條日報",
        url="plugin://plugin.video.youtube/user/hkheadlinenews/",
        thumbnail="https://yt3.ggpht.com/-Ycjhca-2-8w/AAAAAAAAAAI/AAAAAAAAAAA/f19V5Nz5_x0/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Now 財經 新聞",
        url="plugin://plugin.video.youtube/channel/UCChMBgirwM2nnT3Bbe8METQ/playlists/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mCbXlUdLACVHK8TKu8H6Rqmi1OpHIfW-Y6dIg=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )			
		
    plugintools.add_item( 
        #action="", 
        title="娛樂香港新聞透視",
        url="plugin://plugin.video.youtube/channel/UCLtcC8s-2JJ_5iUxcAO462Q/",
        thumbnail="https://yt3.ggpht.com/-SspnPA0LxMY/AAAAAAAAAAI/AAAAAAAAAAA/dhuxokvTOL4/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )								

    plugintools.add_item( 
        #action="", 
        title="明報新聞(多倫多,加國及其他)",
        url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/playlists/",
        thumbnail="https://yt3.ggpht.com/-b-yT1RhZyc4/AAAAAAAAAAI/AAAAAAAAAAA/GQUASiScP9w/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="多倫多 WOWtv",
        url="plugin://plugin.video.youtube/channel/UC5kySUzP0p4Q4Y1rnQLX_bw/",
        thumbnail="https://yt3.ggpht.com/-gYZVZ2dGwUk/AAAAAAAAAAI/AAAAAAAAAAA/5rJVdrjlPSE/s176-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
					
    plugintools.add_item( 
        #action="", 
        title="恩雨之聲",
        url="plugin://plugin.video.youtube/channel/UCgwOhn9ghL2jY5qJEzpzSzw/",
        thumbnail="https://yt3.ggpht.com/-g4j3jPE-tcg/AAAAAAAAAAI/AAAAAAAAAAA/-qthveptCm8/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Lorey Chan 好書推介",
        url="plugin://plugin.video.youtube/playlist/PLFkHgNWcmIh6kwEP_rPXfcFKAh__L4cmt/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwrTyLnojcRwlZ9s1FS2uUnetCsmzczQNb2a59qLA=s88-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Mr & Mrs Gao",
        url="plugin://plugin.video.youtube/channel/UCMUnInmOkrWN4gof9KlhNmQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJw-9mrcVRGrOcO8eMBKxp6hwRYd1vJSqDKG4smsNw=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="环球新视野",
        url="plugin://plugin.video.youtube/channel/UC6aT6m2WuXUfzoahv1hDIaw/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJz0ihZHbWZdPNZBcM7bc9HUIO6K_XrvyQcLGA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="快看资讯",
        url="plugin://plugin.video.youtube/channel/UCgkHTZsCdH8P9z7lazTXN3g/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzB-L487V6_1Q5-qx5hw2xrsMsZVqF0BLE9fg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="点亮历史",
        url="plugin://plugin.video.youtube/channel/UCvYes_0afVM6GeTTFzELW4Q/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJx3GN3TninemlBAP2e46jL11ZqBMfHMk-aimYca=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Guan Video观视频工作室",
        url="plugin://plugin.video.youtube/channel/UCYfJG6cGfW84FVLuy7semEg/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwKOxGSxCKBl_sKK7LdP7J_7ReLWlkjf_1Pyb4Hgg=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GuanchaNews观察者网",
        url="plugin://plugin.video.youtube/channel/UCJncdiH3BQUBgCroBmhsUhQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwvzvyNXchJysT6OZQ-KEnsxUjZRtjjs0gPZaZixw=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="總編輯時間-梁建鋒",
        url="plugin://plugin.video.youtube/search/?q=總編輯時間/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="冼師傅講場",
        url="plugin://plugin.video.youtube/channel/UCFRBCHEqZNJ2Rb1IjrCC8Zw/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_Qg35rIi0wFPrOGCObxPdm5k2y8qSAX6a4Og=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="每日谈Lei Talk",
        url="plugin://plugin.video.youtube/channel/UCD_gy8DWV_DhjJ-bQXF5dGQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzP1GROhwHnIioy4TVg0Xvbbqu7kfLKXQJpGA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="點新聞",
        url="plugin://plugin.video.youtube/channel/UCcrnNcl12onXCeS_3Bi0a2Q/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l79aat4yF9qy5E0uqRiFt4d4t40Q4VZknha4IA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="有聲專欄",
        url="plugin://plugin.video.youtube/playlist/PL50ryNxlMBN5kwOJ_DvTeNXhBrQRbm9N6/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyGzUS1KUF4yZ1VnwWZI8UxEU-4KJhHLr1Lf_dwfA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="新聞龍捲風",
        url="plugin://plugin.video.youtube/channel/UCMetIbaFeT7AzX1K_YOGEjA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyyauxR_0Vz_1Lp2ZmgWfou9ve-VOqrkaZU0A=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="今日大新聞",
        url="plugin://plugin.video.youtube/channel/UCOX2lH5Rzf844ykYz5OCV0Q/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7-mnzxbrkSBKcWCgViKhUQiu0mmy1dqfJtvAA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="陳穎欣Joephy Chan",
        url="plugin://plugin.video.youtube/channel/UCvlBe-TQfjLFINSSYQt9Tjg/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyelSSdVCQhptmAxwrUMmVMVSO13zueU_mOnQ=s144-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寒國人",
        url="plugin://plugin.video.youtube/channel/UCXkOTZJ743JgVhJWmNV8F3Q/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJx5ztsRguSX2MSTYREOEg-YnKrXYt9_r8hI6g=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="火鍋大王Nathan Rich",
        url="plugin://plugin.video.youtube/channel/UCaSlyjhR4WC7QhYuaivxb6g/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l78ngY4lsF1M-z5fRTQxaHGjsHEOJ5Ly2gpjyQ=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )
        
run()