# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT News
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTnews'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Entry point
def run():
    plugintools.log("YTnews.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTnews.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="有線新聞",
        url="plugin://plugin.video.youtube/channel/UCKWpmh1v-kNrAjDkwsqqGyg/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mAKvVh44H5L1wSbE65hqBvcp958Bej1O7HOFA=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Now新聞",
        url="plugin://plugin.video.youtube/channel/UCUlpNsT75-kbZhovVAcmz-A/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mCbXlUdLACVHK8TKu8H6Rqmi1OpHIfW-Y6dIg=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="我係香港人",
        url="plugin://plugin.video.youtube/channel/UCTJZLt3Ev-qHd0a8-Gdwllg/",
        thumbnail="https://yt3.ggpht.com/-iLStsV9iOVY/AAAAAAAAAAI/AAAAAAAAAAA/6QCmSCUyg6k/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Kin News Media",
        url="plugin://plugin.video.youtube/channel/UCtH9qa6HNaCrdM9qwFbMLgg/",
        thumbnail="https://yt3.ggpht.com/-WWLAFDeIFFg/AAAAAAAAAAI/AAAAAAAAAAA/tjy80_lHPHw/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="六點半新聞報道NewsHongKong",
        url="plugin://plugin.video.youtube/channel/UCaym5qyBvJtENEaQGayoXpA/",
        thumbnail="https://yt3.ggpht.com/-auTOM-FnSO4/AAAAAAAAAAI/AAAAAAAAAAA/2pYH7JVJYuM/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="Now 財經 新聞",
        url="plugin://plugin.video.youtube/channel/UCChMBgirwM2nnT3Bbe8METQ/playlists/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mCbXlUdLACVHK8TKu8H6Rqmi1OpHIfW-Y6dIg=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="亞洲電視",
        url="plugin://plugin.video.youtube/channel/UCxbLNKdc7VOupXM9SePn1iA/",
        thumbnail="https://yt3.ggpht.com/-AerHOuBOMXQ/AAAAAAAAAAI/AAAAAAAAAAA/6AbD5dZ1K7c/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="蘋果動新聞",
        url="plugin://plugin.video.youtube/channel/UCeqUUXaM75wrK5Aalo6UorQ/",
        thumbnail="https://yt3.ggpht.com/-UnzSE4d_M1s/AAAAAAAAAAI/AAAAAAAAAAA/NeWTKNbP3TY/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="東網電視",
        url="plugin://plugin.video.youtube/channel/UC4NjmIegGw-HyQCmxwAEZBQ/",
        thumbnail="https://yt3.ggpht.com/-RaYcmdVASWQ/AAAAAAAAAAI/AAAAAAAAAAA/fSo0Yjk_GuQ/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="娛樂香港新聞透視",
        url="plugin://plugin.video.youtube/channel/UCLtcC8s-2JJ_5iUxcAO462Q/",
        thumbnail="https://yt3.ggpht.com/-SspnPA0LxMY/AAAAAAAAAAI/AAAAAAAAAAA/dhuxokvTOL4/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="毛記電視",
        url="plugin://plugin.video.youtube/channel/UCiJnCs2K5gP-DXnMxlstC9A/",
        thumbnail="https://yt3.ggpht.com/-Ce_sRsGEIEw/AAAAAAAAAAI/AAAAAAAAAAA/4aJi1NiadJo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="蕭若元：蕭析",
        url="plugin://plugin.video.youtube/search/?q=〈蕭若元：蕭析〉/",
        thumbnail="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSaLz_W0D6UR_z8HS3vRSYAcFAmyKEIw2RBWkWku6p0YAWUKPHB5EOxXtw",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="蕭若元：香港商界十大梟雄",
        url="plugin://plugin.video.youtube/channel/UCJQ-REbY-IfisGatyrWfVNg/playlist/PLLPBrSaE8CCtxOiyLsV7BsQVH3RCnLELB/",
        thumbnail="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSaLz_W0D6UR_z8HS3vRSYAcFAmyKEIw2RBWkWku6p0YAWUKPHB5EOxXtw",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="謎米",
        url="plugin://plugin.video.youtube/user/memehongkong/",
        thumbnail="https://yt3.ggpht.com/-SMIREPl3xKs/AAAAAAAAAAI/AAAAAAAAAAA/ve2f7W5O8fQ/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="巴士的報",
        url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/",
        thumbnail="http://vignette2.wikia.nocookie.net/evchk/images/c/c8/1518122_130516053785319_320316523_n.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="頭條日報",
        url="plugin://plugin.video.youtube/user/hkheadlinenews/",
        thumbnail="https://yt3.ggpht.com/-Ycjhca-2-8w/AAAAAAAAAAI/AAAAAAAAAAA/f19V5Nz5_x0/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item(
        #action="", 
        title="壹週Plus",
        url="plugin://plugin.video.youtube/channel/UC-8CVMKt5Zlju_i07zhkC-Q/",
        thumbnail="https://yt3.ggpht.com/-NfnRCKGfeao/AAAAAAAAAAI/AAAAAAAAAAA/Bp_UFIBmGoA/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="八八通",
        url="plugin://plugin.video.youtube/channel/UCeFbWIhDj_tjTOTe1P3cVHA/",
        thumbnail="https://yt3.ggpht.com/-16m06v5p7I0/AAAAAAAAAAI/AAAAAAAAAAA/GYFZFRdrU88/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="東Touch",
        url="plugin://plugin.video.youtube/user/EastTOUCHhk/",
        thumbnail="https://yt3.ggpht.com/-2UPyDul4IZk/AAAAAAAAAAI/AAAAAAAAAAA/9sZwPI1aLm8/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="東周網",
        url="plugin://plugin.video.youtube/channel/UCsTeCS6s9YoNn2kbQVAgDsQ/",
        thumbnail="https://yt3.ggpht.com/-Ak12dd6RJWY/AAAAAAAAAAI/AAAAAAAAAAA/Ks4e7PCESzs/s240-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="港人港地",
        url="plugin://plugin.video.youtube/channel/UCqUhYNPzxfRwD73W84xMUSQ/",
        thumbnail="https://yt3.ggpht.com/-vD22FUFZmFk/AAAAAAAAAAI/AAAAAAAAAAA/PkM6Qvf_AH0/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="香港娛樂台",
        url="plugin://plugin.video.youtube/channel/UCorJU17I76qrnmURUvA0Xbw/",
        thumbnail="https://yt3.ggpht.com/-1moxDw_BZ28/AAAAAAAAAAI/AAAAAAAAAAA/Nn0ZJiA4mHM/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="娱乐新闻百晓生",
        url="plugin://plugin.video.youtube/channel/UCeRqTsOPtOgUKhL7GGuBwTA/",
        thumbnail="https://yt3.ggpht.com/-u0CIkVrNx3Q/AAAAAAAAAAI/AAAAAAAAAAA/D-71GN16Wd8/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="明報新聞(多倫多,加國及其他)",
        url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/playlists/",
        thumbnail="https://yt3.ggpht.com/-b-yT1RhZyc4/AAAAAAAAAAI/AAAAAAAAAAA/GQUASiScP9w/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="多倫多 WOWtv",
        url="plugin://plugin.video.youtube/channel/UC5kySUzP0p4Q4Y1rnQLX_bw/",
        thumbnail="https://yt3.ggpht.com/-gYZVZ2dGwUk/AAAAAAAAAAI/AAAAAAAAAAA/5rJVdrjlPSE/s176-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="RTHK 香港電台",
        url="plugin://plugin.video.youtube/channel/UC6of7UYhctnYmqABjUqzuxw/playlists/",
        thumbnail="https://yt3.ggpht.com/-56G6ZUapa8E/AAAAAAAAAAI/AAAAAAAAAAA/vU473yawuv8/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
					
    plugintools.add_item( 
        #action="", 
        title="恩雨之聲",
        url="plugin://plugin.video.youtube/channel/UCgwOhn9ghL2jY5qJEzpzSzw/",
        thumbnail="https://yt3.ggpht.com/-g4j3jPE-tcg/AAAAAAAAAAI/AAAAAAAAAAA/-qthveptCm8/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
run()