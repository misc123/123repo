﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT News
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTnews'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Entry point
def run():
    plugintools.log("YTnews.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTnews.main_list "+repr(params))

                
    plugintools.add_item( 
        #action="", 
        title="杨风時評",
        url="plugin://plugin.video.youtube/channel/UCE05tYKEsEk7Qmhwg5pqcKw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngr3CJnciQrh3Hw2p_QM68a6Qpdli_yzt_MPNCj=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寒锋时评",
        url="plugin://plugin.video.youtube/channel/UCNIRnNn6FZ-jWYFjwBhni7A/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTbUC60yxqFJqx2INF4uF1FHexAyZW1Gn_0bD5P=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="磊哥聊政经",
        url="plugin://plugin.video.youtube/channel/UCD_gy8DWV_DhjJ-bQXF5dGQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzP1GROhwHnIioy4TVg0Xvbbqu7kfLKXQJpGA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="新闻日报",
        url="plugin://plugin.video.youtube/channel/UCBDyUpTT5c3JDLPqY8Nuc5w/",
        thumbnail="https://yt3.ggpht.com/ytc/AMLnZu-canXloaR2fz0CbS6pJjbht2ozSI2HiSQ-Yjth=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="時政焦點",
        url="plugin://plugin.video.youtube/channel/UCHGg-bh_-x6YqVakEkql49A/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSPUvq0fkbU5RcOHc84lMOHo-gC0LJV6Js-wDO8sA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="利刃观察",
        url="plugin://plugin.video.youtube/channel/UCSyzXqH32Pv05iqpBsLYgcA/",
        thumbnail="https://yt3.ggpht.com/ytc/AMLnZu_Bdil1D90BZ64lIoGmIrOp0xM4bhhjBv9tsBsh=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Bastille Post巴士的報",
        url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnhub9qdg-gC-HVcqH6zhr9kCNf31qsocRmBoDEYqA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="屈機TV",
        url="plugin://plugin.video.youtube/channel/UCN0eCImZY6_OiJbo8cy5bLw/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSgEAGosPXetUZ8L_3eSFfYeTRWV159HSdrqWb7=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="東網點評",
        url="plugin://plugin.video.youtube/channel/UC4NjmIegGw-HyQCmxwAEZBQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwniNC13K7MkFYxvSslIs1iPz9oBLje83s1LWGd4Tlw=s88-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="亚洲特快",
        url="plugin://plugin.video.youtube/playlist/PLnhpRSU9pPuMCcyIvfjGSfASENr4YXh2_/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLRpMradlAYKn492HTcnLjoJG9z3SGndCyQHvxUh6A=s88-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="理科男士K一米",
        url="plugin://plugin.video.youtube/channel/UCJMEiNh1HvpopPU3n9vJsMQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwni7PXoQGwopk24A5hP9I1Ad7zIVLTZFoOKq0ho9tQ=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="布解探秘",
        url="plugin://plugin.video.youtube/channel/UCMr_V1NOgeMForzMtE0-aVg/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLQtm6U5u1cZt2t0sLUWhsOza5YRI1acfLJ6JxbRqw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="總編輯時間-梁建鋒",
        url="plugin://plugin.video.youtube/playlist/PLl7zeOiApUFWIYOZw3sJuOPtDdk06O5Ao/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="张维为The Chinese Way by Zhang Weiwei",
        url="plugin://plugin.video.youtube/channel/UCtDd5tl977dQrDiNoLhQHkw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnhrumSsFj9FCJH8Pauw52lI5vmURKfLNzWotWOj=s176-c-k-c0x00ffffff-no-rj",		
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GuanchaNews观察者网",
        url="plugin://plugin.video.youtube/channel/UCJncdiH3BQUBgCroBmhsUhQ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwvzvyNXchJysT6OZQ-KEnsxUjZRtjjs0gPZaZixw=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Guan Video观视频工作室",
        url="plugin://plugin.video.youtube/channel/UCYfJG6cGfW84FVLuy7semEg/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwKOxGSxCKBl_sKK7LdP7J_7ReLWlkjf_1Pyb4Hgg=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="极客队长官方频道GeekLead",
        url="plugin://plugin.video.youtube/channel/UCaW3MoZA0LMrZt9WFXtyvNQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSKnj5tiEhI8-SEm1RTuVaI95AwowDUGixNCQWs=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寒國人",
        url="plugin://plugin.video.youtube/channel/UCXkOTZJ743JgVhJWmNV8F3Q/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJx5ztsRguSX2MSTYREOEg-YnKrXYt9_r8hI6g=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="大鲨鱼街访",
        url="plugin://plugin.video.youtube/channel/UCI9ItaJU2Hm0Jealy3w5OrQ/",
        thumbnail="https://yt3.ggpht.com/jef-zSDANHMIYDromjyFYWMwPzmqRe1MTLqSTXPxGUXwhPR0ZfTxQG75mAd3ruE3397GBY-Q=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="四處觀察",
        url="plugin://plugin.video.youtube/channel/UC6OeJCR9gHsJPVyNhXfK4tA/",
        thumbnail="https://yt3.ggpht.com/I0-_edvQIWtj1oYqhtsbo4-q2iK5A69J0EPd9uHZ-1zGQTMsSLcXxuaqf9ZFVbN7ptOxLopN=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                 
    plugintools.add_item( 
        #action="", 
        title="德国知事",
        url="plugin://plugin.video.youtube/channel/UCdXqCN_HtF_RjlsHzDSnJIQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngI4Tqs-riZXHMT_gyiwolO9ogPdbXSsGdqaRCqoQ=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="冼師傅講場",
        url="plugin://plugin.video.youtube/channel/UCFRBCHEqZNJ2Rb1IjrCC8Zw/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_Qg35rIi0wFPrOGCObxPdm5k2y8qSAX6a4Og=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="傅正",
        url="plugin://plugin.video.youtube/playlist/PLr0JU8OOrK4iENkcC5UWrHM88Hbr5X7QU/",
        thumbnail="https://i1.hdslb.com/bfs/face/b5a5301e9d55f4a7fa24cbc84690eeb9b86c5ad6.jpg@240w_240h_1c_1s.webp",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="我是毛五",
        url="plugin://plugin.video.youtube/channel/UCYxHQWKf3YnBu_dKENKzM9Q/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTGLuvIy3Pjg_kLTo7fM0mpoSvXaCOQuBF_au8=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="新闻联播247",
        url="plugin://plugin.video.youtube/channel/UCe5OepLlodMH68RIJxsmISw/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSHV3VfBrdiSYBxR18mZ_00y4uwjqJ2aPddSvSeEw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Yan Talk 岩论",
        url="plugin://plugin.video.youtube/channel/UCwNGgFvBpxtU8JagZLzztzQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwniH6JQh4uZHOSRAUUV1mAvfjim1Tpr8buqblYEu=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                   
    plugintools.add_item( 
        #action="", 
        title="直播港澳台",
        url="plugin://plugin.video.youtube/channel/UC-UFD2pRujktkSyAD999mFg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngpu2fFPt98ST7y5VteaNW7jqfM40n6lyQgnLn6=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="楊世光在金錢爆",
        url="plugin://plugin.video.youtube/channel/UCrm095p7ZHRS1njmQ1wkgCg/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLS9plBmDiY6CoMUPNK5JWYGgfYGojwL7JS8X51jiw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="李天豪",
        url="plugin://plugin.video.youtube/channel/UCOrcp--cu4Egwdc07X44btA/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSFhfNqDOvZE3pJ8sP_OPH-iSHt5PeDuW0w8qH1KA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="王志郁Plus",
        url="plugin://plugin.video.youtube/channel/UCy-pqt2qjYVDZqwBiTS9yDA/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLRf9DO0RtOk7gZNyUrpBYau3TSixouNJHGZgD2N2g=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="我是柳傑克",
        url="plugin://plugin.video.youtube/channel/UC000Jn3HGeQSwBuX_cLDK8Q/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSyvQcw2l-ZhydsWKuTwQ3d4zoNA0joKQArA0aiXw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="东京自干五-长脸博士传媒",
        url="plugin://plugin.video.youtube/channel/UCzjhdu0yMChb8vRz8Ky3LCg/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSdTjWgSLMuKdSnt-FwqUYsfMMSNSXBsyzLApXXxw=s88-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="洞见时事",
        url="plugin://plugin.video.youtube/channel/UCs4Z-fQ0W42K6NVhGiOF77Q/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLQYmik_K_TfT9Cunu9b8ZTDt-277HXimQ7LQzvq=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="大佬时空",
        url="plugin://plugin.video.youtube/channel/UCEjqTrvJdLG7Eo0KP1AzYJw/",
        thumbnail="https://yt3.ggpht.com/33tPlWGO_wM0pKGgvUmm083amBCJDgFkLt_ZUcg-hNdGcwHZrzTZbaLH575rQq2mSi-U31oQC30=s176-c-k-c0x00ffffff-no-rjj",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="WION",
        url="plugin://plugin.video.youtube/channel/UC_gUM8rL-Lrg6O3adPW9K1g/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTjMUv7cELVis5Au9R2HRytJnMtLShdD_k4IaeFQA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="Asian Boss",
        url="plugin://plugin.video.youtube/channel/UC2-_WWPT_124iN6jiym4fOw/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSHNaY_YBOYiS4J4pHleM9h2LhgpOFTOGqU9AThpw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="东方卫视环球交叉点",
        url="plugin://plugin.video.youtube/channel/UCG4kGP4ETdKzseQshMCCBKg/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTCWOqJffksmrwkiRThZk3OCBg_-qfXT5t4k5bcTw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="中国梦时代",
        url="plugin://plugin.video.youtube/channel/UCltlJhJae9lCBnrtpQs53lw/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLRkfL2vxMBkXVYyx1Mo6zJvHtBhpKgicgn2EkPDbA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="资讯快线 Hong News",
        url="plugin://plugin.video.youtube/channel/UCoK8i6TNovuOYouvDK97VcQ/",
        thumbnail="https://yt3.ggpht.com/kCycf7KK26Wo1JSCBBO_6IYMY96JyHnGzpMGRFp8qMa3LYNmu7vuSpJb4GQIVQGZXUAT58ty=s176-c-k-c0x00ffffff-no-rj",		
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="中国新观察",
        url="plugin://plugin.video.youtube/channel/UCjVRKYmoezJ5A9iCvFomV1g/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTGQPdjf03uF2LgIuLX50YPCPe4beTWhMHGbMokhw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="环球新视线",
        url="plugin://plugin.video.youtube/channel/UCyeUKSEb159TVvlhA01B3xA/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLQU-0LzPRtnps57vWwxsKRfMDq-Z6a21Khk10qA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                 
    plugintools.add_item( 
        #action="", 
        title="环球新视野",
        url="plugin://plugin.video.youtube/channel/UC6aT6m2WuXUfzoahv1hDIaw/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJz0ihZHbWZdPNZBcM7bc9HUIO6K_XrvyQcLGA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寰球一线",
        url="plugin://plugin.video.youtube/channel/UC4XQX3UwoCSvNQR0Tq1bGaQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngxHYTx442U1ieiKKfsv1x9LJD9FUFK_zSgk0iM=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                 
    plugintools.add_item( 
        #action="", 
        title="龙之声",
        url="plugin://plugin.video.youtube/channel/UCjpF47XO6JfF9QVmXoRociQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLS2svK55tNextjFxjqpcTSXg7IlpZ3vzOFOu9aq=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="卢克文",
        url="plugin://plugin.video.youtube/channel/UClTVEzPs4aNRXl3xDfMKqaA/",
        thumbnail="https://i2.hdslb.com/bfs/face/c0a1b1f382c68da453f5a273ce069ee46e685364.jpg@225w_225h_1c.webp",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="环球观察",
        url="plugin://plugin.video.youtube/channel/UC6iTaivn7fHD8rmPQKcUdQg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnh6ERfeIPeRq8k26myDBqW-n-LGduOBIVELrQgB=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="胡锡进Global Times",
        url="plugin://plugin.video.youtube/channel/UCVD-MGxD71IQUk9_hHq8MdA/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnh07drypjn7U6BZ-3_vW4FTbAZXrU8Q195P0sVO=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="诚阅 ChengYue",
        url="plugin://plugin.video.youtube/channel/UCd6umYVQpBZ9CIyCwe8Kg7w/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJxgeqxuisbDAlXj9v7wI6b_1z-pYW8wHRYjAylu=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
            
    plugintools.add_item( 
        #action="", 
        title="全球大視野",
        url="plugin://plugin.video.youtube/channel/UCiwt1aanVMoPYUt_CQYCPQg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnj2DjFWmKz2gqvNpgy5ElO_Zd25NGbbapBy-0mEFw=s176-c-k-c0x00ffffff-no-rj-mo",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="军政速递",
        url="plugin://plugin.video.youtube/channel/UCdyh01hxhKg6uTurnLdickQ/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngx1r4JjslB2Q8aVBbn1pVCFyK6hu1vb7zlIDX1=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="国际时评",
        url="plugin://plugin.video.youtube/channel/UC8HvBg9Rw-cUz0tqKdkKkNg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnguzTBHPbmCvhN3yhwdkFZ-Z_Fy5Hsb-GsB2vnG=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
               
    plugintools.add_item( 
        #action="", 
        title="環球諜報",
        url="plugin://plugin.video.youtube/channel/UCDNXgJEIJx8IiUo2-X6Amdw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwniDyBqarPSVANm6-SNpNrIUoq14G8MRAIxRvgff0Q=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="快看资讯",
        url="plugin://plugin.video.youtube/channel/UCgkHTZsCdH8P9z7lazTXN3g/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzB-L487V6_1Q5-qx5hw2xrsMsZVqF0BLE9fg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="點新聞",
        url="plugin://plugin.video.youtube/channel/UCcrnNcl12onXCeS_3Bi0a2Q/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l79aat4yF9qy5E0uqRiFt4d4t40Q4VZknha4IA=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="新聞龍捲風",
        url="plugin://plugin.video.youtube/channel/UCMetIbaFeT7AzX1K_YOGEjA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyyauxR_0Vz_1Lp2ZmgWfou9ve-VOqrkaZU0A=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="新潮民",
        url="plugin://plugin.video.youtube/channel/UCzV8ytvWEGtMWk0wt9zA1Ng/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnjxUU5eZLp-MAoU7hJDFSlJMmRT2O5KrSc1XO38cw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="KOLHK 時事梓引",
        url="plugin://plugin.video.youtube/channel/UCG6WtLOTXySl1terUhQYWCA/",
        thumbnail="https://yt3.ggpht.com/NDTvGFU50VALAyt8F6jbhS73gSkpgIGRcWMa6umMEgdCSVj7Dwug7552xLCTi6giI6L0ZMpEi5w=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="陳穎欣Joephy Chan",
        url="plugin://plugin.video.youtube/channel/UCvlBe-TQfjLFINSSYQt9Tjg/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyelSSdVCQhptmAxwrUMmVMVSO13zueU_mOnQ=s144-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="大樹與木頭 ‧Y2K Channel",
        url="plugin://plugin.video.youtube/channel/UCFfLWSnUCblI4Lpsph7H1lA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJymkSjncCTZJiz3q8Vpss4LVzKnfX5KctTyPmteRA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="娜娜琳",
        url="plugin://plugin.video.youtube/channel/UCn0Lyn2rx4ZJcHgD-jgNhiw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnjwbRazIvLSThIvvt1Z4auaoaNzlsAafuzot2HN=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="空姐牛肉飯Annie",
        url="plugin://plugin.video.youtube/channel/UCpytXTSrsqbCjmqb6MfMrmw/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwnjE3Ycu_cj3RRlhLzJc0BkKkthOvAYUeV9HIkhXBg=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Chong San 沖先生",
        url="plugin://plugin.video.youtube/channel/UCsGqE-IVUCwyyi_WRsvVLJg/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwngM7DJO1yuLEI0KvbMpR6CBSBIys6sI9aD4V-AN=s176-c-k-c0x00ffffff-no-rj",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="有聲專欄",
        url="plugin://plugin.video.youtube/playlist/PL50ryNxlMBN5kwOJ_DvTeNXhBrQRbm9N6/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyGzUS1KUF4yZ1VnwWZI8UxEU-4KJhHLr1Lf_dwfA=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Vovan222prank",
        url="plugin://plugin.video.youtube/channel/UC7aFhtshxOnaqioFAJ0ZSvA/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLS71RehjZ8viATHcp5QHyTV8DAN33dDTJlvE9ySkQ=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="火鍋大王Nathan Rich",
        url="plugin://plugin.video.youtube/channel/UCaSlyjhR4WC7QhYuaivxb6g/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l78ngY4lsF1M-z5fRTQxaHGjsHEOJ5Ly2gpjyQ=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="和之梦",
        url="plugin://plugin.video.youtube/channel/UCwHUYtwH5E41O6MiYoC19ng/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLSgBajZNqy03PTZe0WjiBSVH_zln38X3yAkTHyMHg=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="印度三哥MANU马怒",
        url="plugin://plugin.video.youtube/channel/UC9rRTrTFBo-ntv7Cx10D2QA/",
        thumbnail="https://yt3.ggpht.com/ytc/AAUvwng3LEsnMLW2NJo-fntq-NNLYihved5LdGd9rvs3=s176-c-k-c0x00ffffff-no-rj",		
        folder=True )
                  
    plugintools.add_item( 
        #action="", 
        title="貨幣互換,本幣結算",
        url="plugin://plugin.video.youtube/play/?video_id=mQAaXQJNVJQ",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="【科普/体验】数字人民币是什么？使用体验如何？数字人民币简单科普与试点地区体验",
        url="plugin://plugin.video.youtube/play/?video_id=h6KeIG1umtI",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="NGO颠覆史（上）",
        url="plugin://plugin.video.youtube/play/?video_id=Tb_g8UgkyRI",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="一堂課帶你看懂烏克蘭危機",
        url="plugin://plugin.video.youtube/play/?video_id=m6sRBEpHBpw",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="日本半導體之衰落",
        url="plugin://plugin.video.youtube/play/?video_id=fCgyc-XwzI4",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="中国对抗霸权的终极武器",
        url="plugin://plugin.video.youtube/play/?video_id=tlaQ2KONzx0",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="中國如何反制美國“剪羊毛",
        url="plugin://plugin.video.youtube/play/?video_id=ZNUhwXykgZs",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="美联储加息減息“剪羊毛",
        url="plugin://plugin.video.youtube/play/?video_id=T6cVPxET77I",
        thumbnail="",
        folder=False )
                   
    plugintools.add_item( 
        #action="", 
        title="美国如何印钞收割全球",
        url="plugin://plugin.video.youtube/play/?video_id=Fni8y0TJWOg",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="美国如何控制全球的糧食",
        url="plugin://plugin.video.youtube/play/?video_id=xf5GnGpDVFc",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="美國房地產次貸危機",
        url="plugin://plugin.video.youtube/play/?video_id=Hjtnxq7qZ7M",
        thumbnail="",
        folder=False )
                  
    plugintools.add_item( 
        #action="", 
        title="美國長臂管轄",
        url="plugin://plugin.video.youtube/play/?video_id=bc26Tt5B9Ik",
        thumbnail="",
        folder=False )
	
    plugintools.add_item( 
        #action="", 
        title="南海那场世纪对峙",
        url="plugin://plugin.video.youtube/play/?video_id=WXJ6LC4mvHM",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國佔領一個國家的12個步驟",
        url="plugin://plugin.video.youtube/play/?video_id=qyqKDomSeUk",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國掠奪一個地方的四部曲",
        url="plugin://plugin.video.youtube/play/?video_id=zffGd8RQhTA",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國謀害中國陷入圈套的十個步驟1",
        url="plugin://plugin.video.youtube/play/?video_id=ddlyL6gqffM",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="美國謀害中國陷入圈套的十個步驟2",
        url="plugin://plugin.video.youtube/play/?video_id=6X4DHDuILIo",
        thumbnail="",
        folder=False )	

    plugintools.add_item( 
        #action="", 
        title="美國謀害中國陷入圈套的十個步驟3",
        url="plugin://plugin.video.youtube/play/?video_id=lxdQPMcxz78",
        thumbnail="",
        folder=False )	

    plugintools.add_item( 
        #action="", 
        title="孟晚舟案",
        url="plugin://plugin.video.youtube/play/?video_id=NOkZeEC5li8",
        thumbnail="",
        folder=False )	

    plugintools.add_item( 
        #action="", 
        title="孟晚舟案全部真相",
        url="plugin://plugin.video.youtube/play/?video_id=6_dhlL5z9kw",
        thumbnail="",
        folder=False )	
       
run()