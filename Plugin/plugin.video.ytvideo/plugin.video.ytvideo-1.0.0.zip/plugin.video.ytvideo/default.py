# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from common import *
from ytvideo import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

#===============================================================================

selfAddon = xbmcaddon.Addon(id=addon_id)

try:
    datapath= xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))
except:
    datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.ytvideo')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

#===============================================================================
def Main():

    addDirMain('新聞及娛樂',BASE,51,'special://home/addons/plugin.video.ytvideo/icon/news.png','fanart.jpg')
    addDirMain('飲食頻道',BASE,52,'special://home/addons/plugin.video.ytvideo/icon/food.png','fanart.jpg')
    addDirMain('時政熱點',BASE,50,'special://home/addons/plugin.video.ytvideo/icon/politics.png','fanart.jpg')
#    addDirMain('Miscellaneous',BASE,53,'special://home/addons/plugin.video.ytvideo/icon/misc.png','fanart.jpg')
#    addDirMain('Languages',BASE,54,'special://home/addons/plugin.video.ytvideo/icon/lang.png','fanart.jpg')
#    addDirMain('Electronic Repair',BASE,55,'special://home/addons/plugin.video.ytvideo/icon/electronic.png','fanart.jpg')
#    addDirMain('Music',BASE,56,'special://home/addons/plugin.video.ytvideo/icon/learnmusic.png','fanart.jpg')
    
#===============================================================================      
#@route(mode='Politics')    
def 時政熱點():

    Add_Dir(
        name="杨风時評", url="plugin://plugin.video.youtube/channel/UCE05tYKEsEk7Qmhwg5pqcKw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngr3CJnciQrh3Hw2p_QM68a6Qpdli_yzt_MPNCj=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="巴士的報", url="plugin://plugin.video.youtube/channel/UCCBNE0MbFaSooy7ZhJwXSrg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhub9qdg-gC-HVcqH6zhr9kCNf31qsocRmBoDEYqA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="磊哥聊政经", url="plugin://plugin.video.youtube/channel/UCD_gy8DWV_DhjJ-bQXF5dGQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzP1GROhwHnIioy4TVg0Xvbbqu7kfLKXQJpGA=s100-c-k-c0xffffffff-no-rj-mo")
                 
    Add_Dir(
        name="K2秀", url="plugin://plugin.video.youtube/channel/UCLqn_8sNfaye3wwNC1PfPIQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AGIKgqPdKlAR7CK-HehxGLPXfIeZS0jwgy9K5COLqWtb=s176-c-k-c0x00ffffff-no-rj")
                 
    Add_Dir(
        name="德国知事", url="plugin://plugin.video.youtube/channel/UCdXqCN_HtF_RjlsHzDSnJIQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngI4Tqs-riZXHMT_gyiwolO9ogPdbXSsGdqaRCqoQ=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="汤山老王", url="plugin://plugin.video.youtube/channel/UCtRJS7qkLIkW7Xdljeaqk8Q/", folder=True,
        icon="https://yt3.googleusercontent.com/n6K17acHSeNK2P-05w3YHA7nTvWuNOBSm8VaAHFZv6uqK9g9WCdbqxSGxhrGoINuV3ULi24G=s176-c-k-c0x00ffffff-no-rj")
                   
    Add_Dir(
        name="直播港澳台", url="plugin://plugin.video.youtube/channel/UC-UFD2pRujktkSyAD999mFg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngpu2fFPt98ST7y5VteaNW7jqfM40n6lyQgnLn6=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="起云戰略", url="plugin://plugin.video.youtube/channel/UCKaNq-iZLbgcJGs7T8Z8HCQ/", folder=True,
        icon="https://yt3.googleusercontent.com/9Q_W3jAt7xm_JMGMpyXISgPzxEs6Wbl2WbDs1QNsIXvWsX-EnARu5a8D4icmUbgpi27XF6DW=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="洞见时事", url="plugin://plugin.video.youtube/channel/UCs4Z-fQ0W42K6NVhGiOF77Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQYmik_K_TfT9Cunu9b8ZTDt-277HXimQ7LQzvq=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="暗中观察", url="plugin://plugin.video.youtube/channel/UCcTGHpkUFYspGjTYFIRqp3g/", folder=True,
        icon="https://yt3.googleusercontent.com/QWBpraRAyZgkxqVWHEiRiUDaec4WKbHooFUngI3gUOvjsSNhdPMwYdwLqjK_j5f9V8jytkdr=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="我是毛五", url="plugin://plugin.video.youtube/channel/UCYxHQWKf3YnBu_dKENKzM9Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTGLuvIy3Pjg_kLTo7fM0mpoSvXaCOQuBF_au8=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="江湖百晓生", url="plugin://plugin.video.youtube/channel/UCfqQVT1iMd1_cnahTy1Hieg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9j_rEvpjo5xZh4u48JgIayLXCXaM7It_tOvtVNJQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="开心天天", url="plugin://plugin.video.youtube/channel/UCJ0gz1Tuls_ivqxaVt_g2lw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9lmO4i4uaiXc42X4hWZKM5Ou9R0iVfMWMlZQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="總編輯時間-梁建鋒", url="plugin://plugin.video.youtube/playlist/PLl7zeOiApUFWIYOZw3sJuOPtDdk06O5Ao/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo")
        
    Add_Dir(
        name="亚洲特快", url="plugin://plugin.video.youtube/playlist/PLnhpRSU9pPuMCcyIvfjGSfASENr4YXh2_/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRpMradlAYKn492HTcnLjoJG9z3SGndCyQHvxUh6A=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="理科男士K一米", url="plugin://plugin.video.youtube/channel/UCJMEiNh1HvpopPU3n9vJsMQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwni7PXoQGwopk24A5hP9I1Ad7zIVLTZFoOKq0ho9tQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="布解探秘", url="plugin://plugin.video.youtube/channel/UCMr_V1NOgeMForzMtE0-aVg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQtm6U5u1cZt2t0sLUWhsOza5YRI1acfLJ6JxbRqw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="观察者网", url="plugin://plugin.video.youtube/channel/UCJncdiH3BQUBgCroBmhsUhQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwvzvyNXchJysT6OZQ-KEnsxUjZRtjjs0gPZaZixw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="观视频工作室", url="plugin://plugin.video.youtube/channel/UCYfJG6cGfW84FVLuy7semEg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwKOxGSxCKBl_sKK7LdP7J_7ReLWlkjf_1Pyb4Hgg=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="张维为", url="plugin://plugin.video.youtube/channel/UCtDd5tl977dQrDiNoLhQHkw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhrumSsFj9FCJH8Pauw52lI5vmURKfLNzWotWOj=s176-c-k-c0x00ffffff-no-rj")        

    Add_Dir(
        name="寒國人", url="plugin://plugin.video.youtube/channel/UCXkOTZJ743JgVhJWmNV8F3Q/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJx5ztsRguSX2MSTYREOEg-YnKrXYt9_r8hI6g=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="Yan Talk 岩论", url="plugin://plugin.video.youtube/channel/UCwNGgFvBpxtU8JagZLzztzQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniH6JQh4uZHOSRAUUV1mAvfjim1Tpr8buqblYEu=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="新闻日报", url="plugin://plugin.video.youtube/channel/UCBDyUpTT5c3JDLPqY8Nuc5w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-canXloaR2fz0CbS6pJjbht2ozSI2HiSQ-Yjth=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="小岛大浪吹", url="plugin://plugin.video.youtube/channel/UCYPT3wl0MgbOz63ho166KOw/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AMLnZu-QZvqsA4E1PSVMddExMsBa9VFmEf_vnNz3OS5uTg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="星球熱點", url="plugin://plugin.video.youtube/channel/UC2r2LPbOUssIa02EbOIm7NA/", folder=True,
        icon="https://yt3.googleusercontent.com/Q0wJomXXFN0U4K9weuNsU7DT7T09heboXcQT8i9NfY0YCq5vd8orgEw9eE4RvT7J81lLak43Gg=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="7知識局", url="plugin://plugin.video.youtube/channel/UCvFxLkzL0KgDv0B3-leVf5A/", folder=True,
        icon="https://yt3.ggpht.com/Bv6npS0UDxqQCMRJU_nARCFoBkIMYQs7s3YMmMNtmjNRIRLgADsAbHd4H7Qknz-Ox2yGA1rx=s176-c-k-c0x00ffffff-no-rj")              

    Add_Dir(
        name="Hot Topics Time", url="plugin://plugin.video.youtube/channel/UCZPCDOdY4m_m1bqjAl6P9rA/", folder=True,
        icon="https://yt3.googleusercontent.com/mnZx2ysQmJRkcDhUX4RHs8XRVbYm6_T0IGQHiZebPRafxOsDtCR8Rhrpc5L_kIcRJiBB5nKWiw=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="赖岳谦TV", url="plugin://plugin.video.youtube/channel/UCnrxxRlv2ZSSW4ApuEy8C0w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-xnof2H-6jr8i1Rl5MojdVJXHzuv1Xfem8OUNwUA=s176-c-k-c0x00ffffff-no-rj")        

    Add_Dir(
        name="Chong San 沖先生", url="plugin://plugin.video.youtube/channel/UCsGqE-IVUCwyyi_WRsvVLJg/", folder=True,
        icon="https://yt3.ggpht.com/XbJK4MQLInnB3FCn0FI1KB3NgJdczSH43QbcX77XAsklvseyviRr93ZzFhmgWxI1swAvRBpybw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="中天新聞", url="plugin://plugin.video.youtube/channel/UCpu3bemTQwAU8PqM4kJdoEQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_GcqEtH92jxUu-uPnd6Z2KRScKh_Qi1T9M0mgluQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="军武侦察兵", url="plugin://plugin.video.youtube/channel/UCU2t_Mq9F97eWHJfgBom_wg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9XL6NnJ3nG9HNAunK_nnu5qIYkjqwZKmePn85Qrg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="龍騰大中國", url="plugin://plugin.video.youtube/channel/UCtmltVWKWMD7POU6NUW5PVA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_2MHSz9haficKalbmRUXfbVt9rNAbLVGl0oe-ohQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="時政焦點", url="plugin://plugin.video.youtube/channel/UCHGg-bh_-x6YqVakEkql49A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSPUvq0fkbU5RcOHc84lMOHo-gC0LJV6Js-wDO8sA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="利刃观察", url="plugin://plugin.video.youtube/channel/UCSyzXqH32Pv05iqpBsLYgcA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_Bdil1D90BZ64lIoGmIrOp0xM4bhhjBv9tsBsh=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="屈機TV", url="plugin://plugin.video.youtube/channel/UCN0eCImZY6_OiJbo8cy5bLw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSgEAGosPXetUZ8L_3eSFfYeTRWV159HSdrqWb7=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="Ming仔", url="plugin://plugin.video.youtube/channel/UCDoEdJo-PI-EKGNKomwLroQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJWXSWaein_lDcN-f3ARHQkXEwXDWuH3xDHIwmWv0g=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="東網點評",
        url="plugin://plugin.video.youtube/channel/UC4NjmIegGw-HyQCmxwAEZBQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniNC13K7MkFYxvSslIs1iPz9oBLje83s1LWGd4Tlw=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="极客队长官方频道GeekLead", url="plugin://plugin.video.youtube/channel/UCaW3MoZA0LMrZt9WFXtyvNQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSKnj5tiEhI8-SEm1RTuVaI95AwowDUGixNCQWs=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="冼師傅講場", url="plugin://plugin.video.youtube/channel/UCFRBCHEqZNJ2Rb1IjrCC8Zw/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l7_Qg35rIi0wFPrOGCObxPdm5k2y8qSAX6a4Og=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="傅正", url="plugin://plugin.video.youtube/playlist/PLr0JU8OOrK4iENkcC5UWrHM88Hbr5X7QU/", folder=True,
        icon="https://i1.hdslb.com/bfs/face/b5a5301e9d55f4a7fa24cbc84690eeb9b86c5ad6.jpg@240w_240h_1c_1s.webp")

    Add_Dir(
        name="楊世光在金錢爆", url="plugin://plugin.video.youtube/channel/UCrm095p7ZHRS1njmQ1wkgCg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS9plBmDiY6CoMUPNK5JWYGgfYGojwL7JS8X51jiw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="李天豪", url="plugin://plugin.video.youtube/channel/UCOrcp--cu4Egwdc07X44btA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSFhfNqDOvZE3pJ8sP_OPH-iSHt5PeDuW0w8qH1KA=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="王志郁Plus", url="plugin://plugin.video.youtube/channel/UCy-pqt2qjYVDZqwBiTS9yDA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRf9DO0RtOk7gZNyUrpBYau3TSixouNJHGZgD2N2g=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="我是柳傑克", url="plugin://plugin.video.youtube/channel/UC000Jn3HGeQSwBuX_cLDK8Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSyvQcw2l-ZhydsWKuTwQ3d4zoNA0joKQArA0aiXw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="东京自干五-长脸博士传媒", url="plugin://plugin.video.youtube/channel/UCzjhdu0yMChb8vRz8Ky3LCg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSdTjWgSLMuKdSnt-FwqUYsfMMSNSXBsyzLApXXxw=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="WION", url="plugin://plugin.video.youtube/channel/UC_gUM8rL-Lrg6O3adPW9K1g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTjMUv7cELVis5Au9R2HRytJnMtLShdD_k4IaeFQA=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="Asian Boss", url="plugin://plugin.video.youtube/channel/UC2-_WWPT_124iN6jiym4fOw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSHNaY_YBOYiS4J4pHleM9h2LhgpOFTOGqU9AThpw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="东方卫视环球交叉点", url="plugin://plugin.video.youtube/channel/UCG4kGP4ETdKzseQshMCCBKg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTCWOqJffksmrwkiRThZk3OCBg_-qfXT5t4k5bcTw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="中国梦时代", url="plugin://plugin.video.youtube/channel/UCltlJhJae9lCBnrtpQs53lw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRkfL2vxMBkXVYyx1Mo6zJvHtBhpKgicgn2EkPDbA=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="中国新观察", url="plugin://plugin.video.youtube/channel/UCjVRKYmoezJ5A9iCvFomV1g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTGQPdjf03uF2LgIuLX50YPCPe4beTWhMHGbMokhw=s176-c-k-c0x00ffffff-no-rj")
                 
    Add_Dir(
        name="环球新视野", url="plugin://plugin.video.youtube/channel/UC6aT6m2WuXUfzoahv1hDIaw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJz0ihZHbWZdPNZBcM7bc9HUIO6K_XrvyQcLGA=s288-c-k-c0xffffffff-no-rj-mo")
                 
    Add_Dir(
        name="龙之声", url="plugin://plugin.video.youtube/channel/UCjpF47XO6JfF9QVmXoRociQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS2svK55tNextjFxjqpcTSXg7IlpZ3vzOFOu9aq=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="卢克文", url="plugin://plugin.video.youtube/channel/UClTVEzPs4aNRXl3xDfMKqaA/", folder=True,
        icon="https://i2.hdslb.com/bfs/face/c0a1b1f382c68da453f5a273ce069ee46e685364.jpg@225w_225h_1c.webp")

    Add_Dir(
        name="环球观察", url="plugin://plugin.video.youtube/channel/UC6iTaivn7fHD8rmPQKcUdQg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnh6ERfeIPeRq8k26myDBqW-n-LGduOBIVELrQgB=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="胡锡进Global Times", url="plugin://plugin.video.youtube/channel/UCVD-MGxD71IQUk9_hHq8MdA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnh07drypjn7U6BZ-3_vW4FTbAZXrU8Q195P0sVO=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="诚阅 ChengYue", url="plugin://plugin.video.youtube/channel/UCd6umYVQpBZ9CIyCwe8Kg7w/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxgeqxuisbDAlXj9v7wI6b_1z-pYW8wHRYjAylu=s176-c-k-c0x00ffffff-no-rj")
            
    Add_Dir(
        name="全球大視野", url="plugin://plugin.video.youtube/channel/UCiwt1aanVMoPYUt_CQYCPQg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnj2DjFWmKz2gqvNpgy5ElO_Zd25NGbbapBy-0mEFw=s176-c-k-c0x00ffffff-no-rj-mo")
                
    Add_Dir(
        name="军政速递", url="plugin://plugin.video.youtube/channel/UCdyh01hxhKg6uTurnLdickQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngx1r4JjslB2Q8aVBbn1pVCFyK6hu1vb7zlIDX1=s176-c-k-c0x00ffffff-no-rj")
                
    Add_Dir(
        name="国际时评", url="plugin://plugin.video.youtube/channel/UC8HvBg9Rw-cUz0tqKdkKkNg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnguzTBHPbmCvhN3yhwdkFZ-Z_Fy5Hsb-GsB2vnG=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="快看资讯", url="plugin://plugin.video.youtube/channel/UCgkHTZsCdH8P9z7lazTXN3g/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzB-L487V6_1Q5-qx5hw2xrsMsZVqF0BLE9fg=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="點新聞", url="plugin://plugin.video.youtube/channel/UCcrnNcl12onXCeS_3Bi0a2Q/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l79aat4yF9qy5E0uqRiFt4d4t40Q4VZknha4IA=s288-c-k-c0xffffffff-no-rj-mo")
        
    Add_Dir(
        name="新潮民", url="plugin://plugin.video.youtube/channel/UCzV8ytvWEGtMWk0wt9zA1Ng/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjxUU5eZLp-MAoU7hJDFSlJMmRT2O5KrSc1XO38cw=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="KOLHK 時事梓引", url="plugin://plugin.video.youtube/channel/UCG6WtLOTXySl1terUhQYWCA/", folder=True,
        icon="https://yt3.ggpht.com/NDTvGFU50VALAyt8F6jbhS73gSkpgIGRcWMa6umMEgdCSVj7Dwug7552xLCTi6giI6L0ZMpEi5w=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="陳穎欣Joephy Chan", url="plugin://plugin.video.youtube/channel/UCvlBe-TQfjLFINSSYQt9Tjg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyelSSdVCQhptmAxwrUMmVMVSO13zueU_mOnQ=s144-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="大樹與木頭 ‧Y2K Channel", url="plugin://plugin.video.youtube/channel/UCFfLWSnUCblI4Lpsph7H1lA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJymkSjncCTZJiz3q8Vpss4LVzKnfX5KctTyPmteRA=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="娜娜琳", url="plugin://plugin.video.youtube/channel/UCn0Lyn2rx4ZJcHgD-jgNhiw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjwbRazIvLSThIvvt1Z4auaoaNzlsAafuzot2HN=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="空姐牛肉飯Annie", url="plugin://plugin.video.youtube/channel/UCpytXTSrsqbCjmqb6MfMrmw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjE3Ycu_cj3RRlhLzJc0BkKkthOvAYUeV9HIkhXBg=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="Chong San 沖先生", url="plugin://plugin.video.youtube/channel/UCsGqE-IVUCwyyi_WRsvVLJg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngM7DJO1yuLEI0KvbMpR6CBSBIys6sI9aD4V-AN=s176-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="有聲專欄", url="plugin://plugin.video.youtube/playlist/PL50ryNxlMBN5kwOJ_DvTeNXhBrQRbm9N6/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyGzUS1KUF4yZ1VnwWZI8UxEU-4KJhHLr1Lf_dwfA=s100-c-k-c0xffffffff-no-rj-mo")
        
    Add_Dir(
        name="Vovan222prank", url="plugin://plugin.video.youtube/channel/UC7aFhtshxOnaqioFAJ0ZSvA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS71RehjZ8viATHcp5QHyTV8DAN33dDTJlvE9ySkQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="火鍋大王Nathan Rich", url="plugin://plugin.video.youtube/channel/UCaSlyjhR4WC7QhYuaivxb6g/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l78ngY4lsF1M-z5fRTQxaHGjsHEOJ5Ly2gpjyQ=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="和之梦", url="plugin://plugin.video.youtube/channel/UCwHUYtwH5E41O6MiYoC19ng/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSgBajZNqy03PTZe0WjiBSVH_zln38X3yAkTHyMHg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="印度三哥MANU马怒", url="plugin://plugin.video.youtube/channel/UC9rRTrTFBo-ntv7Cx10D2QA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwng3LEsnMLW2NJo-fntq-NNLYihved5LdGd9rvs3=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="台積與中芯最終命運, 巴菲特購台積股權之謎", url="plugin://plugin.video.youtube/kodion/search/query/?q=EKujoLAEO5A", folder=False)
                  
    Add_Dir(
        name="【科普/体验】数字人民币是什么？使用体验如何？数字人民币简单科普与试点地区体验", url="plugin://plugin.video.youtube/kodion/search/query/?q=h6KeIG1umtI", folder=False)
                  
    Add_Dir(
        name="国产GPU如何突围？AI芯片与CPU/GPU有何不同？", url="plugin://plugin.video.youtube/kodion/search/query/?q=7EXDp6c9n-Q", folder=False)
  
    Add_Dir(
        name="2008次貸危機 & 2023 svb银行危机", url="plugin://plugin.video.youtube/kodion/search/query/?q=Ak8x7pKZ7pw", folder=False)

    Add_Dir(
        name="美联储加息減息“剪羊毛", url="plugin://plugin.video.youtube/kodion/search/query/?q=T6cVPxET77I", folder=False)
                  
    Add_Dir(
        name="美国如何利用加息降息周期收割全世界", url="plugin://plugin.video.youtube/kodion/search/query/?q=dhEsJt7qo8o", folder=False)
                  
    Add_Dir(
        name="美國長臂管轄", url="plugin://plugin.video.youtube/kodion/search/query/?q=bc26Tt5B9Ik", folder=False)
    
    Add_Dir(
        name="南海那场世纪对峙", url="plugin://plugin.video.youtube/kodion/search/query/?q=WXJ6LC4mvHM", folder=False)
                
    Add_Dir(
        name="一堂課帶你看懂烏克蘭危機", url="plugin://plugin.video.youtube/kodion/search/query/?q=m6sRBEpHBpw", folder=False)

    Add_Dir(
        name="NGO颠覆史（上）", url="plugin://plugin.video.youtube/kodion/search/query/?q=Tb_g8UgkyRI", folder=False)

    Add_Dir(
        name="美國佔領一個國家的12個步驟", url="plugin://plugin.video.youtube/kodion/search/query/?q=qyqKDomSeUk", folder=False)

    Add_Dir(
        name="美國掠奪一個地方的四部曲", url="plugin://plugin.video.youtube/kodion/search/query/?q=zffGd8RQhTA", folder=False)

    Add_Dir(
        name="美國謀害中國陷入圈套的十個步驟1", url="plugin://plugin.video.youtube/kodion/search/query/?q=ddlyL6gqffM", folder=False)

    Add_Dir(
        name="美國謀害中國陷入圈套的十個步驟2", url="plugin://plugin.video.youtube/kodion/search/query/?q=6X4DHDuILIo", folder=False)

    Add_Dir(
        name="美國謀害中國陷入圈套的十個步驟3", url="plugin://plugin.video.youtube/kodion/search/query/?q=lxdQPMcxz78", folder=False)

    Add_Dir(
        name="孟晚舟案", url="plugin://plugin.video.youtube/kodion/search/query/?q=NOkZeEC5li8", folder=False)

    Add_Dir(
        name="x孟晚舟案全部真相", url="plugin://plugin.video.youtube/kodion/search/query/?q=6_dhlL5z9kw", folder=False)
                
    Add_Dir(
        name="x从英雄到恶魔，环保少女被欧洲清算", url="plugin://plugin.video.youtube/kodion/search/query/?q=ylJyflgz3YI", folder=False)
               
    Add_Dir(
        name="x美国如何印钞收割全球", url="plugin://plugin.video.youtube/kodion/search/query/?q=Fni8y0TJWOg", folder=False)
             
    Add_Dir(
        name="x美国如何控制全球的糧食", url="plugin://plugin.video.youtube/kodion/search/query/?q=xf5GnGpDVFc", folder=False)
       
    Add_Dir(
        name="x中国对抗霸权的终极武器", url="plugin://plugin.video.youtube/kodion/search/query/?q=tlaQ2KONzx0", folder=False)

    Add_Dir(
        name="x中國如何反制美國“剪羊毛", url="plugin://plugin.video.youtube/kodion/search/query/?q=ZNUhwXykgZs", folder=False)
        
    Add_Dir(
        name="x美國房地產次貸危機", url="plugin://plugin.video.youtube/kodion/search/query/?q=Hjtnxq7qZ7M", folder=False)
   
    Add_Dir(
        name="x日本半導體之衰落", url="plugin://plugin.video.youtube/kodion/search/query/?q=fCgyc-XwzI4", folder=False)
   
    Add_Dir(
        name="x貨幣互換,本幣結算", url="plugin://plugin.video.youtube/kodion/search/query/?q=mQAaXQJNVJQ", folder=False)
        
#===============================================================================
#@route(mode='News')       
def 新聞及娛樂():

    Add_Dir(
        name="無綫7:30一小時新聞", url="plugin://plugin.video.youtube/playlist/PLKoXXVQa3yxCbgfZiuq61w9UhEI085PHu/", folder=True)
    Add_Dir(
        name="明報5:30加拿大新聞", url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/", folder=True)
    Add_Dir(
        name="TVBusa - 東張西望", url="plugin://plugin.video.youtube/kodion/search/query/?q=tvbusa%e6%9d%b1%e5%bc%b5%e8%a5%bf%e6%9c%9b", folder=True)
#    Add_Dir(
#        name="多倫多華基主日粵語崇拜講道", #url="plugin://plugin.video.youtube/kodion/search/query/?q=%e5%a4%9a%e5%80%ab%e5%a4%9a%e8%8f%af%e4%ba%ba%e5%9f%ba%e7%9d%a3%e6%95%99%e6%9c%83%e5%8d%88%e5%a0%82%e5%b4%87%e6%8b%9c", folder=True)
    Add_Dir(
        name="香港01", url="plugin://plugin.video.youtube/channel/UCTxyBu9VWUq5LXezXwy_SGg/", folder=True)
    Add_Dir(
        name="香港V", url="plugin://plugin.video.youtube/channel/UCJngFlPRJELUXCwl08PZvqg/", folder=True)
    Add_Dir(
        name="i-Cable News 有線新聞", url="plugin://plugin.video.youtube/playlist/PLIpRvnEkgEeVUPzeLS6JraRwmD3YcWkMz/", folder=True)
    Add_Dir(
        name="ViuTV", url="plugin://plugin.video.youtube/channel/UCHOmxBZKt6uCFqoCvRHnSgQ/playlists/", folder=True)
    Add_Dir(
        name="AMM 亞洲心動娛樂", url="plugin://plugin.video.youtube/channel/UCTsSh20JYvvFlHQ9NYzj1mg/playlists/", folder=True)
    Add_Dir(
        name="MPWeekly明周", url="plugin://plugin.video.youtube/user/Mingpaoweekly/", folder=True)
    Add_Dir(
        name="HK娛樂驛站", url="plugin://plugin.video.youtube/channel/UCGT-CnExA28xbZNX4AYp1tg/", folder=True)
    Add_Dir(
        name="明星周刊", url="plugin://plugin.video.youtube/channel/UCvM04RAO0VeVLoLqRF_MEcQ/", folder=True)
    Add_Dir(
        name="TVB (official)", url="plugin://plugin.video.youtube/channel/UCD2SNRlEjxJODlwaKx-BoRw/playlists/", folder=True)
    Add_Dir(
        name="TVB Anywhere Life", url="plugin://plugin.video.youtube/kodion/search/query/?q=TVB%20Anywhere%20Life", folder=True)
    Add_Dir(
        name="TVB Variety Show 綜藝娛樂", url="plugin://plugin.video.youtube/channel/UCflTI_nq4yyQK3B9UITRJFw/", folder=True)
    Add_Dir(
        name="TVB Food &amp; Travel 飲食旅遊", url="plugin://plugin.video.youtube/channel/UC0FCCZhGfa-BnohSaQjwXGA/playlists/", folder=True)
    Add_Dir(
        name="TVB Mystery Channel 神秘頻道", url="plugin://plugin.video.youtube/kodion/search/query/?q=TVB%20Mystery%20Channel%20%e7%a5%9e%e7%a7%98%e9%a0%bb%e9%81%93&amp;search_type=playlist", folder=True)
    Add_Dir(
        name="TVB Drama – Action WuXia 動作武俠", url="plugin://plugin.video.youtube/channel/UCcadjKOwi1MLRlXb78aGx-Q/playlists/", folder=True)
    Add_Dir(
        name="TVB Best Drama 熱播劇場", url="plugin://plugin.video.youtube/channel/UC-vdzV9IVeIsp0YSCm16CkQ/playlists/", folder=True)
    Add_Dir(
        name="TVB Drama – Comedy 喜劇台", url="plugin://plugin.video.youtube/channel/UC3zIehcse5c7xRdE-baFVfw/playlists/", folder=True)
    Add_Dir(
        name="TVB Crime &amp; Mystery Channel 神秘頻道", url="plugin://plugin.video.youtube/channel/UCYEcRcwNhGS3fAYVrOneFew/playlists/", folder=True)
    Add_Dir(
        name="亞視精選 Drama Asia", url="plugin://plugin.video.youtube/channel/UCCyJ08FwnuhEvsT7QSrWBhA/playlists/", folder=True)
    Add_Dir(
        name="ViuTV World", url="plugin://plugin.video.youtube/kodion/search/query/?q=ViuTV%20World&amp;search_type=playlist", folder=True)
    Add_Dir(
        name="有線電視節目列表", url="plugin://plugin.video.youtube/channel/UC_q7e5XYJB0JDGagcF0KW0w/playlists/", folder=True)
    Add_Dir(
        name="Now 財經新聞", url="plugin://plugin.video.youtube/channel/UCChMBgirwM2nnT3Bbe8METQ/playlists/", folder=True)
    Add_Dir(
        name="八八通", url="plugin://plugin.video.youtube/channel/UCeFbWIhDj_tjTOTe1P3cVHA/", folder=True)
    Add_Dir(
        name="東Touch", url="plugin://plugin.video.youtube/user/EastTOUCHhk/", folder=True)
    Add_Dir(
        name="東周網", url="plugin://plugin.video.youtube/channel/UCsTeCS6s9YoNn2kbQVAgDsQ/", folder=True)
    Add_Dir(
        name="頭條日報", url="plugin://plugin.video.youtube/user/hkheadlinenews/", folder=True)
    Add_Dir(
        name="《危險人物》翁靜晶", url="plugin://plugin.video.youtube/channel/UCqz7Q8gOavVi_ZiGHePvLug/playlist/PLPbX1ivjKJuJ1SO0lDA0o8E80JEywnYl0/", folder=True)
    Add_Dir(
        name="解密工作室", url="plugin://plugin.video.youtube/channel/UCtokllq2j9bzPD6XdcQP9mQ/", folder=True)
    Add_Dir(
        name="Mr. Atom 原子檔案", url="plugin://plugin.video.youtube/kodion/search/query/?q=Mr.%20Atom%20%e5%8e%9f%e5%ad%90%e6%aa%94%e6%a1%88", folder=True)
    Add_Dir(
        name="Just For Fun", url="plugin://plugin.video.youtube/channel/UCfmhgy-jmq_P2m-rSXsEq3g/", folder=True)
    Add_Dir(
        name="娛樂香港新聞透視", url="plugin://plugin.video.youtube/channel/UCLtcC8s-2JJ_5iUxcAO462Q/", folder=True)
    Add_Dir(
        name="明報新聞(多倫多,加國及其他)", url="plugin://plugin.video.youtube/channel/UCuaiQk1XUTc3q4HaL36E_Dg/playlists/", folder=True)
    Add_Dir(
        name="多倫多 WOWtv", url="plugin://plugin.video.youtube/channel/UC5kySUzP0p4Q4Y1rnQLX_bw/", folder=True)
    Add_Dir(
        name="恩雨之聲", url="plugin://plugin.video.youtube/channel/UCgwOhn9ghL2jY5qJEzpzSzw/", folder=True)
    Add_Dir(
        name="Lorey Chan 好書推介", url="plugin://plugin.video.youtube/playlist/PLFkHgNWcmIh6kwEP_rPXfcFKAh__L4cmt/", folder=True)
    Add_Dir(
        name="Mr &amp; Mrs Gao", url="plugin://plugin.video.youtube/channel/UCMUnInmOkrWN4gof9KlhNmQ/", folder=True)
    Add_Dir(
        name="科学声音", url="plugin://plugin.video.youtube/channel/UCUBhobCkTLhgfUNRAgHSYmw/", folder=True)
    Add_Dir(
        name="這麼遠 那麼近-方東昇", url="plugin://plugin.video.youtube/channel/UCaA4Wqk9sf2prQbjoVBtnPw/playlist/PLCGAsPLmtY28brHkRXonte3LDEY7pr_X5/", folder=True)
    Add_Dir(
        name="長命百二歲-方東昇", url="plugin://plugin.video.youtube/channel/UCvdc-bj7Onv5XhEC5z8_JUg/playlist/PLhbhEbEB8P3r7CBSv0zuLCHq7a-AGWU9U/", folder=True)
    Add_Dir(
        name="世界零距離-方東昇", url="plugin://plugin.video.youtube/channel/UCvdc-bj7Onv5XhEC5z8_JUg/playlist/PLhbhEbEB8P3qHxdq__peUJM2aM1zc7YVs/", folder=True)
    Add_Dir(
        name="挑战不可能 Impossible Challenge", url="plugin://plugin.video.youtube/channel/UC3HLhJGcc_0Vse2UncGnxcQ/", folder=True)
    Add_Dir(
        name="御赐小仵作", url="plugin://plugin.video.youtube/channel/UC3PKcYXUAhao3p4kuNS4_9w/playlist/PL9yRf-Ghij3YIJj8j2Y8rEVMWBqGuLD9A/", folder=True)
    Add_Dir(
        name="琅琊榜Nirvana In Fire", url="plugin://plugin.video.youtube/channel/UC0jYsshDZfOBZC9nIJn94Cg/playlist/PLtt_YYUGi1gXRt2XVJZrHDBkZECcfmuAJ/", folder=True)
    Add_Dir(
        name="志雲飯局", url="plugin://plugin.video.youtube/kodion/search/query/?q=%e5%bf%97%e9%9b%b2%e9%a3%af%e5%b1%80", folder=True)
    Add_Dir(
        name="溫哥華港灣TV-粵語臺", url="plugin://plugin.video.youtube/channel/UCQ8YIXrsmi-crzalI8YH64A/", folder=True)
    Add_Dir(
        name="多倫多華基主日粵語崇拜", url="plugin://plugin.video.youtube/channel/UCDkQRGX3nwpyZL1DPxG3sLg/", folder=True)
    Add_Dir(
        name="多倫多華基2023年01月01日主日午堂崇拜", url="plugin://plugin.video.youtube/play/?video_id=zLZ6LtpZfA4", folder=True)

#===============================================================================
#@route(mode='Food')       
def 飲食頻道():

    Add_Dir(
        name="張媽媽廚房", url="plugin://plugin.video.youtube/user/mamacheung/", folder=True,
        icon="https://yt3.ggpht.com/-wuwa4F3RyBE/AAAAAAAAAAI/AAAAAAAAAAA/Yugf9xG3bMc/s100-c-k-no-mo-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="職人吹水", url="plugin://plugin.video.youtube/channel/UCZVmFDfn5WnixrHNf25MeJQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngdVtClUVAO7Y75pirK0vkyHQrpUgi6pas6aolMbj8=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Ricky講煮講食", url="plugin://plugin.video.youtube/channel/UClAIsd91NfxAtdBA0T1h2NQ/", folder=True,
        icon="https://yt3.ggpht.com/EtBef8cHuO8b3eH5qnVzXaGm24ilQB-S9GT0e93oDcHbCNcd-v1YBcs6Wo5wnl34WzikS88riQ=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="海娟美食", url="plugin://plugin.video.youtube/channel/UCxZj1ezvRm0YrHuEaRrZk-A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwni6xI3FJxD95hCyObdwbjU7pad_fEMqgahRLJG5=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="天鵝美食", url="plugin://plugin.video.youtube/channel/UCC_C5EHzBqEyW2Oo0QVZpBw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngJBImcD_Iswboj5zeoaOfwp-eQ_OKzvuw3HwvS=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="越煮越好", url="plugin://plugin.video.youtube/channel/UCDfTo6oLw_ZcVfepgTgD_Kg/", folder=True,
        icon="https://yt3.ggpht.com/-y81UYUbzl6k/AAAAAAAAAAI/AAAAAAAAAAA/tTEP3Td-bsE/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg")

    Add_Dir(
        name="疫境廚神", url="plugin://plugin.video.youtube/playlist/PL6xnAvlFTCA2ibLkS3Uih6mm_2R2mwPHZ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyrcChFpzJm3kpa_inzd0JZARIi_MLD-iiOcQ=s88-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="寶寶滋味館", url="plugin://plugin.video.youtube/channel/UCCrXv19nZEi95F0UZ-LyXDg/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mCZyNXpLJJ7qFs4R4-HGbbd52ht039dhVtgvA=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="Chef Chu's Kitchen", url="plugin://plugin.video.youtube/channel/UCdZ4iamY-QJDEZhBckQpzrQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLReZt_yhB7xT99Cbr_RgY8eRZBzKpyu1yc0jgEq=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="我是马小坏", url="plugin://plugin.video.youtube/channel/UCemTxydROG4XAOS63IY7s8Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSf1m496LAiKmlqC7ISBaMskgtjL5lPsb3eUfZr=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Made With Lau", url="plugin://plugin.video.youtube/channel/UCsIF9vk-I_PV1P-ShDFA84A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSfTJ-pAcCoVDmHHdnBh1yFwt3XvU5wh9hP6QBp=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Da达哥厨房", url="plugin://plugin.video.youtube/channel/UCqpJKjTsQ7FMMeIDPWHGAnw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR9Hf1oTWawwDw2tEVs0wdy86Bezr9z7EVdhk-Qyw=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="天天相見廚房", url="plugin://plugin.video.youtube/channel/UC1SaDcKftNgCW-I34K462yQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzM5s88nOoca9mzVol6NfZkuO3B4M5-hLzznl0FLw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="彩虹小厨", url="plugin://plugin.video.youtube/channel/UC_ReTh__D4ZZeaftHZ0GJhA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwiuRzN72ONc0BvJGDgpudNG_kxEwgDj1HFdGgf=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="大叔食记", url="plugin://plugin.video.youtube/channel/UCaB7FUC5KojXmtjSsdIhJjg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyJQzOjYUljD-r1AfOvS0FGvSOUo_h7tE7jkO1q=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="冯小厨", url="plugin://plugin.video.youtube/channel/UCjVQ9WHx9Lu0kNFaadzDKUg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJw-u19gX9ZDYetoRrf8NGOxekI_VPhwPtK9e-m5=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="田园时光", url="plugin://plugin.video.youtube/channel/UCEkG-qWrskKVdawEFA99koA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyaEmzF6KHsoHErDYOX1kQAlKk4hObwx_uRmw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="明聰", url="plugin://plugin.video.youtube/channel/UCZ3X7wpqu7aKdgDCpyQgDyw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwGfv94DsXVuP2gwG3n3Thf75JRpc65YghDCw=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="點 Cook Guide", url="plugin://plugin.video.youtube/user/dimcookguide/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mDsd7YaWCAZMRgOmdm0EqQ0rH2sYkhR09UFGg=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="Jing Sang's Kitchen", url="plugin://plugin.video.youtube/channel/UCSfcTjOJPBWZvGZe4JV2KDw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJy38vPRESpI1fqxEFU9Iy-GQoAogzQ-dmr_xw=s288-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="李晨曦", url="plugin://plugin.video.youtube/channel/UCE2fFvG2dwKWE3VyD4bkOZQ/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mDrGXfXBZg4OYk_4KdUgZx0NuTr4oh7lEwUow=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="米太廚房手記", url="plugin://plugin.video.youtube/channel/UCcMOC9SMClz663otoRQdObQ/", folder=True,
        icon="https://yt3.ggpht.com/-yXmurm9KMPw/AAAAAAAAAAI/AAAAAAAAAAA/wYFwQJwT4kE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="日日煮", url="plugin://plugin.video.youtube/channel/UCYDVigTy-NE2KyCqVCiJb_Q/", folder=True,
        icon="https://yt3.ggpht.com/-bccB1jY_CJo/AAAAAAAAAAI/AAAAAAAAAAA/gLoRzxLDN0k/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="李子柒", url="plugin://plugin.video.youtube/channel/UCoC47do520os_4DBMEFGg4A/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyukkMJtjdEYwhB4AyQKVVT9Qyy0tQRrN_TVa4R=s100-c-k-c0xffffffff-no-rj-mo")

    Add_Dir(
        name="飲食男女", url="plugin://plugin.video.youtube/search/?q=%e9%a3%b2%e9%a3%9f%e7%94%b7%e5%a5%b3/", folder=True,
        icon="https://yt3.ggpht.com/-UTIHiP9Qp00/AAAAAAAAAAI/AAAAAAAAAAA/a3-HMfQ28wY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="飲食男女-Backup", url="plugin://plugin.video.youtube/channel/UCzSbfRERtKmU7BuU7ZnGznQ/", folder=True, 
        icon="https://yt3.ggpht.com/uuTxKWWmFBMbGuu3RYtxD48nhjPJWRAhoq6y1gwMe5O3sYeEVx3JdWWI_1KBABSX9beYU8f2Yg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="入廚秘技", url="plugin://plugin.video.youtube/channel/UCeqUUXaM75wrK5Aalo6UorQ/playlist/PLQcmGU2t4gsp9DBQlqPWjhUy3kr-OwoM-/", folder=True,
        icon="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="港飲港食", url="plugin://plugin.video.youtube/channel/UCeqUUXaM75wrK5Aalo6UorQ/playlist/PLQcmGU2t4gsphUkfAHyO-jPkR5dbR_1Nt/", folder=True,
        icon="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="飲食籽", url="plugin://plugin.video.youtube/playlist/PLBtDO8vnUizoFs2546t1DhockqKoC0i1T/", folder=True,
        icon="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="真英雄素食", url="plugin://plugin.video.youtube/channel/UCryUWjfZLd3Q_aiq677kuGA/", folder=True,
        icon="http://www.realherokitchen.com.hk/online_lesson_youtube/realherokitchen.gif")

    Add_Dir(
        name="Wantanmien", url="plugin://plugin.video.youtube/channel/UCsy5tUhFYchN8BFdXJtECRQ/", folder=True,
        icon="https://yt3.ggpht.com/-mboGmDJr-c4/AAAAAAAAAAI/AAAAAAAAAAA/gtR0e3mpOQM/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Cooking With May Lynn", url="plugin://plugin.video.youtube/channel/UCAXO1tbQzZ5kOUg3BVl0eYw/", folder=True,
        icon="https://yt3.ggpht.com/-8efBzKvUTuU/AAAAAAAAAAI/AAAAAAAAAAA/2P-lSNWHqOI/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Helen's Recipes-Vietnamese", url="plugin://plugin.video.youtube/channel/UCMmZEL8jV1B61NKAXcyW87A/", folder=True,
        icon="https://yt3.ggpht.com/-lXWCk1JjtDQ/AAAAAAAAAAI/AAAAAAAAAAA/WimPbqGFPHw/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="CookingWithDog-Japanese w/sub", url="plugin://plugin.video.youtube/channel/UCpprBWvibvmOlI8yJOEAAjA", folder=True,
        icon="https://yt3.ggpht.com/-SixK-U1jMsg/AAAAAAAAAAI/AAAAAAAAAAA/n76jU-5KaTk/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Maangchi-Korean", url="plugin://plugin.video.youtube/channel/UC8gFadPgK2r1ndqLI04Xvvw/", folder=True, 
        icon="https://yt3.ggpht.com/-d0KStw-ZOOM/AAAAAAAAAAI/AAAAAAAAAAA/0Im0I-Sr9cg/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="Food Wishes", url="plugin://plugin.video.youtube/channel/UCRIZtPl9nb9RiXc9btSTQNw/", folder=True,
        icon="https://i1.ytimg.com/sh/M0InoNcVcRA/showposter.jpg?v=508859c4")

    Add_Dir(
        name="How to Make yummy", url="plugin://plugin.video.youtube/channel/UCECA8Jct_FI6l2tIBLuK7QA/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mBJ-yJRDVb8aeE-ZQPnFoNbylYCYY77ZpNCvQ=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="Josephine's Recipes", url="plugin://plugin.video.youtube/user/Everydaypossible/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mDf8GRm90gl3axHcLYpGxyIPbcMoJ0NlyWDkg=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir(
        name="Nickos Kitchen-Bakery", url="plugin://plugin.video.youtube/channel/UCffs63OaN2nh-6StR6hzfiQ/", folder=True,
        icon="https://yt3.ggpht.com/-R-PA4kxVgkE/AAAAAAAAAAI/AAAAAAAAAAA/JOEZ7x59uWE/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="BBQ Pit Boys", url="plugin://plugin.video.youtube/channel/UCjrL1ugI6xGqQ7VEyV6aRAg/", folder=True,
        icon="https://yt3.ggpht.com/-w5MgnW1qxCw/AAAAAAAAAAI/AAAAAAAAAAA/ywS4ukZBIaM/s100-c-k-no-rj-c0xffffff/photo.jpg")

    Add_Dir(
        name="十三間燒臘舖叉燒 & 燒肉試食", url="plugin://plugin.video.youtube/kodion/search/query/?q=9YQDeaKUHgE", folder=False)

    Add_Dir(
        name="七間店雲吞麵試食兵團", url="plugin://plugin.video.youtube/kodion/search/query/?q=5XWmpRCgVas", folder=False)

    Add_Dir(
        name="香港人在多倫多", url="plugin://plugin.video.youtube/channel/UCDYgTnWK6sl-YZEDM4jv7fQ/", folder=True,
        icon="https://yt3.googleusercontent.com/7uTaGKgQ9OJ8kOneDfFYHyF9N7vjZT7hhkJvdsowmi0FLmJIoFjmgfT9A0JqqcCKflobHoMWjQ=s176-c-k-c0x00ffffff-no-rj")
         
    Add_Dir(
        name="荷包蛋做法", url="plugin://plugin.video.youtube/kodion/search/query/?q=D2KfDKlDO7U", folder=False)

    Add_Dir(
        name="Gabaomom Cuisine", url="plugin://plugin.video.youtube/channel/UCGhLTa2WPbfSyexW2NqZNNQ/", folder=True,
        icon="https://yt3.ggpht.com/o5qwsZc8vq-wQZeLizAh2MU9mTdD4y063H_r_iU3_5S-26q0Uf_hGHQT1rRyIQu9qJMvzLVv9Q=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="[COLOR red]---面包生胚---[/COLOR]", url="", folder=False)        

    Add_Dir(
        name="Costco 面包生胚的烘焙温度和烘焙时间 (由Costco 提供)", url="plugin://plugin.video.youtube/kodion/search/query/?q=wFvI7mh5vfY", folder=False)
    
    Add_Dir(
        name="11款COSTCO面包生胚的详细介绍", url="plugin://plugin.video.youtube/kodion/search/query/?q=CY401omZakk", folder=False)

    Add_Dir(
        name="Costco面包生胚系列-Cynthia‘s Garden", url="plugin://plugin.video.youtube/channel/PLOkrBCzG0EIcmSKVvi98lKSXPjFaOJYPq/", folder=True,
        icon="https://yt3.ggpht.com/ZnW-0W-AUI0_6sD7PjMt1SGdsDTOUFbEIfknh6RJUv-3Y_J5MmY2cmS-MBHJYIxn0ND9090skg=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Costco面包生胚系列-多伦多生活点滴", url="plugin://plugin.video.youtube/channel/PLCLuUnNhBf70_Apc2rY1sMttsuvACGYa-/", folder=True,
        icon="https://yt3.ggpht.com/m5o1qJ0b2JYg2oGxFWc7ECx8R7SsI46Fgf3-Wu2R08k4Oh2_uu9ruBpnXgCdIFJezjhSE90-Sg=s88-c-k-c0x00ffffff-no-rj")
        
    Add_Dir(
        name="Costco Brioche dough - Rose Cook 로즈쿡", url="plugin://plugin.video.youtube/channel/PLT9_eLrkThxQOkRox_ArQmFFHi_pmfK3k/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQfvzjnc6ByJnpQ8b2-09XfJA1PgIXSoxhc5BMk=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Judy四月风信的美食日记", url="plugin://plugin.video.youtube/channel/PLhQRAPzsDF8zX1czpJRcUm9jCFVTX3QZ3/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSs4xC1t5_3fbKzIFd1CDuOKyFhBE_YlYiJN5C04Q=s88-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="四月风信的走走停停", url="plugin://plugin.video.youtube/channel/UCQiRFAPnHsejTHGgQm0Dk7A/", folder=True,
        icon="https://yt3.ggpht.com/h3NNeOIFbqRaxUw6RTTU2uKuIKnB0OJxQXrnuE4rOVTzEPiF3HriQjcmRrsN2Vj_0S5acrzQtg=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="Costco的面包生胚你会玩吗", url="plugin://plugin.video.youtube/kodion/search/query/?q=-N_FsGspDf0", folder=False)

    Add_Dir(
        name="Costco的面包生胚做中式面食-用面包生胚炸油条炸麻花", url="plugin://plugin.video.youtube/kodion/search/query/?q=9DwxBlluwRM", folder=False)

    Add_Dir(
        name="Costco的无糖夏巴塔面包生胚", url="plugin://plugin.video.youtube/kodion/search/query/?q=nBGyQdXFFKI", folder=False)

    Add_Dir(
        name="Costco的零失败 好玩好吃又省钱的面包生胚", url="plugin://plugin.video.youtube/kodion/search/query/?q=WgWAF1N6RMM", folder=False)

    Add_Dir(
        name="Costco的面包胚做出来的面包", url="plugin://plugin.video.youtube/kodion/search/query/?q=B5ZMiJCIa5s", folder=False)

    Add_Dir(
        name="Costco的Easy Ham cheese bread ", url="plugin://plugin.video.youtube/kodion/search/query/?q=NoAT3v7LSg8", folder=False)

    Add_Dir(
        name="Costco的Frozen Baked Goods are A Breeze", url="plugin://plugin.video.youtube/kodion/search/query/?q=0gqGOR-Pwjg", folder=False)

    Add_Dir(
        name="叉燒包-I am Ma Xiaohuai", url="plugin://plugin.video.youtube/kodion/search/query/?q=3qReozpFwhw", folder=False)

    Add_Dir(
        name="叉烧包的做法-Da达哥厨房", url="plugin://plugin.video.youtube/kodion/search/query/?q=udq9v_Osaho", folder=False)

    Add_Dir(
        name="琥珀合桃", url="plugin://plugin.video.youtube/kodion/search/query/?q=txRWcIcThrg", folder=False)

    Add_Dir(
        name="氣炸窩琥珀合桃", url="plugin://plugin.video.youtube/kodion/search/query/?q=ibiremo1ExM", folder=False)

    Add_Dir(
        name="腰果怎樣炸才會香脆", url="plugin://plugin.video.youtube/kodion/search/query/?q=abAayOrNwGo", folder=False)

    Add_Dir(
        name="氣炸窩腰果", url="plugin://plugin.video.youtube/kodion/search/query/?q=E2rUMKzGeKU", folder=False)

    Add_Dir(
        name="潮式炸花生", url="plugin://plugin.video.youtube/kodion/search/query/?q=0ofnmelLfA4", folder=False)
  
    Add_Dir(
        name="杏仁酥 Almond Puff Pastry", url="plugin://plugin.video.youtube/kodion/search/query/?q=uNtrZ248OPQ", folder=False)
   
    Add_Dir(
        name="簡單速成蝴蝶酥", url="plugin://plugin.video.youtube/kodion/search/query/?q=iYt3d_L8ABQ", folder=False)

    Add_Dir(
        name="酥皮點心", url="plugin://plugin.video.youtube/kodion/search/query/?q=ziJENa_9-Jo", folder=False)

    Add_Dir(
        name="Puff pastry ideas for a party at home!", url="plugin://plugin.video.youtube/kodion/search/query/?q=gM_thxhU3Ho", folder=False)

    Add_Dir(
        name="酥皮蛋撻-天鵝美食", url="plugin://plugin.video.youtube/kodion/search/query/?q=2Gx8fRmeB9k", folder=False)
  
    Add_Dir(
        name="酥皮蛋撻-wantanmien", url="plugin://plugin.video.youtube/kodion/search/query/?q=Ndlv4ZxnRSs", folder=False)

    Add_Dir(
        name="蒸蛋糕", url="plugin://plugin.video.youtube/kodion/search/query/?q=W7vMIj1PuFA", folder=False)

    Add_Dir(
        name="25 ways to mold homemade buns!", url="plugin://plugin.video.youtube/kodion/search/query/?q=F9Ahp96YOaA", folder=False)

    Add_Dir(
        name="廣東雲吞", url="plugin://plugin.video.youtube/kodion/search/query/?q=tmeBKK-sJTg", folder=False)

    Add_Dir(
        name="香滑豆腐花-電飯煲做法", url="plugin://plugin.video.youtube/kodion/search/query/?q=ACPp3XlROms", folder=False)

    Add_Dir(
        name="煲紅豆沙", url="plugin://plugin.video.youtube/kodion/search/query/?q=HiOOYP67NNI", folder=False)

    Add_Dir(
        name="白果腐竹雞蛋糖水", url="plugin://plugin.video.youtube/kodion/search/query/?q=eopsB8F_t-o", folder=False)

    Add_Dir(
        name="椰汁年糕 簡單易做版本", url="plugin://plugin.video.youtube/kodion/search/query/?q=X2WciiObtDE", folder=False)

    Add_Dir(
        name="香酥烤年糕", url="plugin://plugin.video.youtube/kodion/search/query/?q=f-4j1llTudg", folder=False)

    Add_Dir(
        name="〈職人吹水〉砵仔糕/ 零失敗/簡單做法", url="plugin://plugin.video.youtube/kodion/search/query/?q=nBAnOuuRRaM", folder=False)

    Add_Dir(
        name="砵仔糕", url="plugin://plugin.video.youtube/kodion/search/query/?q=FkMlM9UTHjc", folder=False)

    Add_Dir(
        name="麻辣紅油", url="plugin://plugin.video.youtube/kodion/search/query/?q=eopsB8F_t-o", folder=False)

    Add_Dir(
        name="9种经常做的空气炸锅食谱", url="plugin://plugin.video.youtube/kodion/search/query/?q=wePXiPnYNNY", folder=False)
           
    Add_Dir(
        name="HONG KONG STYLE CHEE CHEONG FUN", url="plugin://plugin.video.youtube/kodion/search/query/?q=V5J4GBdZUC8", folder=False)

    Add_Dir(
        name="[COLOR red]---肠粉---[/COLOR]", url="", folder=False)
        
    Add_Dir(
        name="牛肉肠粉 /米浆的比例", url="plugin://plugin.video.youtube/kodion/search/query/?q=lrnJkvUikTI", folder=False)
          
    Add_Dir(
        name="張媽媽廚房 - 腸粉簡單做法", url="plugin://plugin.video.youtube/kodion/search/query/?q=PoQA0lu3aNs", folder=False)
         
    Add_Dir(
        name="酒樓靚腸粉", url="plugin://plugin.video.youtube/kodion/search/query/?q=5mHsmj2t_zM", folder=False)
               
    Add_Dir(
        name="街檔蒸腸粉豉油", url="plugin://plugin.video.youtube/kodion/search/query/?q=vOH6u25G_Rg", folder=False)
            
    Add_Dir(
        name="腸粉 沙河粉 腸粉醬油", url="plugin://plugin.video.youtube/kodion/search/query/?q=xEDyP1e5H1s", folder=False)

    Add_Dir(
        name="Steamed Rice Noodle Rolls 3 Ways", url="plugin://plugin.video.youtube/kodion/search/query/?q=oghIp0i0Y-Q", folder=False)

    Add_Dir(
        name="簡易平底鑊做腸粉", url="plugin://plugin.video.youtube/kodion/search/query/?q=TX6PCkSQeyc", folder=False)

    Add_Dir(
        name="腸粉 首創最易做法", url="plugin://plugin.video.youtube/kodion/search/query/?q=3KVQtUmkBxI", folder=False)

    Add_Dir(
        name="蔥花蝦米腸粉配特製甜醬油", url="plugin://plugin.video.youtube/kodion/search/query/?q=ARxgDRiaoU4", folder=False)

    Add_Dir(
        name="Microwave Mushroom Cheung Fu", url="plugin://plugin.video.youtube/kodion/search/query/?q=yQ027MajVSM", folder=False)

    Add_Dir(
        name="［簡易食譜］自家製脆皮爆多汁燒肉/燒腩肉", url="plugin://plugin.video.youtube/kodion/search/query/?q=8EOr3E-3ctc", folder=False)

    Add_Dir(
        name="猪肉直接放酱油中泡2天，味道比腊肉都香", url="plugin://plugin.video.youtube/kodion/search/query/?q=26jHlrk55XA", folder=False)

    Add_Dir(
        name="生炒糯米飯", url="plugin://plugin.video.youtube/kodion/search/query/?q=HK2WFo5OC04", folder=False)

    Add_Dir(
        name="9款懷舊小食", url="plugin://plugin.video.youtube/kodion/search/query/?q=bC2_8mTNX14", folder=False)

    Add_Dir(
        name="牛奶小油条", url="plugin://plugin.video.youtube/kodion/search/query/?q=uG9bHIaD4P0", folder=False)

    Add_Dir(
        name="鱼汤煮白", url="plugin://plugin.video.youtube/kodion/search/query/?q=-Vi0s-u-SM0", folder=False)
  
    Add_Dir(
        name="泡發乾香菇最忌直接加水泡，教你飯店不外傳技巧，2分鐘全泡開", url="plugin://plugin.video.youtube/kodion/search/query/?q=LynJ_FmijzE", folder=False)

    Add_Dir(
        name="红豆黑豆还是绿豆，煮前多加一步，10分钟全煮烂", url="plugin://plugin.video.youtube/kodion/search/query/?q=SVXUpfAtFTY", folder=False)
              
    Add_Dir(
        name="〈職人吹水〉KFC/ 白汁薯仔雞皇飯/ 零失敗", url="plugin://plugin.video.youtube/kodion/search/query/?q=MYl39TD7dBE", folder=False)

    Add_Dir(
        name="Chef Wang 美食作家王刚", url="plugin://plugin.video.youtube/channel/UCg0m_Ah8P_MQbnn77-vYnYw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRQnGQ8ot-NyajS6UnoSjxMlp61fCvtAM_aeRcy=s176-c-k-c0x00ffffff-no-rj")

    Add_Dir(
        name="留日生活", url="plugin://plugin.video.youtube/channel/UCSno2IYkzCAQTqIPoZG6cDw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzxcAEfYJcIOWmRBObSZFIrG_Kj9NQHvebVJK1R=s176-c-k-c0x00ffffff-no-rj")
        
#===============================================================================       
#@route(mode='Miscellaneous')       
def Miscellaneous():        


    Add_Dir(
        name="[COLOR red]---Audio Video---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="The Charming Geek - Best Dolby/DTS Demo", url="plugin://plugin.video.youtube/channel/UCwRYshoJboHRsc3wFOVzm2Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-hubmug1hcFknNQNEKGHTAr22oO9bV0bMU2IOX=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Digital Trends", url="plugin://plugin.video.youtube/channel/UC8wXC0ZCfGt3HaVLy_fdTQw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTzoBCJUdQAuD3ZwXlnV9UtIpsAlMlIM0KzXUSEXA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Surround Sound Test", url="plugin://plugin.video.youtube/search/?q=surround sound test", folder=True)

    Add_Dir(
        name="[COLOR red]---Computer---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="零度解说", url="plugin://plugin.video.youtube/channel/UCvijahEyGtvMpmMHBu4FS2w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTzoBCJUdQAuD3ZwXlnV9UtIpsAlMlIM0KzXUSEXA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Loi Liang Yang - Hacker", url="plugin://plugin.video.youtube/channel/UC1szFCBUWXY3ESff8dJjjzw/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJV4RHEEaWD-Xm54hvHve-Y0oc761hykTRzOR9QL714=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="AOMEI - Computer & Phone", url="plugin://plugin.video.youtube/channel/UCPgX_gJiOkb54QacjjKGdNg/", folder=True,
        icon="https://yt3.googleusercontent.com/H3i-QPtDodOdt1g3_jYiXS9MLoIcKLZWrnPg6dImjomHLb4gx0cM7gML9uYHtZ8QsfpKH9Uj=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="techie zero", url="plugin://plugin.video.youtube/channel/UCI-JFHOA07eEIQeRbf-FDNQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-MX2e5bC1JIUm_W9vWTubQCkc5SBVMhPgiOA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Solvetic English", url="plugin://plugin.video.youtube/channel/UCkVkmxeHaBk77kAWEzopCBw/", folder=True,
        icon="https://yt3.ggpht.com/b4_d40Mgoc73qcTYX4WtWU2s494ZQJUm61qk3MEWITqNqeMorz1CVVdKkN1h-nliYRAsKc1-XQk=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="小芃路子野", url="plugin://plugin.video.youtube/channel/UC5QUaLoGxpEUU-fG6_k7AJQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-0CHyCveJoLYpdrhftg-Dqt4c4ECNlaoSjs_5w=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Professor Adam Morgan - MS office & Windows", url="plugin://plugin.video.youtube/channel/UCML68AtcFhcKebYCRbYepeQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu8-hUxFtESj85qBSmBGtDtG7TS0cFJl4ZrnYAaq0Q=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Tantrum Dev - Kodi Addons", url="plugin://plugin.video.youtube/channel/UCs_Ci64Q3vz8h8rBhOkPMYw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRABKVNaF1cUI__KtjUo8UCcx_9KoOEKDspjglo=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="UniqueTutorials - Smart Phone/Computer Technique", url="plugin://plugin.video.youtube/channel/UCGhkRoks9q0Ms7cxpu5gtww/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_37wUbR10SM-yLK4d7-xAXNwrWtlY8irZCqpEa=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="CrazyCracker 瘋破解 - Crack & Hack", url="plugin://plugin.video.youtube/channel/UCxwVNOIPp-jq-jbgFVQNPMA/", folder=True,
        icon="https://yt3.ggpht.com/ltUoIsEgau0CExtxOTaYK1gVgx4wn3wml8gWEHFM0q3AubsJmB4fh5nwcFl91cnWRFICZ4tjsA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="PAPAYA 電腦教室", url="plugin://plugin.video.youtube/channel/UCdEpz2A4DzV__4C1x2quKLw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJw-rGE-JFjGmE8J1pAzVlIE8u0LUTo1_8UU5vRIqQ=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="大培科技分享", url="plugin://plugin.video.youtube/channel/UC8MnkBkk4P1PLqxe2Zrwobw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRCnnuwEIQaCsJBHz3W4mRDCM6es0k7mp6dQqyp=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="老郭种树", url="plugin://plugin.video.youtube/channel/UCj7hwd3wEYYp5l9LRPAo7YA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSOMhVtKVFtNEHH0PF4foX0zjTRZdVhmTIMy2rj=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="走歪的工程師James - Coding Github", url="plugin://plugin.video.youtube/channel/UCyBbA05rNQU0Agbv_1Yqx0w/", folder=True,
        icon="https://yt3.ggpht.com/qYMuwcLTlRrT3nrlGQvCJdCxIBz5Mf8ygppAVjGY0lifN5v6ijdhVzM6TQCO84Bp8zB9Hna0=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---FireStick---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="FireTVSticks", url="plugin://plugin.video.youtube/channel/UCxb2ktvayRwCIN9kBKgxUiQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxi9ggYEtqnO5ed9FubmcgeBQHJp6y_cLWdDSdwVw=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="看电视app分享", url="plugin://plugin.video.youtube/playlist/PLOq1ZaZRnBYJw8lQWRjRYMK1y8-6ESI4b/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjrQiJcueoyJcxUoGO1E6juJVdWbiDOkJ4TswvSVQ=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="向北", url="plugin://plugin.video.youtube/channel/UCe-TLzlrBZrJCavjQHll3lg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9VPpcKhFI8twuPWyJ-mvF69n9UaVdQlGHNpF_g=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Chan hang yan", url="plugin://plugin.video.youtube/channel/UCrRbZnJWUEAPHX19d4mIpRA/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJVVufqw0yYTcceUB30V9HJhV59K-d7Wmq5qGXqtSQ=s176-c-k-c0x00ffffff-no-rj"
)


    Add_Dir(
        name="求索科教", url="plugin://plugin.video.youtube/channel/UCZEQRUTRRZwryw0cOmXB1_g/", folder=True,
        icon="https://yt3.ggpht.com/fmKsB82F_6qnkA7VZgPVELD6mXD-qK1pEIkHRQfUE0Q74CcypQb8-IWyrPPk3zLPrvn5rRIPkYg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Technology Connections", url="plugin://plugin.video.youtube/channel/UCy0tKL1T7wFoYcxCe0xjN6Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnheuQU95snftEbYcf33Q34EStPI2Gy0CemqZ9Da=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="佑來了", url="plugin://plugin.video.youtube/channel/UCWYa0v8bpGyYr0ycqGXifVQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS9kpB85XpUZhAVYPPT4zXVUpRac1MBDGU89zyp=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="AL technology 阿雷科技", url="plugin://plugin.video.youtube/channel/UCiLtBk8dChPldOho8uTZHhQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQd7hoVqg47Uo6k3fsMgknWJINeuU2STTo8mVXtVw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="AL technology 阿雷科技 B站", url="plugin://plugin.video.bilibili/up/256643605/1/", folder=True,
        icon="https://i1.hdslb.com/bfs/face/9201477687ac1450cdff7e39643ee40c25321631.jpg@128w_128h_1o.webp"
)

    Add_Dir(
        name="The Action Lab", url="plugin://plugin.video.youtube/channel/UC1VLQPn9cYSqx8plbk9RxxQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTEMkgbhpderM6PFqBf3RtlIjo1A60CGRv6Iav0Ng=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Dacha craftsman", url="plugin://plugin.video.youtube/channel/UC5Pfa1bbDlktHCsoCJnpklw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9FhAZyYsJ36OOnuUQ-MFReiBjh36ISw3Nb5D2wNw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Good Advice", url="plugin://plugin.video.youtube/channel/UCDEDgWXEotFLagRt_X1lHYQ/", folder=True,
        icon="https://yt3.ggpht.com/de-S8W9niPi0fLHBGUKRLZ8ItSCnhl6F0ZeSJiCu2ykuZfLn9HJ2HYEX-IJ3bkQocrukO3M2qA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="5-Minute Crafts", url="plugin://plugin.video.youtube/channel/UC295-Dw_tDNtZXFeAPAW6Aw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnicrG9RNUfo_lxIwy179qaAChmgaWrOs6Y4_r7CKg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="5-Minute Crafts 2", url="plugin://plugin.video.youtube/channel/UCuGS1iJpM_4ZYFp62mia2xQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSaYA2qh9cD-eUPu0HPDTGS81Sse10Z3joFzLfnyA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Simple Ideas", url="plugin://plugin.video.youtube/channel/UCM-zWEs-pN9NqeXauahg5CQ/", folder=True,
        icon="https://yt3.ggpht.com/N31GCrkbB14P2gv_5Sx_M-uhmYQ1kay37t0Bepr6cBUc5MTAQWtLwe_Oiw5zexjUpmQSRvynHBQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="New creative DIY", url="plugin://plugin.video.youtube/channel/UCcaJF8zvn8x_EK9vwyGM0MQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSYRFO6gJcUARCu58YOspNDBLNEF8Q1IxMvcqUmsA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="妙招小哥", url="plugin://plugin.video.youtube/channel/UCmEEFYkEfg6HvUTCvnJkU4g/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJysb9YWUtF22f_1c5UEozQ4LfXC0bi9cGB8=s288-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="我是佐藤SATO", url="plugin://plugin.video.youtube/channel/UCrIwHvOaoxQJMgUzx_4Fvvg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-J8EkIccYIvwlhROGMc1frEevALr3O1AnuQyznxcw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="三分日记", url="plugin://plugin.video.youtube/channel/UCauXEcNoj2ZRufqCRERPt6g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQnBJ4FNKQ3t51ZwlXNPDj6CFdbAAjlOIhS9Bn2=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="The Maker", url="plugin://plugin.video.youtube/channel/UCIEzRynZsewtFjUTxtRbyUA/", folder=True,
        icon="https://yt3.ggpht.com/LtXQfrGUJvLwruGl5VpOg9PiY4hzn1veIfnyLD2tg4H649aMF57GuvUzxFbC7Vpb5Do0llW_=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Picking Locks---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="LockPickingLawyer", url="plugin://plugin.video.youtube/channel/UCm9K6rby98W8JigLoZOh6FQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu8YeGyK0ikeFP32Mk8S3ZNFAXKJcd6aSWeWU5h9qg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Swynndla - Picking Locks", url="plugin://plugin.video.youtube/channel/UCldWdyS8THRro8j31Khe_-w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_SCLLV8cdRsFh5xLRIiD1sAEqrIKc50MY5n2ja=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="BosnianBill - Lock Lab", url="plugin://plugin.video.youtube/channel/UCp1orOGJwZvjLAvckyxC4Nw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9-1QYC51INf803BLkS4AFVwRBNVgoJXYbURUmC0Q=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Potti314 - Lock Picking", url="plugin://plugin.video.youtube/channel/UCSCUS_rVVks_NKookFW9m4A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_ypuy-V27IUW_NUUk3AAyMGdhOBMZ_w-IW6xmHDw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Car Repair---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="小韩修车", url="plugin://plugin.video.youtube/channel/UCtvT3w5zTR9U70wtmOSbkMA/", folder=True,
        icon="https://yt3.ggpht.com/T6WqeNqSKxM1EEtGkyKx7jABQFjohHIOApLLNdIg8IB6zZ6JItK1DUFiM4w4gP0Dv3enxGFc4w=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="ChrisFix", url="plugin://plugin.video.youtube/channel/UCes1EvRjcKU4sY_UEavndBw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu92GYzxEue9t34rrJuzhCFpv2xCM41sLsogcqbHHw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="聪哥说车", url="plugin://plugin.video.youtube/channel/UCldHaRLZQevOi6m2TCHSBGw/", folder=True,
        icon="https://yt3.ggpht.com/4JpB9OmsHMauu0CboZREbtp3Wu51iuPHVMMIdWW-x9SDqpe8Nr7O0d3Z6dqpdgUkd0G7sfY1EA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Home Reno & Fix---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="Everyday Home Repairs", url="plugin://plugin.video.youtube/channel/UCw1V3VC3xAzL66X4VwqaKlg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRYc5mQ6g96bFlVV4hZFdlb3DARnlnP0Hcowox3fg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Fix This House", url="plugin://plugin.video.youtube/channel/UCjhwaa5Ufj-l_5JGFwfp98Q/", folder=True,
        icon="https://yt3.ggpht.com/1J0rt2AGLPLCVkkYUqfM-vnTdTod23D5wesiL9Q8eyhYFP6EY-ss5cdQdNF1Qk3mqd_AmCwtRw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="HUMA LO Home Reno", url="plugin://plugin.video.youtube/channel/UCqu4g9MiJXK-khmKyOUEnPw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTnVwefCM70NXPqt8xiGWlPdhNUwXNCyWzawZn1=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="KENDI的DIY频道", url="plugin://plugin.video.youtube/channel/UCA1sPlgcxIZBMcRF7Nzsk-A/", folder=True,
        icon="https://yt3.ggpht.com/QHj7Bzu6RlJqSz_vBVf3S32oRY02pLfYvpjMHkCtsvuvKkeD0NU1-KItll8S7ifUkIISIvUOgQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="KENDI的副频道", url="plugin://plugin.video.youtube/channel/UCp6W3DbXT-xlLmCk_dA3yBw/", folder=True,
        icon="https://yt3.ggpht.com/021lNUHXPZFmbhoNawMOcyRzzuRM_p4g2rgODlK15XI_GkaBka-O3epYXTPZCdJ7d04zweFHInA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Ding's Workshop 老螺工坊", url="plugin://plugin.video.youtube/channel/UCNv6Hiouq_wBVbJIZOe9tvw/", folder=True,
        icon="https://yt3.ggpht.com/JOAa0FuvEUVqJL6kJgRzXCC_zImHkSz_adISaF0MDW8e9g-8KR5-kfGrdr48B-IKE31u1ETza78=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="建房子的豆壳儿", url="plugin://plugin.video.youtube/channel/UCTC3LNRjoJ8WfalrNoyMh1w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRdHbBeLf9MBz_mZ1fQyuCXhayPYOdazGbkglEt=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="DIY君", url="plugin://plugin.video.youtube/channel/UCpyqIO7QrW1Zz2jaJ7rtDAQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQrRetsNFlvoJr5LQZto957--v_T83gvLFMuCUYTg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Lawn Mower etc---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="六哥维修 - Drills Grinders etc", url="plugin://plugin.video.youtube/channel/UCFzw0HGCEurj7J1M1Vklmiw/", folder=True,
        icon="https://yt3.ggpht.com/3rYkfo-7YeD700OBrQz8-Mqxjzn7bvyFSVLWnhLyW3K8FgulU1utrPUkS56xAZxX2t2Sz4uXpMg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Home Garage", url="plugin://plugin.video.youtube/channel/UC7PchZysH2AyW8skCPml7iA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-0-ofuC3Kf1rkcdJe1mf5JHLAIiZxArLboAYfu=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Sewing Machine Repair Guy", url="plugin://plugin.video.youtube/channel/SewingMachineRepairGuy/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngCXY1TwBEmHkkB76YrTf-t3rsVIBY-7s2zQ6EO=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="LKs OFFICIAL CHANNEL", url="plugin://plugin.video.youtube/channel/UCMpQA4MMSpl_bMvNTZ5rODQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQpVDlm7VyhMEXUy4lfrgOEMCjPE3DzL7nO6bBxkQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="茶里", url="plugin://plugin.video.youtube/channel/UCJmCH6G1fnRf3CTJk-PYHMg/", folder=True,
        icon="https://yt3.ggpht.com/dT0pK5tTGq4nZG07omGERAHAkTGOj0-9UBGlIhmz-sarThkqESQjBtvf0RVp0-9HOTH5ewQ1=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="FreeDream Macau", url="plugin://plugin.video.youtube/channel/UC97RPPL3EYe9PUypZBzXI_g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRirbZFjJh_qV1XrJzOb7GI8y68YgOlJ9uQ9Fgz=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="糖糖微笑社", url="plugin://plugin.video.youtube/channel/UC9dvBnuCL8hrKEoOIjWumFg/", folder=True,
        icon="https://yt3.ggpht.com/fc2RtH1klZpPmeDnqG-7sQn7Oo3mBjs4OrtnaqDgMgJAr45PuxMTxDOD77qa1YgyI3oZEOv3=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="腹语撩妹", url="plugin://plugin.video.youtube/search/?q=腹语撩妹", folder=True)


    Add_Dir(
        name="住加男人CanMen", url="plugin://plugin.video.youtube/channel/UCppf_ukZPzSZkjRdVm10Iuw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzEV6QGMzbjpYYf9sQ6KO5JEXvR6LjUZFfLrtBR=s144-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Coco哥", url="plugin://plugin.video.youtube/channel/UC_vZsUCJrwYrbIRPHacAS_Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-tHfWBLRAAipLQrU0WatakNLbLc29NWS9keA55-Q=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Michelle Garden 美國生活", url="plugin://plugin.video.youtube/channel/UC_RogBtQG4YFrhcj6Mrt-cA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyOdA35jKmtLt7WVOqG051B-qrZaa8yGxvvGl2a5Fw=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="MM - Mill MILK", url="plugin://plugin.video.youtube/channel/UCa1d9ZXVMU0BZQRXZHt8Cpw/", folder=True,
        icon="https://yt3.ggpht.com/TAeR8ys4VJLDLaz9DY_RwQngwjljD7Tj8yhcQ7zlPPJIJHXjgDedcWK7Kn3E1fByrQmf-mH5pw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="叉雞", url="plugin://plugin.video.youtube/channel/UCB3pBfnruGVgbP1r5Ya2CEg/", folder=True,
        icon="https://yt3.ggpht.com/kbxnlbPCiJgWoAwCLduSRi7h6w09q7dXTLeUZGvoDQfcWfgvBGfHGsnCeSCqMlYcu7yJd9ZO7g=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="大郎水口炒粉姐", url="plugin://plugin.video.youtube/channel/UCx4dMNXDKlS6E0rqFYutCBg/", folder=True,
        icon="https://yt3.ggpht.com/dv3TseS1OjUugePrQreJPba51QJ5bCy76JBP_v_Nri1kyAxQZ1kpfIVo0bVDKbf1J4H9PAz_kVs=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="肥C拉阿May - Fat Lady May", url="plugin://plugin.video.youtube/channel/UCdO_eUKn-tVZzQnHCI-7KYg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-mN-Vj5ltiXTetw-TH_1rz--AJdiSxw0oqUX0g=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Price.com.hk 香港格價網", url="plugin://plugin.video.youtube/channel/UCUEJok-GiWaGlv5nIPwk-GQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSEh2ggidS2SDcosOETGJ-iAsOq9DQIMME_atlc=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="GadgetGang HK", url="plugin://plugin.video.youtube/channel/UCrZG5sGryxwgSDQSlHgmZTw/", folder=True,
        icon="https://yt3.ggpht.com/jDDEB9S7QGJBtOL7gGpJv84UrfECFed7ma8fz27Kp1M_Yemysu3V3wKFm4AIo6IUKI_4qlIv=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="鴨寮街/桂林街電話上網儲值卡行情", url="plugin://plugin.video.youtube/channel/UCviKWPe2qYMyfZVq8AJfipg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxRjjE_9ePom3J8YFBZE-gJn1F-EDTZVapIFl8G-g=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Future Now", url="plugin://plugin.video.youtube/channel/UCI_O1FM_rKEU8PNGYwK19cQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTmoRc9QkzXJMNrAc0ZIMmk7FbxYCGjxn43ZUeg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Nick Johnson-Best & Worst States To Live In America", url="plugin://plugin.video.youtube/channel/UCEBY1LNHPiJ6AE0B1wxfNHw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQR3cGmtk5_bPm92mRsDvBe5epMPS96mYaySFmVzw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Statistics---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="Stats Media", url="plugin://plugin.video.youtube/channel/UC10X_pdYvhTG6YE7CnJeF7A/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJy7aJzDJhRYocfhQ9dFuhxzDtVpbvpZTPf5VZWjCw=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Animated Stats", url="plugin://plugin.video.youtube/channel/UCLwluonD3CuhTaVLlmSQ-VQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyQ_R3exrrAanh5p02zEEMdDCMW_QzfCit93MRp=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="WawamuStats", url="plugin://plugin.video.youtube/channel/UCy0dKy89rZFR8OCbAT69wcQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJydU71bDOcoa0LHxNiPH-E5lzBqYR3Ocbk1YUsdRA=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Latos Charts", url="plugin://plugin.video.youtube/channel/UCUp2zhqu3tRjmhXbtgyeBXA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyYfB5iIUX_B_qpF_R9hcnJvpD1dvyBjAceIH8T=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Data Is Beautiful", url="plugin://plugin.video.youtube/channel/UCkWbqlDAyJh2n8DN5X6NZyg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzmXkZPeo4QwdjE8QF5QjS4F6RnztqlaDHpjNou=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="RankingTheWorld", url="plugin://plugin.video.youtube/channel/UCFRoQ_PH8Ho5bUQb443PPqw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzBehUfazonl-y-A-7byEZdNkmhR7nfrOQ0-vinUQ=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Gabriel St-Germain - Shopify Dropshipping", url="plugin://plugin.video.youtube/channel/UCqw27ZfS4aWdNhP1MDOldPA/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l7_w0A7K9qIgURPOEGZx3IsOUSuU9o0iaeta9A=s288-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="LittleBoatTan小船-How to Youtuber", url="plugin://plugin.video.youtube/channel/UCsQpF-hfgzcpPMq2hF59TXQ", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJz8nkcF7L30bcFzniZ-VSL7fK5e48tyY0hT-Fn_sA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="SmartTravel1", url="plugin://plugin.video.youtube/channel/UCIuNPxqDGG08p3EqCwY0XIg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhQ4UlO1NSXYbsXyS2ip1C-6tnOLHFn8RlDo5ArTA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Rafa Goes Around!", url="plugin://plugin.video.youtube/channel/UCqV2FpeI5TeOQhnY3cXc9Ag/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSOKiCVDR_xjLP75cvdF0Uti-FO6pQ507DT_ZxshA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Ping Pong---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="乒乓球示范讲解", url="plugin://plugin.video.youtube/channel/UCLFr_qiUN1D4zwFEHsImZpw/", folder=True,
        icon="https://yt3.ggpht.com/2h9iZlOAmjtvS3qi6nbVCC5SVOPBM4CmAD7VvFIxLu3BpnByXhmsUONX6eH6y2RHYNmfshRR9Q=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="KCCC傑夫 - Table Tennis Skills", url="plugin://plugin.video.youtube/channel/UCl692PMFEZ_-Vxs7u6WLS6w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR_AsKS1DoYlyzt48VS6fNL8tOA420rWJ7A8ydQ-A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Martial Arts Defend Yourself", url="plugin://plugin.video.youtube/channel/UCcbsmx3jgDUTeTn78cEmXpg/", folder=True,
        icon="https://yt3.ggpht.com/1D2kEBdE58BYIaXN4Eo_t6k4G9YUT3q82MsLG2SoJ3Y6-w0fYGxiqoF6qsXopy-c7KnsV8cZUg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Medical---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="LoseTheBackPain-Tennis Elbow etc", url="plugin://plugin.video.youtube/channel/UCCn4crfPxpYDzu_sPONugEA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRTLgIfS496VWZU3cGdaMxzUtYUA2KV-x6Dotnl=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="AskDoctorJo-Piriformis", url="plugin://plugin.video.youtube/channel/UCjdxelARHGq3-3dN_neMOAQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRDiw-1RdxiPuE5f1FPqOgRqw2AUAApg3OKTaMH=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Dr. Eric Berg DC", url="plugin://plugin.video.youtube/channel/UC3w193M5tYPJqF0Hi-7U-2g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTPNKQaNreGaliJXlCYYkJVcnCZHsymUl2HUALo5A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Products---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="先看评测", url="plugin://plugin.video.youtube/channel/UCf4YPrRO2clAH-zJcomJaGw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_DeCc2FHzu4iaGBeqK7AHXdxbgVinjX95sq4eV=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="AK‘s Tech Studio", url="plugin://plugin.video.youtube/channel/UCZVThl_MRppEdGUPGjXSSdg/", folder=True,
        icon="https://yt3.ggpht.com/TsQ7k_W0ZBiYUxilCjRfdGTXZXdyttFcUTtu7DQ25LF5SrXGyixlZLK5Z9fjroZgJBQxqoWF=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="思思聊名品", url="plugin://plugin.video.youtube/channel/UC7ITYRko5aT5bWQt3JEpW-A/", folder=True,
        icon="https://yt3.ggpht.com/jlbSP4lJ-a7xA1lMXRXUlBO32VlQ4DaVXgDU_MzM5omxyHaRWp78x9YzvjmXrgrEAOdALbtW=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Immigration---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="澳洲Henry", url="plugin://plugin.video.youtube/channel/UCShBd7dtD2H5Ue83jJTo1DA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu85TrvtmJF-89gIJX9rwkMqj2PfmFImNwgYno6ltA=s800-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="容易工作室 - 回到內地生活", url="plugin://plugin.video.youtube/channel/UCtR5x6K4-45vXy1b5FBlNVg/", folder=True,
        icon="https://yt3.ggpht.com/SUo0ZsdpnkPy3kcHEMHMybZAZB0nBWMRBUvToeoI2iBi-iO1ydqRvL9-fdtFivbdwuW-wCtOJg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="How China Conquered The Keyboard", url="plugin://plugin.video.youtube/kodion/search/query/?q=hBDwXipHykQ", folder=False)
    Add_Dir(
        name="How to Move a Lost Off-Screen Window Back to Desktop", url="plugin://plugin.video.youtube/kodion/search/query/?q=qpnQNgmXJGU", folder=False)
    Add_Dir(
        name="安裝 Google 免費作業系統安裝教學（Chrome OS Flex /CloudReady）", url="plugin://plugin.video.youtube/kodion/search/query/?q=Nc3bTBA4meo", folder=False)
    Add_Dir(
        name="Chrome OS Flex /CloudReady", url="plugin://plugin.video.youtube/kodion/search/query/?q=Nc3bTBA4meo", folder=False)
    Add_Dir(
        name="Google搜索一秒搜到", url="plugin://plugin.video.youtube/kodion/search/query/?q=GYoAIR1oML4", folder=False)
    Add_Dir(
        name="DP接口是什么？对比HDMI有哪些优劣？DisplayPort简单科普", url="plugin://plugin.video.youtube/kodion/search/query/?q=qGpe5AhV0Dk", folder=False)
    Add_Dir(
        name="Converting devices to USB Type-C", url="plugin://plugin.video.youtube/kodion/search/query/?q=V-vFtiDYiIw", folder=False)
    Add_Dir(
        name="乱码", url="plugin://plugin.video.youtube/kodion/search/query/?q=zSstXi-j7Qc", folder=False)
    Add_Dir(
        name="扫自己手机里的二维码", url="plugin://plugin.video.youtube/kodion/search/query/?q=IBaAJ2O2B50", folder=False)
    Add_Dir(
        name="WINDOWS 11 ON FIRESTICK", url="plugin://plugin.video.youtube/kodion/search/query/?q=hC_Eidh_szw", folder=False)
    Add_Dir(
        name="PLUG YOUR FIRESTICK INTO YOUR PC", url="plugin://plugin.video.youtube/kodion/search/query/?q=NhLX7fhCPP4", folder=False)
    Add_Dir(
        name="FIRE TV STICK CODES", url="plugin://plugin.video.youtube/kodion/search/query/?q=61L6LO8Z3a0", folder=False)
    Add_Dir(
        name="Hidden Tips and Tricks For Your AMAZON FIRE TV STICK!", url="plugin://plugin.video.youtube/kodion/search/query/?q=6nHpIRGCLd8", folder=False)
    Add_Dir(
        name="Hidden Tips and Tricks For Your AMAZON FIRE TV STICK! 2", url="plugin://plugin.video.youtube/kodion/search/query/?q=nLrzAlnLcPA", folder=False)
    Add_Dir(
        name="Kick-Proof TV from China!", url="plugin://plugin.video.youtube/kodion/search/query/?q=4eSADWuZskk", folder=False)
    Add_Dir(
        name="How to Remove ANY Virus from Windows for FREE in 1 EASY STEP (Windows 10 & Windows 1", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="5 things you didn't know your USB Flash Drive could do!", url="plugin://plugin.video.youtube/kodion/search/query/?q=fAlz59koSnY", folder=False)
    Add_Dir(
        name="機在何砌", url="plugin://plugin.video.youtube/kodion/search/query/?q=sdE3LuFGE54", folder=False)
    Add_Dir(
        name="实用生活小技巧", url="plugin://plugin.video.youtube/kodion/search/query/?q=Ztqa0gjKE1A", folder=False)
    Add_Dir(
        name="4 Easy Ways To Remove Security Torx (Sta", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="Key to open shopping cart", url="plugin://plugin.video.youtube/kodion/search/query/?q=0D43me4iK0Q", folder=False)
    Add_Dir(
        name="Amazing Dress Material", url="plugin://plugin.video.youtube/kodion/search/query/?q=Obi65c6XSXw", folder=False)
    Add_Dir(
        name="1 2 3 4 .. Bird is finished", url="plugin://plugin.video.youtube/kodion/search/query/?q=tdBdHQ1iYe0", folder=False)
    Add_Dir(
        name="Simplest 3D Drawing", url="plugin://plugin.video.youtube/kodion/search/query/?q=R6ogrDcqvTY", folder=False)
    Add_Dir(
        name="大聪明啊-反轉筷子用", url="plugin://plugin.video.youtube/kodion/search/query/?q=juLG1BkXRX0", folder=False)
    Add_Dir(
        name="Air Gunning PS 6 plastic", url="plugin://plugin.video.youtube/kodion/search/query/?q=FDj_mXV6B7Q", folder=False)
    Add_Dir(
        name="13 ways to unlock various locks", url="plugin://plugin.video.youtube/kodion/search/query/?q=niHOimopCeM", folder=False)
    Add_Dir(
        name="Unlock Combination Locks", url="plugin://plugin.video.youtube/kodion/search/query/?q=BgNBZNE1PWY", folder=False)
    Add_Dir(
        name="Decode most combination bike locks", url="plugin://plugin.video.youtube/kodion/search/query/?q=PWF5vi13a1g", folder=False)
    Add_Dir(
        name="Hack Luggage Code", url="plugin://plugin.video.youtube/kodion/search/query/?q=HCRN9-RgvTE", folder=False)
    Add_Dir(
        name="牙膏清洁小技巧", url="plugin://plugin.video.youtube/kodion/search/query/?q=m4buYd8CQEs", folder=False)
    Add_Dir(
        name="穿针引线方法", url="plugin://plugin.video.youtube/kodion/search/query/?q=TJ0IEuDblxE", folder=False)
    Add_Dir(
        name="換拉鏈頭", url="plugin://plugin.video.youtube/kodion/search/query/?q=ibVQltPe1Fo", folder=False)
    Add_Dir(
        name="挑西瓜", url="plugin://plugin.video.youtube/kodion/search/query/?q=MKSHeNqjGjc", folder=False)
    Add_Dir(
        name="去魚刺", url="plugin://plugin.video.youtube/kodion/search/query/?q=wFOwPPpncYE", folder=False)
    Add_Dir(
        name="大米生蟲千", url="plugin://plugin.video.youtube/kodion/search/query/?q=39KJti625Ww", folder=False)
    Add_Dir(
        name="穿針原來這麼簡單", url="plugin://plugin.video.youtube/kodion/search/query/?q=tXgsU0pOL-g", folder=False)
    Add_Dir(
        name="地鼠终于要被我清零了", url="plugin://plugin.video.youtube/kodion/search/query/?q=6Q6f6gFRwGE", folder=False)
    Add_Dir(
        name="3 Easy Tricks To Start a Dead Car - Without Jumper Cables", url="plugin://plugin.video.youtube/kodion/search/query/?q=YzHdxL8im6E", folder=False)
    Add_Dir(
        name="How To Fix Clogged Windshield Washer Spray Nozzle", url="plugin://plugin.video.youtube/kodion/search/query/?q=AyIeuBR-Bp0", folder=False)
    Add_Dir(
        name="Windshield Washer Fluid Nozzle Not Spraying Fix", url="plugin://plugin.video.youtube/kodion/search/query/?q=zcshcvc8s4M", folder=False)
    Add_Dir(
        name="Windshield Washer Fluid Not Coming Out? System Diagnosis", url="plugin://plugin.video.youtube/kodion/search/query/?q=c1PaJdJujy8", folder=False)
    Add_Dir(
        name="汽车大灯发黄不亮", url="plugin://plugin.video.youtube/kodion/search/query/?q=_IbxRu5clFQ", folder=False)
    Add_Dir(
        name="Parking is no longer difficult!", url="plugin://plugin.video.youtube/kodion/search/query/?q=Q2SbXE-nU3o", folder=False)
    Add_Dir(
        name="坐在车内，就能轻松判断前后左右车距的小技巧", url="plugin://plugin.video.youtube/kodion/search/query/?q=pc2PEKloFXs", folder=False)
    Add_Dir(
        name="Side mirror hidden tricks", url="plugin://plugin.video.youtube/kodion/search/query/?q=xHZBouyE4nI", folder=False)
    Add_Dir(
        name="Echo trimmer conversion kit installation", url="plugin://plugin.video.youtube/kodion/search/query/?q=_Uhajo5MjS4", folder=False)
    Add_Dir(
        name="Faucet Pull Sprayer Head Repair", url="plugin://plugin.video.youtube/kodion/search/query/?q=gTJYAyI-c90", folder=False)
    Add_Dir(
        name="Moen Faucet Wand Disassembly", url="plugin://plugin.video.youtube/kodion/search/query/?q=ljeQ8heRohI", folder=False)
    Add_Dir(
        name="How to fix low water pressure on a Moen faucet", url="plugin://plugin.video.youtube/kodion/search/query/?q=YYBDtcMzB2s", folder=False)
    Add_Dir(
        name="Definitive solution to dripping faucets", url="plugin://plugin.video.youtube/kodion/search/query/?q=NB8UxfwtOkI", folder=False)
    Add_Dir(
        name="Storm Door Closer Installation and Adjustment", url="plugin://plugin.video.youtube/kodion/search/query/?q=aht8hLSlq1o", folder=False)
    Add_Dir(
        name="4 Post Hole Digger Showdown!", url="plugin://plugin.video.youtube/kodion/search/query/?q=INuGAMD2KJs", folder=False)
    Add_Dir(
        name="Christie Engineering Post Driver & Y Post Remover", url="plugin://plugin.video.youtube/kodion/search/query/?q=WbgoV0EdyJc", folder=False)
    Add_Dir(
        name="Best Manual Post Driver", url="plugin://plugin.video.youtube/kodion/search/query/?q=_50uc8JGoXg", folder=False)
    Add_Dir(
        name="Driving a Steel PostMaster Fence Post Instead of Using Concrete", url="plugin://plugin.video.youtube/kodion/search/query/?q=cLvM7ijI9zE", folder=False)
    Add_Dir(
        name="Man Savor post driver", url="plugin://plugin.video.youtube/kodion/search/query/?q=3oBbvjDJPUw", folder=False)
    Add_Dir(
        name="How To Fix Damaged IKEA Furniture", url="plugin://plugin.video.youtube/kodion/search/query/?q=LfH645d6Ns0", folder=False)
    Add_Dir(
        name="How To Remove Bubbles on Laminate Furniture", url="plugin://plugin.video.youtube/kodion/search/query/?q=R7nv7H4bRew", folder=False)
    Add_Dir(
        name="How to Fix and Repair Dents in Wood", url="plugin://plugin.video.youtube/kodion/search/query/?q=c75LWAmWeBQ", folder=False)
    Add_Dir(
        name="How to Fix Broken Particle Board Furniture", url="plugin://plugin.video.youtube/kodion/search/query/?q=8Ut5LpHU3Fo", folder=False)
    Add_Dir(
        name="Lifting an Extension Ladder and Safe Climbing Practices", url="plugin://plugin.video.youtube/kodion/search/query/?q=qaUZCrdkB8g", folder=False)
    Add_Dir(
        name="How to Not Fall Off A Ladder", url="plugin://plugin.video.youtube/kodion/search/query/?q=n28tYo5T1Po", folder=False)
    Add_Dir(
        name="柜板封边怎么做？适用多层板和颗粒板。DIY三氰板柜体封边技巧", url="plugin://plugin.video.youtube/kodion/search/query/?q=1GdtgkTefQU", folder=False)
    Add_Dir(
        name="DIY制作橱柜技巧之-安装吊柜/顶柜/墙柜/壁柜", url="plugin://plugin.video.youtube/kodion/search/query/?q=2rLd7J2ZVxM", folder=False)
    Add_Dir(
        name="DIY瓷砖刷漆改色流程，给旧瓷砖翻新续命。耐划痕测试", url="plugin://plugin.video.youtube/kodion/search/query/?q=vaSrq_EID6A", folder=False)
    Add_Dir(
        name="DIY制作实木桌面。适用书房办公桌，厨房台面，浴室洗脸台，橱柜桌面", url="plugin://plugin.video.youtube/kodion/search/query/?q=xm4AS8h0HUQ", folder=False)
    Add_Dir(
        name="DIY刷漆：如何刷一个房间？如何刷出平整、均匀的墙面？刷屋顶和刷墙面的详细步骤", url="plugin://plugin.video.youtube/kodion/search/query/?q=ehhtu-geVNA", folder=False)
    Add_Dir(
        name="AMAZING GROUT CLEANER for Kitchen, Bathroom Floors & Shower!", url="plugin://plugin.video.youtube/kodion/search/query/?q=D7sTymORypQ", folder=False)
    Add_Dir(
        name="How to grout tile", url="plugin://plugin.video.youtube/kodion/search/query/?q=kZaxmLu8DtQ", folder=False)
    Add_Dir(
        name="How to seal driveway cracks", url="plugin://plugin.video.youtube/kodion/search/query/?q=YEjxUOE4hZ4", folder=False)
    Add_Dir(
        name="Toilet Rim Hole Fix", url="plugin://plugin.video.youtube/kodion/search/query/?q=4mzBc-oUxZI", folder=False)
    Add_Dir(
        name="破解马桶构造", url="plugin://plugin.video.youtube/kodion/search/query/?q=73CxzMmoIVA", folder=False)
    Add_Dir(
        name="Repair Ball Facucet and Using Syringe rubber ring to Stop The Faucet Dripping", url="plugin://plugin.video.youtube/kodion/search/query/?q=EYobGZXk6CQ", folder=False)
    Add_Dir(
        name="How Do Gas Water Heaters Work? | Repair and Replace", url="plugin://plugin.video.youtube/kodion/search/query/?q=BHUPFLbb8NY", folder=False)
    Add_Dir(
        name="Drill & Grinder Repair", url="plugin://plugin.video.youtube/kodion/search/query/?q=yeX78iBaAus", folder=False)
    Add_Dir(
        name="How to install Grinder Plates", url="plugin://plugin.video.youtube/kodion/search/query/?q=Nqtj9ErobX0", folder=False)
    Add_Dir(
        name="Rope Chain Saw Cutting Branches", url="plugin://plugin.video.youtube/kodion/search/query/?q=gRpc-BDsi8M", folder=False)
    Add_Dir(
        name="LEVELING a Bumpy LAWN the EASY Way", url="plugin://plugin.video.youtube/kodion/search/query/?q=mioAA0N1dWY", folder=False)
    Add_Dir(
        name="Super Glue - CA Glue - Tips Tricks And Uses", url="plugin://plugin.video.youtube/kodion/search/query/?q=D9Vrty5Y14U", folder=False)
    Add_Dir(
        name="Super Glue and Cotton Miracle", url="plugin://plugin.video.youtube/kodion/search/query/?q=odjiOGD8-M0", folder=False)
    Add_Dir(
        name="Fix yellowed plastics", url="plugin://plugin.video.youtube/kodion/search/query/?q=VU7vXMezW_I", folder=False)
    Add_Dir(
        name="Whiten yellowed plastics", url="plugin://plugin.video.youtube/kodion/search/query/?q=t6TspJyHnnE", folder=False)
    Add_Dir(
        name="Easy Plastic Reconstruction and Repair", url="plugin://plugin.video.youtube/kodion/search/query/?q=n1meoZaHYZo", folder=False)
    Add_Dir(
        name="How To Repair Broken Plastic Car Parts", url="plugin://plugin.video.youtube/kodion/search/query/?q=_qaFIg1yQuc", folder=False)
    Add_Dir(
        name="腹语撩妹", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="iphone捕捉面部，免费的VTuber应用，3分钟上手，录播直播好助手", url="plugin://plugin.video.youtube/kodion/search/query/?q=3TaSrFGVjPQ", folder=False)
    Add_Dir(
        name="香港做YouTuber揾到幾多錢?", url="plugin://plugin.video.youtube/kodion/search/query/?q=HlcUUkRyMBs", folder=False)
    Add_Dir(
        name="How to be a Full Time Youtuber", url="plugin://plugin.video.youtube/kodion/search/query/?q=nEw_EoZCl_w", folder=False)
    Add_Dir(
        name="王楠 讲解如何根据自己的特点选择乒乓球底板和套胶", url="plugin://plugin.video.youtube/kodion/search/query/?q=9Kts-DxJce8", folder=False)
    Add_Dir(
        name="王楠 示范乒乓球的发球和接发球，如何发出合乎规则的球", url="plugin://plugin.video.youtube/kodion/search/query/?q=XwUC5TfmztE", folder=False)
    Add_Dir(
        name="王楠 示范乒乓球的正反手拉加转弧圈球和前冲弧圈球", url="plugin://plugin.video.youtube/kodion/search/query/?q=9lkXv1xqYlE", folder=False)
    Add_Dir(
        name="王楠 示范乒乓球的正手挑打和反手挑打 ，反手提拉", url="plugin://plugin.video.youtube/kodion/search/query/?q=dSRUdggI8vs", folder=False)
    Add_Dir(
        name="Golden hoop slow motion teaching", url="plugin://plugin.video.youtube/kodion/search/query/?q=-l1uIZqBkzE", folder=False)
    Add_Dir(
        name="Spin stick thru fingers", url="plugin://plugin.video.youtube/kodion/search/query/?q=DXeqYLNd-H4", folder=False)
    Add_Dir(
        name="成龙，以替身和谎言伪造的拼命神话", url="plugin://plugin.video.youtube/kodion/search/query/?q=puKsjFRwIyw", folder=False)
    Add_Dir(
        name="成龙38年欺骗路：高危替身、花絮作假、伤情作假", url="plugin://plugin.video.youtube/kodion/search/query/?q=eNpAGY4Irb0", folder=False)
    Add_Dir(
        name="Professional Denture Repair", url="plugin://plugin.video.youtube/kodion/search/query/?q=2pl1x8aDk5U", folder=False)
    Add_Dir(
        name="Easiest Self-haircut | How to Cut Your Own Hair", url="plugin://plugin.video.youtube/kodion/search/query/?q=ZrTC5D-zYBs", folder=False)
    Add_Dir(
        name="HOW TO CUT YOUR OWN HAIR | Quick and Easy Home Self Haircut Tutorial", url="plugin://plugin.video.youtube/kodion/search/query/?q=eUwR_CbezmQ", folder=False)
    Add_Dir(
        name="Learn to Cut Your Own Hair At Home", url="plugin://plugin.video.youtube/kodion/search/query/?q=DSZCH2mlz_M", folder=False)
    Add_Dir(
        name="Tennis Elbow Pain Relief", url="plugin://plugin.video.youtube/kodion/search/query/?q=4xfb3DS_tqA", folder=False)
    Add_Dir(
        name="Piriformis Muscle Syndrome", url="plugin://plugin.video.youtube/kodion/search/query/?q=r7U1nRpxZuM&t", folder=False)
    Add_Dir(
        name="Sciatica Treatments - How to Treat Sciatica", url="plugin://plugin.video.youtube/kodion/search/query/?q=go7v8BlLWyw", folder=False)
    Add_Dir(
        name="手汗症", url="plugin://plugin.video.youtube/kodion/search/query/?q=qmzGKcr5q94", folder=False)
    Add_Dir(
        name="消除腳指甲真菌,便宜又簡單,柏格醫生 Dr Berg", url="plugin://plugin.video.youtube/kodion/search/query/?q=4tVbxYt86QY", folder=False)
    Add_Dir(
        name="永遠根除腳指甲真菌(灰指", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="CURE Toenail Fungus for Less than $2.00 - Dr. Berg", url="plugin://plugin.video.youtube/kodion/search/query/?q=gMnFOsJoTyE", folder=False)
    Add_Dir(
        name="12 Home Remedies to Prevent Hair Loss and Regrow Your Hair", url="plugin://plugin.video.youtube/kodion/search/query/?q=wrhGIgye_Z4", folder=False)
    Add_Dir(
        name="ROLEX劳力士价格崩盘暴跌！", url="plugin://plugin.video.youtube/kodion/search/query/?q=OiSB8opwEIg", folder=False)
    Add_Dir(
        name="One Way Ticket Out Of Hong Kong: One Way - Part 1", url="plugin://plugin.video.youtube/kodion/search/query/?q=qMaKLwqU3vI", folder=False)
    Add_Dir(
        name="Finding A New Home After Leaving Hong Kong | One Way - Part 2", url="plugin://plugin.video.youtube/kodion/search/query/?q=bJn3J_PPFGE", folder=False)
    Add_Dir(
        name="What Happened To The Chow Family From One Way?", url="plugin://plugin.video.youtube/kodion/search/query/?q=_OfTvQbAC5o", folder=False)
    Add_Dir(
        name="海外港人退休回大灣區生活】（加拿大-香港-內地）", url="plugin://plugin.video.youtube/kodion/search/query/?q=1je-rKhVSCA", folder=False)

#===============================================================================       
#@route(mode='Languages')       
def Languages():        

    Add_Dir(
        name="ST English", url="plugin://plugin.video.youtube/channel/UC4Yvba2mfv0h4TbLQWK04Tw/", folder=True,
        icon="https://yt3.ggpht.com/jVXl7fWsexwKHgSCHMAqeKULWpzaZtqwBGGByvjNXuEyXnXvb8W5DYZ5xbXn29JdjIZvQ9F_uw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Wang Cicely", url="plugin://plugin.video.youtube/channel/UCuhRFHmNjbrI8NgDrLP6OFA/", folder=True,
        icon="https://yt3.googleusercontent.com/v8gpElrTLY7uTOpnTyWF1DboZ5-Onru564oeN3G2HC4oiacPpUD-gpbIa4_SLr8zZRgM9EUb=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="zaharaEnglish", url="plugin://plugin.video.youtube/channel/UCTABKswbDxx36elouOdQhlw/", folder=True,
        icon="https://yt3.googleusercontent.com/ugwD4_xh_j52b0G6PIZ1CNB3G_sKLkWfCjSVQRglHHBmCXOdu-krR_LPhycyXhBmIaX82sOIdjA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="英文老師William- 每周新聞英文", url="plugin://plugin.video.youtube/channel/UCy4rREatQSudxASFTyz0F8w/", folder=True,
        icon="https://yt3.googleusercontent.com/P53YBBhBpsUx9Za3P0pcXB9MltCLM5oBU8kK8-VxUVoIMZQjkdZ5mD3usX3U1vZivcNvHjqn4Q=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="读新闻学英语", url="plugin://plugin.video.youtube/channel/UCxoexy5N2fRxZNReR_2PWsw/", folder=True,
        icon="https://yt3.ggpht.com/t-bPjzb7q11D65GhaT32sk1aMm1tF8AT_5CibS7NWPoYwEMe1w8VicVzWIO5vZO93-wm861rsA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="英语这样用LEC", url="plugin://plugin.video.youtube/channel/UCGsT-CwBnWCWW4UWe3QnOvg/", folder=True,
        icon="https://yt3.ggpht.com/ccsGZc_bbBK2VR9sOZnKfzvyZyKW0VRcurrWf6IR_MU0V_SHp7wBj0AhOUD08pSHurZES5hGNg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="和Austin學英文", url="plugin://plugin.video.youtube/channel/UCq4gY4o_6jtHruoDWSxvmQg/", folder=True,
        icon="https://yt3.googleusercontent.com/PzN6uSQZ3_Hcs1A-8YVLf2YGjVDOCB9G7SPvPKu22iNb6j-JCVWQdx86SQVn3PmAmL8fplWafQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="英英语语", url="plugin://plugin.video.youtube/channel/UCqnoe8MHE3BtqCOfF6WXMdg/", folder=True,
        icon="https://yt3.ggpht.com/rfxZHiopQ-Gazbx4_OajLSG_Yfz7MSJX8XWd3uDto3OTc4qfXKDyzGPRTBrnGljofIr1WUmvaw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Michelleleungsy - Medical English", url="plugin://plugin.video.youtube/channel/UCkAAcoTU8Hia-Gk_fidqYpA/", folder=True,
        icon="https://yt3.ggpht.com/JQkU2eIWL7DbMhH0_-CTjsoIxGxicbZTNqcrE1NUH4lXYNQwsKbKrv-mOzjPAaXx6m4cNzWOUsc=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="linguamarina", url="plugin://plugin.video.youtube/channel/UCAQg09FkoobmLquNNoO4ulg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSNO3VqpFZ59W1_spWLBeQ9KCiJy4JP7Qvf0Ksn=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="English Conversation Anh Ngu VIPS", url="plugin://plugin.video.youtube/playlist/PLzVm1SmjPKc_OnC56MbILOmdXvGV_3kE9/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxZQeBCHvD-tTLkgmEDCywsP1z6kEZR93Re71wqxA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Learning English Anh Ngu VIPS", url="plugin://plugin.video.youtube/channel/UCVXM96yuiXY3ZT73Dy8HgCA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxZQeBCHvD-tTLkgmEDCywsP1z6kEZR93Re71wqxA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Daily English Speaking Anh Ngu VIPS", url="plugin://plugin.video.youtube/playlist/PLG8vJQBHlyoErKrozK21hyZestXaj18AT/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwuGN_WWXcbx4FGBssTiJeMDmAZV25CvA_HKs5U4g=s88-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="英语这样用LEC", url="plugin://plugin.video.youtube/channel/UCGsT-CwBnWCWW4UWe3QnOvg/", folder=True,
        icon="https://yt3.ggpht.com/ccsGZc_bbBK2VR9sOZnKfzvyZyKW0VRcurrWf6IR_MU0V_SHp7wBj0AhOUD08pSHurZES5hGNg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Ozma English", url="plugin://plugin.video.youtube/channel/UCTyEW-W7FTVdN0HdYHtQrEA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQCWSEgYxabSQwXzFBz9uxcP0ylaCpgo4FzwIr65w=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Nate -Onion English", url="plugin://plugin.video.youtube/channel/UCr3G6ktLt-1rWK7JT2kl6uw/", folder=True, 
        icon="https://yt3.ggpht.com/ytc/AKedOLSHSvhHsyqoKu79kDpFZQIiX76c-lz5dFsTpmusHA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Sea Light English 海之光英语", url="plugin://plugin.video.youtube/channel/UCxKcshfmz6L565ewsvrEOPQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRw4q_4IN-3WXKxLtzCmiv0puXo6CEB8iQiq6Bg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="JR Lee Radio", url="plugin://plugin.video.youtube/channel/UCH1jieeP7Ecpo4s-pPT9FWQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS3eAlEcf9fwFCBrh60AyNVRk8c1eGsC6z4UJOr=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="知心英文", url="plugin://plugin.video.youtube/channel/UCnIIyNL75v-0F85_6ExC0mw/", folder=True,
        icon="https://yt3.ggpht.com/il_iPYH1GCPppCjTfu3p2owwXFVdD2bbw3jOWMVmh7UwiH0g6M4ZmmKGFPBWEJl4wPmGYRAlE5U=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="強效英文 Powerful English", url="plugin://plugin.video.youtube/channel/UCtL8ERlEprymslmnHPcWNnw/", folder=True,
        icon="https://yt3.ggpht.com/KiHmXKV5Jzaq9FL8CgsKqve8dEmvvoHBHqFqzI-r9lCjvDvgrRvlA59isImtQ8W15cITXgkd=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="簡短易用的英語短句", url="plugin://plugin.video.youtube/playlist/PLtLNrYAJQaF-cYe3dOpcIiuCcyK6iIkZB/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRagvsEQxgLjHD-D8kBA3Pf8TfhB8yK55pShRVaMA=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="PronunciationDictionary", url="plugin://plugin.video.youtube/channel/UChA2GL2QZnpqbw7U7tNTB0Q/", folder=True,
        icon="https://yt3.ggpht.com/iGVj_PSx8oSlltXkqmn4uyCvs2UdyIgteQ-hSvukad5vmBQ-F5o3ToXQ6enXJXf30_MVu_Th0A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="独角兽英语", url="plugin://plugin.video.youtube/channel/UC_IfKvdExQGN0Hhpr75ut7w/", folder=True,
        icon="https://yt3.ggpht.com/Zjj2VglDKz4l2jnplfVXX6_-uXUCip_hi9vFR2eaSDQeE23WRQjfjI4ZizOpMJ4uQf7PitXG1g=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="英英语语-看美剧学英语", url="plugin://plugin.video.youtube/channel/UCqnoe8MHE3BtqCOfF6WXMdg/", folder=True,
        icon="https://yt3.ggpht.com/rfxZHiopQ-Gazbx4_OajLSG_Yfz7MSJX8XWd3uDto3OTc4qfXKDyzGPRTBrnGljofIr1WUmvaw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="聽美劇練聽力", url="plugin://plugin.video.youtube/channel/UCS24AgMqFRLHA6V1wOMeqhA/", folder=True,
        icon="https://yt3.ggpht.com/YMkGJgGwnihWIWRBIlmaSZ4qXNWI4TcLMwcKlYt2owDzVTyyFLjYB-lZHpnxWXE0WNeQg3Cy=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="English Listening Practice (from beginners to experts)", url="plugin://plugin.video.youtube/playlist/PL41R2vH_CL40T-mJPvt83YVyFFrOVmJjT/", folder=True,
        icon="https://i.ytimg.com/vi/f7Sg3Wjpd14/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAGmn2e1_lYYCpApNUI44jgYal4kg"
)

    Add_Dir(
        name="Kendra's Language School", url="plugin://plugin.video.youtube/channel/UCTYQzAi6YOcgv2mkzsfzmpA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSE1IJ5YT5WXthPXZUbvLh68gZQFNi5pkWbrhRMnw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="口语老炮儿马思瑞 Laoma Chris", url="plugin://plugin.video.youtube/channel/UC8FnQA_ZSeHwxAX9igzyeCg/", folder=True,
        icon="https://yt3.ggpht.com/ZCFmOZ1ZFilf7AyId-9pcpxlzdZf8wcFR22W4GTT4i6xf-mNGedIHP6agn4Z7GmG6jUPPlHOcAc=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Learn Chinese with Rita", url="plugin://plugin.video.youtube/channel/UChvb7fsf1B1a-0qtg-8Tfjg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTtPvFe1bET_nnboD58vf0EvAkXR6NK2XemNzUq=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Phoenix Hou", url="plugin://plugin.video.youtube/channel/UCqLqngg7htY6Pol4ZBJKwHA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTMNkCOw8CklJw9f_U3vQMXPHmh558gboIfMvkR=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="莎白Elizabeth", url="plugin://plugin.video.youtube/channel/UCaf2miuZ-IeiX4_-4dej9Eg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRVWXEG3BLbPY8r6uJplWykRjxa850WPkF_FvU=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Learn English With TV Series", url="plugin://plugin.video.youtube/channel/UCKgpamMlm872zkGDcBJHYDg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwnMcURDL4jwSKIH1zYkaeiR7VbUHRnj1JWlg2D=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="瑪姬英文 English with Maggie", url="plugin://plugin.video.youtube/channel/UCMXOmw_gVvTj8n1gjqUN51w/", folder=True,
        icon="https://yt3.ggpht.com/t-WxyLl93o5XWblnYX6u3uVZ6DfWk6mgWe-Mj5gyyDkjqKZVSC3qe31KLtsPnEycea1-ifAUYQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="與芬尼學英語 Finnie's Language Arts", url="plugin://plugin.video.youtube/channel/UCHkPJ7O9LLjEntwbsgn5TOg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnh1-VwmySxKXG_E7jjqYQBibHHM6_tG_7aaOlfl6w=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Torres Pit托哥", url="plugin://plugin.video.youtube/channel/UCsnZXdLOGBnezK--CiG7FZQ/", folder=True,
        icon="https://yt3.ggpht.com/tYRKEsJ27gGN8bSQ-mrqSXxHOCoqQxXjyeqa5UZZp2qj_iCDePzLtR1MF69xSRZW_nUDXUyg5EY=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="英语兔", url="plugin://plugin.video.youtube/channel/UCzSDYsBLs6EIHcQyO70Agxg/", folder=True,
        icon="https://yt3.ggpht.com/VnKzy6UKvr4EJppQhjxfAtUWD4vibPBYZEU2jziPFrG_0V8XqZTO9TT6b32Fp0GzOoJYucD4OtA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Learn English with EnglishClass101.com", url="plugin://plugin.video.youtube/channel/UCeTVoczn9NOZA9blls3YgUg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwmSsXMx70Uv-dunsQHpFNEovn5b4GMWz1RsgFY8g=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Smart English TV", url="plugin://plugin.video.youtube/channel/UCeIU0bIyDnG9xmIVM43ZfHQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzY9PQYLOABbX4M9Nhw5jl0DLzoJPRECKr0I9ycgw=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Speak English With Vanessa", url="plugin://plugin.video.youtube/channel/UCxJGMJbjokfnr2-s4_RXPxQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJw46skdZabHUAb8p1n9N09E3cZZZ2NCdpy2SoWZSA=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Rachel's English", url="plugin://plugin.video.youtube/channel/UCvn_XCl_mgQmt3sD753zdJA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzth5bLS3FS5ahYPCzNDk9tAorieF83covquTYuuA=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Maaaxter English", url="plugin://plugin.video.youtube/channel/UCO8GewbsHFFmJn4kLLq1WXQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjB9wpG7gaoGUzQAFvQvQt2sOZ3N5Y2vkabu9nivw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="MrYang楊家成", url="plugin://plugin.video.youtube/channel/UCAXYUIlnzX62PppZ6BvOA1w/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzWudMDbGt4kNVfVBOPXUXhjSFpPT3EGN-JFooCTA=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="語音研究所", url="plugin://plugin.video.youtube/channel/UCR6Tl_nu_6PaicKSPm8S7GQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwi3DOac1XWcRTtDxne494vvEVYugmts_Qz-pn9=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Fullness Language - Mandarin & Cantonese", url="plugin://plugin.video.youtube/channel/UCA8meO_jqNPNXRdr28lTG2Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLT--jod34JCZURy_jkJZ17edXSSdXLeeKEoQucy=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Learn English and Chinese", url="plugin://plugin.video.youtube/channel/UCzcE1dwNZk0NHn3DyKDqjaw/", folder=True,
        icon="https://yt3.ggpht.com/XakQVAdYaTCsu6X6F9qhF47ONvLGoBwO1TM7k1zQDbIqnWbiWNgSlgJ_MukL3gfsiNTgXc9blQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="ChineseFor.Us - Learn Mandarin Chinese Online ", url="plugin://plugin.video.youtube/channel/UCgCrOLcWvSFl5K2ld0nKS7w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRvh_TukNtnfDddoLzD2rpRZFVnXzRP0ky9Lzltog=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="SyS Mandarin", url="plugin://plugin.video.youtube/channel/UCUjFsQAUUS1IFM7oyUXeB1g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQv0ic8c63Eh0OTyl4-9iE3ZhWUC20pextJv3ZK=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="杨老师中文小课堂", url="plugin://plugin.video.youtube/channel/UCeCHXtByei6mSAQQhbYagyw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRy-hngEQ0NRJtwEzqbBZjH0a44MQZJS17ELFRXDA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="中文微课", url="plugin://plugin.video.youtube/channel/UCc4EJKXCenO-8e-yidfMmJQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyTekNiN67cfESCq2ixAd2tyJW1R-F9vAZ4uIkN=s176-c-k-c0x00ffffff-no-rj-mo"
)

    Add_Dir(
        name="叻叻果叮 ladaldkid", url="plugin://plugin.video.youtube/channel/UCGyUVIhEzQH89IdZl0i646g/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxgyg9j1SFm7zo8ZD_qdR3lFWD2irFLa6k-H2rLZw=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Thaikong Wei - 最系统性学粤语（广东话）", url="plugin://plugin.video.youtube/channel/UC7C3iEhzeCiSSe1ggdGjUXw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLScit2bF3Oz_F37Vb-prX3ruNbljOb9wKXZQ0EjJQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="5 minute Cantonese", url="plugin://plugin.video.youtube/playlist/PLBscToQcliCZ-c8rQZ-SczgkeZZXIYXSN/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSVhHBioxvsza3FHOgbPBGCXGHjBQunWDDrYE5K=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Uncle Calvin 廣東話教室", url="plugin://plugin.video.youtube/channel/UCCVn38j5xSJZN-II-TeyomA/", folder=True,
        icon="https://yt3.ggpht.com/mv5xnajZytsP2VuE0nkVoty_xCJ91cZWEnIG_aA9DCw3kfVkCGvUgr2KZGxAQ-JqalhxQUQ3=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Easy Italian in 1 Minute", url="plugin://plugin.video.youtube/playlist/PLHI2TAm-NyNOupHMB4_7xgNFlYyQEwEzo/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQFuw-04Sp2PybU5Zjf4QHBBvUK2Eqj4yj9oJiSLg=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Learn Italian in 30 Days", url="plugin://plugin.video.youtube/playlist/PLHI2TAm-NyNPpFJriRvVbxVoJ4jksDUUH/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQFuw-04Sp2PybU5Zjf4QHBBvUK2Eqj4yj9oJiSLg=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="井上一宏", url="plugin://plugin.video.youtube/channel/UCowdcSC1VR2eusS_SL1BztQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-EgxX5SxVOmIAjpSN-ms2O3_un8WIai7n060EAIA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="何必日語", url="plugin://plugin.video.youtube/channel/UCZ5Wn4ss81cVKSk74Duv2BA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-Zk2w3LtITuEnAseOG0PS7vMiwYxWMZzPtJpr5kzY=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Yunaty日本語", url="plugin://plugin.video.youtube/channel/UCeKUWJFqZa7rR4G_NLnV_9g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQmhXIGIlCBlrHyefOCrV2zVwdm4HNTsBLqWtb_=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="秋山燿平-日文教学", url="plugin://plugin.video.youtube/channel/UCnskHxjXjiog69et60V-pHw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniDdFfWrOGCnrr6FMS6WrM5CGlg6bBTpAmTfaS5uQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="利用ChatGPT免费练习英文口语和听力，练就流利英文！", url="plugin://plugin.video.youtube/kodion/search/query/?q=gFr4zhuV1g0", folder=False)
    Add_Dir(
        name="How to speak fast and understand native speakers - Connecting words", url="plugin://plugin.video.youtube/kodion/search/query/?q=_PWsV3WpJ20", folder=False)
    Add_Dir(
        name="How I started speaking English without fear (as a non-native speake", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="Airport / Customs English", url="plugin://plugin.video.youtube/kodion/search/query/?q=eujv6WYyU1g", folder=False)
    Add_Dir(
        name="自然增強英語聽力-JR Lee Radio", url="plugin://plugin.video.youtube/kodion/search/query/?q=Hz5heh407ps", folder=False)
    Add_Dir(
        name="練出一口道地美語-JR Lee Radio", url="plugin://plugin.video.youtube/kodion/search/query/?q=D3o5cZC7Gz4", folder=False)
    Add_Dir(
        name="英語口語大全2700句（時長10小時）", url="plugin://plugin.video.youtube/kodion/search/query/?q=jTMatEZVEEU", folder=False)
    Add_Dir(
        name="Stop Learning English with Friends! My Top 10 Recommendations", url="plugin://plugin.video.youtube/kodion/search/query/?q=-i90nkYc8I8", folder=False)
    Add_Dir(
        name="Understand FAST English Conversations", url="plugin://plugin.video.youtube/kodion/search/query/?q=nRiHKI_8u0A", folder=False)
    Add_Dir(
        name="調羹", url="plugin://plugin.video.youtube/kodion/search/query/?q=eyjWLfxuc_4", folder=False)
    Add_Dir(
        name="10分鐘完美KO倉頡輸入法-杜氏數學", url="plugin://plugin.video.youtube/kodion/search/query/?q=iBq3f6tNkH8", folder=False)
    Add_Dir(
        name="10分鐘完美KO倉頡輸入法-語音研究所", url="plugin://plugin.video.youtube/kodion/search/query/?q=ZKOjwgIdM3k", folder=False)
    Add_Dir(
        name="倉頡輸入法-師奶仔教室", url="plugin://plugin.video.youtube/kodion/search/query/?q=f9EzYmtTJg0", folder=False)
    Add_Dir(
        name="10分鐘學識速成輸入法", url="plugin://plugin.video.youtube/kodion/search/query/?q=K_-5b-3-ix8", folder=False)
    Add_Dir(
        name="How to Learn Chinese Characters", url="plugin://plugin.video.youtube/kodion/search/query/?q=lvebdr0sNao", folder=False)

#===============================================================================       
#@route(mode='ElectronicRepair')       
def ElectronicRepair():        

    Add_Dir(
        name="Fix AVReceiver - Denon Marantz Pioneer .. etc", url="plugin://plugin.video.youtube/channel/UCQtOH3tS-9LyqYiD0wZVRZA/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-xWy0efZFVxQrjgvhWhpTUhUM7yHrmqHg-QVbZ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="看懂电路板", url="plugin://plugin.video.youtube/kodion/search/query/?q=看懂電路板", folder=True)

    Add_Dir(
        name="确认电路板上的元器件", url="plugin://plugin.video.youtube/kodion/search/query/?q=确认电路板上的元器件", folder=True)

    Add_Dir(
        name="[COLOR red]---Schematics---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="EE Wave - Good Explain +-5V Small projects with ic", url="plugin://plugin.video.youtube/channel/UCN5yLMGFtk_6VfqGRK8PJNg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_P7OJRdmEUku7NUBitDLtuXke9pKfNDMUCaF31=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---TV---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="tevz TV", url="plugin://plugin.video.youtube/channel/UCHPZLPggzxsWD7DBfb-swDg/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJUkyvnvszpEoHL6XEt-NIl48Ubs1z0e6Gt8fKwXJw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="REPAIR ELECTRONIC - TV Repair", url="plugin://plugin.video.youtube/channel/UC_Wp3D72hTXBKf1hsHOf2uQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu8ys9snJQIyIke1QcaQ95R8dlgmNG1IA2RnuY8SpAuhAhx3Oa6H6F-ydgY2H2tx=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="最愛無線電 favorite radio", url="plugin://plugin.video.youtube/channel/UCPZ2qxIgV_oiiiWkE_fJ16Q/", folder=True,
        icon="https://yt3.ggpht.com/TWpvsBHF4k__GZTrJFG5VWFJG8SBAt0m2yM_2NblSRo1CYf4tQlqSOnkzGR-Au4SaSb-mSKtIw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="工科男孙老师", url="plugin://plugin.video.youtube/channel/UCcGM3aVEJ6SrH5UtfZ80YHQ/", folder=True,
        icon="https://yt3.ggpht.com/Wa6ye8HVpSoRNnUAglWneMpLclkr8bmNIMWp3ndFGD79KzvUFrJG9NC8-fMY4tgR3VFAdTwgYA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="小飞机DIY - Ram SSD", url="plugin://plugin.video.youtube/channel/UCrHVBycuv9_EUQmHQOEotQA/", folder=True, 
        icon="https://yt3.ggpht.com/0SXpxx7pK05uaRvxLtZevFTAnTt6cS9Ezq1Yg36obgNH6IHPktMYABWmih8z8hU4SViwIj63Mn0=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="李永乐老师", url="plugin://plugin.video.youtube/channel/UCSs4A6HYKmHA2MG_0z-F0xw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRFKH_r5A8mm5EfnGb71i8WnGnwH5LW_ex0YiOb=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="The Engineering Mindset", url="plugin://plugin.video.youtube/channel/UCk0fGHsCEzGig-rSzkfCjMw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSAxBtXZcNWYWaBi7Va0f6dvgNVibxXJjatDyGw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Battery---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="電池知識分享", url="plugin://plugin.video.youtube/channel/UCBl3Up4SswZXLktkoGdP1-w/", folder=True,
        icon="https://yt3.ggpht.com/Zd7ZaOywUpeNETUgk8yZFTFacz1wypKsTiTDPFOA2rBw45E4Ydykq6DMvOjB8Pmbz2GddOdn=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Howto repair switch mode power supplies", url="plugin://plugin.video.youtube/playlist/PLUTV_UMnJSciYeKoJLuQ6jxYsMEeWET3f/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTvWw_LlJQNAxwTcu2aK8pE_F2SNrLpY_qhBJ4l=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Haseeb Electronics - SMPS Repair", url="plugin://plugin.video.youtube/channel/UCamuZ8n1PwdZpzxV32b1l_w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTnLG0648F0AqdHya7AL1KNpdLo4uNXF9yp_F-FHFA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Laptops---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="笔记本维修厮", url="plugin://plugin.video.youtube/channel/UCgaTQ4N7-Q50UTLkYSHslCQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRCbhBowHgnWxVphmnVOzeNvfd6dGoVSiN3w0Qy=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Computer Boards Repair - Adamant IT (Playlist for Board Repair Basics)", url="plugin://plugin.video.youtube/channel/UCURRdjIBFE8TDJlPOuiob3Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRLI0z-gmu-GLnnIHisR-iaxFJY2CHHR-zp2p2E=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="HDD Recovery Services", url="plugin://plugin.video.youtube/channel/UCsojCyeOSuw4Odm6MyBXLmg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9vopAkCYqM-TBDtH8G2mHSbNo6ZrXZ10-x7R-43A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Hedgehog刺蝟幫", url="plugin://plugin.video.youtube/channel/UCAg6mvECZYaXdA2KNXkJHMQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQi30PNk_qwatcZ93QWtLwYhiTW8_57AaO5sFEO=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Electronics repair school", url="plugin://plugin.video.youtube/channel/UCooKQlg-HZ0PFAPc4Ymg3RA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnj9ALEKjwfALPbUI41ivYTn6nrdwypL1vZgH0Yi=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Electrician teaching", url="plugin://plugin.video.youtube/channel/UCgCbWvKwhUFvG51r8_uW9Ng/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwNeSVTt9NjeDL_u4J0TCKiqa4j9is9vZkD2Q=s144-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Branchus Creations", url="plugin://plugin.video.youtube/channel/UCXy8pDuiwZoY8_bNISGQ_Cw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhhJZGc_2Z42HLpehewnhWssRh6vDDtTfJahYPm=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="OLMMvideo胡搞蝦搞", url="plugin://plugin.video.youtube/channel/UCQQkUjuHx__kBxvIw1C-xTA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwMoTt569EXByTH42ecRn4ewxY3yeK2ZHwrqg=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="羊羹爸爸ようかんパパ的DIY生活", url="plugin://plugin.video.youtube/channel/UC8yos2dlQzZn7K6zwNkz4vA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxOsIk9-TeQe1LssTSofaaUymN1B6Wo5b5Z7Q=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Haseeb Electronics", url="plugin://plugin.video.youtube/channel/UCamuZ8n1PwdZpzxV32b1l_w/", folder=True,
        icon="https://yt3.googleusercontent.com/pAfkqv3JnIzOR7kGSc9sd4ORnngWzn8X8DOvpl9olJnP_PUcR3yCLpdxVkwuGYEhmTGzP-5hRg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="NorthridgeFix", url="plugin://plugin.video.youtube/channel/UCLaXgfNlVxY149shiA1pykQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngQM2t5LStxEyV06dIZd7VNpKVEXaBBDBgjO82z6A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="The 8-Bit Guy", url="plugin://plugin.video.youtube/channel/UC8uT9cgJorJPWu7ITLGo9Ww/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwni90vq5dQbo824aMYFmmrn4MfLkDpK3mVsAVDLJ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="修客实验室", url="plugin://plugin.video.youtube/channel/UCZoE5OhPeozu88vfPDcy3NQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhNZ07g6q3espgeVaUGKRLxci61GBZRJleVKXJ2=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="80 Xiao Chen", url="plugin://plugin.video.youtube/channel/UCgXuxCSCGyxx_BPxZJh6uVA/", folder=True,
        icon="https://yt3.googleusercontent.com/9W-14wNDZ54fztI13PwJhbxnJKNEULLtUrp4EV6tHs59jueXi2h0s18-TdN_F6UO49XEB5qZCg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="我爱电器维修", url="plugin://plugin.video.youtube/channel/UCma9sHXyCIBoYmC0PzDmLNw/", folder=True,
        icon="https://yt3.ggpht.com/116NVl5ECjVf2QZOkJ_hlKq9x9_qxyyTZNjC4NpvFGKiVnBKiFeBGe_s4ZYG8d6liQsf0-Y8ew=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="电识分享", url="plugin://plugin.video.youtube/channel/UCZ7mVehY7p9xxzSDmzOAvog/", folder=True,
        icon="https://yt3.ggpht.com/CN2pHvdzU1QHiAUuz8z2YmvsGv-PVZKeDJ4OUEVTQytnRll_s_htK_CUqpchD4MkPGqoSgOngA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="修电器的小向", url="plugin://plugin.video.youtube/user/blessedpianokid/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwni9N_hL2m2CQWI3Pnz8CZ6PBKZ9zwurmDe1tKV8=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="80小陈", url="plugin://plugin.video.youtube/user/hvde1992/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhiPBdfdWraieIyfvGCdC86Pz-Pf-bedEhtmLba6w=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="阿兵电器维修", url="plugin://plugin.video.youtube/channel/UCDeRw-USRCNQAXdq0AAvUYg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjNS_1m4WPKw7Yp9Iy_Kd7M8SlEVwdyvIoV_A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="朝锋家电维修", url="plugin://plugin.video.youtube/channel/UCDwsdYjPGwrPgUAQaOwB4wg/", folder=True,
        icon="https://yt3.ggpht.com/CMPPzvjKaUGxGffor8570xE-dnCobIqR-DNFBioSqpF37mDRVUK_JZtNuLZJWuOTtkw1jzULnw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Dream Finder", url="plugin://plugin.video.youtube/channel/UCzlOs_RDnMqct6HhmtWC8NQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-eaDU233bLTB_AV3NLwOB1HyjwGOloWd1RE5sH=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="bigslick", url="plugin://plugin.video.youtube/channel/UC7cKkkJxmblu6lotS8hgr2w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_IC8yNALUTsaqsWlh_pGaBvYeLjm8YaWbCYJCcgg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="點竅門教學", url="plugin://plugin.video.youtube/channel/UCa-ZLMJsh3S_U3HYe_MtZ9Q/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJw22nbTiFd9rFWsCxrH55pEX031V-SSNixPQ_rm=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="實作派電子實驗室", url="plugin://plugin.video.youtube/channel/UCEmI7o9Du2F7FB1bWvSqgYg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxt8uiGn9X_SULuO0hxPYu-XO_mDiejBzg9Gw=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="强弱蜂鸣", url="plugin://plugin.video.youtube/channel/UCqjcS7m4vQz8ZjXjNubLT7w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniO-tC37wbom7PpLl__FltI-5J5esAzhSebber1eg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="科技大家谈", url="plugin://plugin.video.youtube/channel/UCFFFgW940fgJT24cszi4Exw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnibm-XxeV6iZ5SyLA_EuwX4RP-z4ycTdT0ARZJ6=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="学习教程", url="plugin://plugin.video.youtube/channel/UCCkxZE6yACtF9SkE8D8oenA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhU65I1vIihdwKD8mHF5bFia8dSMeYd309qSYjH=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="华宇万维", url="plugin://plugin.video.youtube/channel/UCAYqiqCu1ACUE6pq4Vd7N4A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnhcFgJtuNf1LjvX4CuY7yCFjtG3MuOJVUHtuDO0=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="光头机电", url="plugin://plugin.video.youtube/channel/UCEHiNBbGCgr-QtQS5F4uUpw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnjJvYWN5xY-SF-kKaoU8-7No5munZGH0i9Ynsug=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Soldering---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="Mr SolderFix", url="plugin://plugin.video.youtube/channel/UCw4EJfQf0KJXCyQ5qiNlcUg/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJUnb7LqBIMlXxWcswBJJ5Wp4rsZFqv9vvKtNyQrQg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Androkavo", url="plugin://plugin.video.youtube/channel/UCKDfmGeSKmwP6SdGDHhu6hg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwDQBPqYYKs1CMj6zGRwdXzrFJYUddw4ac7Ir8e=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Electronic Tech", url="plugin://plugin.video.youtube/channel/UCmbn_Up0RJpljJNGTYvws9A/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyJDpyxvopSYmNOn05kcqG16-Q6SmUH-IMCwfAh=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="mjlorton", url="plugin://plugin.video.youtube/channel/UCOTPsWDzNAosVd6vc3pCPHQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJwcVbbP1fZcMPaVOtNti7B9nspXMWKLW59VgNBz=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Electronics repair school", url="plugin://plugin.video.youtube/channel/UCooKQlg-HZ0PFAPc4Ymg3RA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzrjJisJLnJKwHzH4m7nba-of1z5rk0X0939vtp=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Math and Science", url="plugin://plugin.video.youtube/channel/UCYgL81lc7DOLNhnel1_J6Vg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJy9BfukTVfEAF-rQoz4ID6Z9IJ8-lhM1j8qonvnog=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="The Current Source", url="plugin://plugin.video.youtube/channel/UCw0U6DtO0PHb3l37eKEAdSg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzXxtQN5hw1W-781lUvHsGaJQTh-FOWprvwBg=s100-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Mr Carlson's Lab", url="plugin://plugin.video.youtube/user/MrCarlsonsLab/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJxJC9pyKoM2E2-xiCQIHFBERvMuzFH_h-Ndzw=s144-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="NorCal715 - VCR DVD Receivers", url="plugin://plugin.video.youtube/channel/UCJTrnevHaK73BbOxfteY5Gw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJzhhv4Q5EkpNPy3RGzkvUNIYxNu6uAW71BU8mnY=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="12voltvids - VCR & Receivers", url="plugin://plugin.video.youtube/channel/UCRx5TQd00NOjK5D7VB6pHyA/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJyUdxdzYeXyDsAD5Z-utzFaAALlv0Z_MHSzg9t-=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Duality Repair - Detail Tutorial Amplifier Repair", url="plugin://plugin.video.youtube/channel/UCuwCEerek4ggchL1uHpYnBw/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJykdkXaS0YIX4QiOwZPNVCXC6PfRmEjZL5FOxDI=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Microscope---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="黃信惠的瘋狂教室", url="plugin://plugin.video.youtube/channel/UC2pfQLCfrLWwyJlP31MmmFw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_fxrmvQPy00VG7k7ETklCptsJxS7S_1HfsRAf4=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---VHS DVD Cassettes---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="Repair VHS Machines - Non JVC", url="plugin://plugin.video.youtube/playlist/PL9KRKUL1rqE5rIF5Uf2d2ZWxyDbIAPMfQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRhCQAKOwzNZEyyGc57matYQRlhBqsTSPxxxOGWMg=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Repair The JVC VHS Clones", url="plugin://plugin.video.youtube/playlist/PL9KRKUL1rqE7ASdtkfj4xOCD5QzjSSlLK/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRhCQAKOwzNZEyyGc57matYQRlhBqsTSPxxxOGWMg=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="JCTs Fascinating Hobbies VHS & Car Fix", url="plugin://plugin.video.youtube/channel/UCkh4VF9SMQ9Qt-_i7g8zShg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRhCQAKOwzNZEyyGc57matYQRlhBqsTSPxxxOGWMg=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Repair Radio Cassette Players", url="plugin://plugin.video.youtube/playlist/PL9KRKUL1rqE5N1Vk2ZyYak0hL2UHCUKUZ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRhCQAKOwzNZEyyGc57matYQRlhBqsTSPxxxOGWMg=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---Keyboard Piano---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="[COLOR red]---Speakers---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="Simply Speakers", url="plugin://plugin.video.youtube/channel/UCwCFRpw-O1RO3dlUA9is5gA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRVkybB1-O24n5ElzNVpDNjKLYL2nWPcpYJXNbe=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="DIY Guitar Pedals", url="plugin://plugin.video.youtube/channel/UCGhzS1GbX-yxyBrUJtnUMoA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLReqw7kyo_Hg_e6utv6iQb8sxSLg4dPrkhdN6y0=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="识别电感电阻等电子元件", url="plugin://plugin.video.youtube/kodion/search/query/?q=EmaJRCySx18", folder=False)
    Add_Dir(
        name="万用表笔测量", url="plugin://plugin.video.youtube/kodion/search/query/?q=WRR0XCQ1cHM", folder=False)
    Add_Dir(
        name="【教學】三用電表", url="plugin://plugin.video.youtube/kodion/search/query/?q=Dvg1X1q7kQs", folder=False)
    Add_Dir(
        name="Tool to change a cpu", url="plugin://plugin.video.youtube/kodion/search/query/?q=rEZ7XSREiaQ", folder=False)
    Add_Dir(
        name="Diode Testing", url="plugin://plugin.video.youtube/kodion/search/query/?q=nQpXBHEn09A", folder=False)
    Add_Dir(
        name="A simple guide to electronic components.", url="plugin://plugin.video.youtube/kodion/search/query/?q=6Maq5IyHSuc", folder=False)
    Add_Dir(
        name="Electronics Repair-Methods To Fix Almost Anything", url="plugin://plugin.video.youtube/kodion/search/query/?q=wkAp5x3Z_gc", folder=False)
    Add_Dir(
        name="新手如何入门硬件 一本正经的电子电路入门", url="plugin://plugin.video.youtube/kodion/search/query/?q=1MLYGcNGiys", folder=False)
    Add_Dir(
        name="電路板維修大補帖-海賊王", url="plugin://plugin.video.youtube/kodion/search/query/?q=7AcEt0GNlj0", folder=False)
    Add_Dir(
        name="速修电路板", url="plugin://plugin.video.youtube/kodion/search/query/?q=ZkcVijaa1Lw", folder=False)
    Add_Dir(
        name="燒機大法 Burn in Method", url="plugin://plugin.video.youtube/kodion/search/query/?q=Im303_Hgu7M", folder=False)
    Add_Dir(
        name="燒機大法精準排查", url="plugin://plugin.video.youtube/kodion/search/query/?q=f0zFpPxunoE", folder=False)
    Add_Dir(
        name="維修電路板，各種不同的電子元件，損壞後有什麼特點", url="plugin://plugin.video.youtube/kodion/search/query/?q=DQw0yXijmR4", folder=False)
    Add_Dir(
        name="Electronic Circuit in 11 Minutes", url="plugin://plugin.video.youtube/kodion/search/query/?q=V3A0fxmhYrg", folder=False)
    Add_Dir(
        name="开关电源详解", url="plugin://plugin.video.youtube/kodion/search/query/?q=9LrC2FBk9KU", folder=False)
    Add_Dir(
        name="充电器无输出炸芯片要检查这些元件，电路构成，元件作用详细解读", url="plugin://plugin.video.youtube/kodion/search/query/?q=NAFAPhwBAqE", folder=False)
    Add_Dir(
        name="教你一步一步檢修電路板", url="plugin://plugin.video.youtube/kodion/search/query/?q=i0dHKMbHlUo", folder=False)
    Add_Dir(
        name="维修不通电的电路板", url="plugin://plugin.video.youtube/kodion/search/query/?q=IderqzK6R84", folder=False)
    Add_Dir(
        name="電路板有短路不用拆下來測量", url="plugin://plugin.video.youtube/kodion/search/query/?q=rEXpNtV867I", folder=False)
    Add_Dir(
        name="Where to find schematics", url="plugin://plugin.video.youtube/kodion/search/query/?q=Ii--aTKocTA", folder=False)
    Add_Dir(
        name="Schematics Explain", url="plugin://plugin.video.youtube/kodion/search/query/?q=9cps7Q_IrX0", folder=False)
    Add_Dir(
        name="Board Repair Basics #1 - Schematics & Board View", url="plugin://plugin.video.youtube/kodion/search/query/?q=i293n9VVpHg", folder=False)
    Add_Dir(
        name="Toshiba Regza LCD TV DEAD SET No Power Circuit Diagnosis", url="plugin://plugin.video.youtube/kodion/search/query/?q=AZrVw3XoTTY", folder=False)
    Add_Dir(
        name="DC-DC Buck Converter Tested/Reviewed 电源模块评测", url="plugin://plugin.video.youtube/kodion/search/query/?q=nv8z3BEBMwA", folder=False)
    Add_Dir(
        name="How AC to DC works", url="plugin://plugin.video.youtube/kodion/search/query/?q=RiRyzLl4Y8U", folder=False)
    Add_Dir(
        name="Which AA Rechargeable Battery is Best after 1 Year", url="plugin://plugin.video.youtube/kodion/search/query/?q=-jXQNY6rve8", folder=False)
    Add_Dir(
        name="Are IKEA LADDA Batteries Really Eneloop Pro?", url="plugin://plugin.video.youtube/kodion/search/query/?q=Jeo_hv-8bHI", folder=False)
    Add_Dir(
        name="HOW TO REVIVE A NiCd DRILL BATTERY THAT WON’T CHARGE", url="plugin://plugin.video.youtube/kodion/search/query/?q=ruR42DHJ9tc", folder=False)
    Add_Dir(
        name="Laptop Battery Factory Reset at Home | How to Repair Laptop Battery | Not Working Laptop Battery", url="plugin://plugin.video.youtube/kodion/search/query/?q=QiPbq8vkOPI", folder=False)
    Add_Dir(
        name="Repairing a laptop battery by replacing cells and programming the chip using NLBA1 PRO Tool", url="plugin://plugin.video.youtube/kodion/search/query/?q=HTG135lTuPg", folder=False)
    Add_Dir(
        name="How to Test a Car Battery with a Multimeter", url="plugin://plugin.video.youtube/kodion/search/query/?q=COJr7OB23Hw", folder=False)
    Add_Dir(
        name="Awesome $50 Tiny Spot Welder - Better than Expected - 1031", url="plugin://plugin.video.youtube/kodion/search/query/?q=TI_ZV-5WHi4", folder=False)
    Add_Dir(
        name="Best Budget Battery Spot Welder Kit", url="plugin://plugin.video.youtube/kodion/search/query/?q=AfqioxP4lFE", folder=False)
    Add_Dir(
        name="DIY Battery Spot Welder - Update & Demonstration", url="plugin://plugin.video.youtube/kodion/search/query/?q=b_kGgPVrcCI", folder=False)
    Add_Dir(
        name="Schematicc - 12v Car Battery Tab Welder", url="plugin://plugin.video.youtube/kodion/search/query/?q=nmVqUkNjubk", folder=False)
    Add_Dir(
        name="DIY Spot Welding Using 12V Battery", url="plugin://plugin.video.youtube/kodion/search/query/?q=lmq6RhxcxMA", folder=False)
    Add_Dir(
        name="How to Make USB Rechargeable 9V Li-Ion Battery", url="plugin://plugin.video.youtube/kodion/search/query/?q=NVKh-PCSj3E", folder=False)
    Add_Dir(
        name="Home-made spot welder (very powerfu", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="Repair Attempt - Super Cheap Spot Welder", url="plugin://plugin.video.youtube/kodion/search/query/?q=Zk_ir69kB5Q", folder=False)
    Add_Dir(
        name="鋰電池充不上電", url="plugin://plugin.video.youtube/kodion/search/query/?q=RkOc2omZQQ8", folder=False)
    Add_Dir(
        name="锂电池组坏了修复", url="plugin://plugin.video.youtube/kodion/search/query/?q=iaCp2ZKPV60", folder=False)
    Add_Dir(
        name="维修电器时避免触电", url="plugin://plugin.video.youtube/kodion/search/query/?q=FyIzpXf7mCI", folder=False)
    Add_Dir(
        name="修復電線插頭根部斷了", url="plugin://plugin.video.youtube/kodion/search/query/?q=540JDiW2NU0", folder=False)
    Add_Dir(
        name="Laptop Adapter Disassemble Trick", url="plugin://plugin.video.youtube/kodion/search/query/?q=a00esZ3B-aQ", folder=False)
    Add_Dir(
        name="How to Repair Laptop Charger, No Power Solution", url="plugin://plugin.video.youtube/kodion/search/query/?q=6sJprZNOSU4", folder=False)
    Add_Dir(
        name="How to Open and Fix Laptop AC Adapter without Damaging. DC cable and Capacitors Replacement", url="plugin://plugin.video.youtube/kodion/search/query/?q=nvxkaqxeXsM", folder=False)
    Add_Dir(
        name="Repairing a dead USB Drive?", url="plugin://plugin.video.youtube/kodion/search/query/?q=Ixfy20eKtu4", folder=False)
    Add_Dir(
        name="How to repair switch mode power supply SMPS VERY EASY practical troubleshooting", url="plugin://plugin.video.youtube/kodion/search/query/?q=PPLjXkca7eo", folder=False)
    Add_Dir(
        name="Dell optiplex 9020 Desktop computer blinking orange light", url="plugin://plugin.video.youtube/kodion/search/query/?q=2SY1-TvpDUI", folder=False)
    Add_Dir(
        name="Dell Inspiron orange amber light problem PC will not boot", url="plugin://plugin.video.youtube/kodion/search/query/?q=gYPv6VlftR0", folder=False)
    Add_Dir(
        name="HP Laptop dv6 Overheating Loud Fan Fix on DV6 | DV7", url="plugin://plugin.video.youtube/kodion/search/query/?q=el0B6imb5hg", folder=False)
    Add_Dir(
        name="Things you can make from old, dead laptops", url="plugin://plugin.video.youtube/kodion/search/query/?q=WLP_L7Mgz6M", folder=False)
    Add_Dir(
        name="Transform a Damaged Laptop into an ALL-IN-ONE desktop PC", url="plugin://plugin.video.youtube/kodion/search/query/?q=8jeLCQ62vFk", folder=False)
    Add_Dir(
        name="How to repair LED lamp", url="plugin://plugin.video.youtube/kodion/search/query/?q=l9jFIP6pfvY", folder=False)
    Add_Dir(
        name="How to repair LED lamp 2", url="plugin://plugin.video.youtube/kodion/search/query/?q=0uxOac42qFA", folder=False)
    Add_Dir(
        name="Become A Super Electronics Troubleshooter!", url="plugin://plugin.video.youtube/kodion/search/query/?q=7VBVSEevXaY", folder=False)
    Add_Dir(
        name="*BEST-How To Remove Electronic Components || Soldering Tutorial", url="plugin://plugin.video.youtube/kodion/search/query/?q=D-un9-ZsSQI", folder=False)
    Add_Dir(
        name="When to use Flux ?", url="plugin://plugin.video.youtube/kodion/search/query/?q=tfIwHuGzUEk", folder=False)
    Add_Dir(
        name="Soldering + Tools for (almos", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="Professional Hand Soldering Training", url="plugin://plugin.video.youtube/kodion/search/query/?q=nyele3CIs-U", folder=False)
    Add_Dir(
        name="What Microscope to Buy in 2022", url="plugin://plugin.video.youtube/kodion/search/query/?q=zKUYf4QLh1s", folder=False)
    Add_Dir(
        name="DIY microscope - mobile phone and DVD RW drive hack", url="plugin://plugin.video.youtube/kodion/search/query/?q=auQwOtrUN5A", folder=False)
    Add_Dir(
        name="DIY Video Soldering Microscope", url="plugin://plugin.video.youtube/kodion/search/query/?q=jkFcwL6tAbw", folder=False)
    Add_Dir(
        name="how to make a soldering smoke absorber", url="plugin://plugin.video.youtube/kodion/search/query/?q=wQVD9rniLXA", folder=False)
    Add_Dir(
        name="最簡單的PCB電路板教學", url="plugin://plugin.video.youtube/kodion/search/query/?q=yPJ-4nEXykE", folder=False)
    Add_Dir(
        name="Restoration Old Panasonic M7 VHS 1", url="plugin://plugin.video.youtube/kodion/search/query/?q=izmp20rZhko", folder=False)
    Add_Dir(
        name="Fixing another Panasonic M7", url="plugin://plugin.video.youtube/kodion/search/query/?q=u5Cd6CazaeY", folder=False)
    Add_Dir(
        name="Fixing another Panasonic M7 - Fixed Recording Demonstration", url="plugin://plugin.video.youtube/kodion/search/query/?q=6kBwRcao8dk", folder=False)
    Add_Dir(
        name="Video head swap just for funsies - Shorter Edit", url="plugin://plugin.video.youtube/kodion/search/query/?q=NY-Ih_4buwY", folder=False)
    Add_Dir(
        name="VHS Don't Work - Sylvania DVD/VHS combo......repair??? Shorter Edit", url="plugin://plugin.video.youtube/kodion/search/query/?q=jHBLmnFxRVU", folder=False)
    Add_Dir(
        name="Restoring an Old Panasonic S-VHS Journalist Reporter Camera", url="plugin://plugin.video.youtube/kodion/search/query/?q=yZagwO5jAh8", folder=False)
    Add_Dir(
        name="How to Fix CD or DVD Player No Disc Error - won't play cd", url="plugin://plugin.video.youtube/kodion/search/query/?q=DHpnVLR8TDs", folder=False)
    Add_Dir(
        name="Restoration Digital Piano YAMAHA", url="plugin://plugin.video.youtube/kodion/search/query/?q=JQc_f4HJahs", folder=False)
    Add_Dir(
        name="Restoration herd piano yamaha", url="plugin://plugin.video.youtube/kodion/search/query/?q=WEf_tO-pZus", folder=False)
    Add_Dir(
        name="RESTORATION old electronic keyboard organ", url="plugin://plugin.video.youtube/kodion/search/query/?q=D9UeMPKGiMA", folder=False)
    Add_Dir(
        name="JBL Speaker Repair and Rebuild", url="plugin://plugin.video.youtube/kodion/search/query/?q=x6CCrLz-Zts", folder=False)
    Add_Dir(
        name="Restoration NIKON F50", url="plugin://plugin.video.youtube/kodion/search/query/?q=PfByZJ5RTh4", folder=False)
    Add_Dir(
        name="How I made circuit boards in small batches at home", url="plugin://plugin.video.youtube/kodion/search/query/?q=0Kzd7nf1tWs", folder=False)
    Add_Dir(
        name="How To Make a Table Saw or Bench Saw Machine", url="plugin://plugin.video.youtube/kodion/search/query/?q=df78MqYPVUw", folder=False)

#===============================================================================
#@route(mode='Politics')    
def Music():

    Add_Dir(
        name="Easy FingerStyle", url="plugin://plugin.video.youtube/channel/UCaLcMZJ8bb5KcmfEcetkpJg/", folder=True,
        icon="https://yt3.ggpht.com/ROizSOwxOsR-w7w4zo7zi9Owf2TYIF18oYs9IsrQxolk8HZ6QTvhz9URO7tf4uVbgWMrukhK_A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Alvaro Tejerina", url="plugin://plugin.video.youtube/channel/UC7iaTSOj4ZMLjktrQlpy_9g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9d0MRNRu6_BevWiH6xkPNYUrNPZkQFTuGalAqUqA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Kenneth Acoustic", url="plugin://plugin.video.youtube/channel/UCKK6N8sPcFjX_HijYC1u3Dw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_ipaIZKhUNWzh0y_juqEcjUwGtkbpXRrI3L5D54Q=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="GCH Guitar Academy w/Backing Tracks", url="plugin://plugin.video.youtube/channel/UC0dHs3GB1bfilzqodugN4FA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR0x6slyQB7DF-KQqW2n6oIrvB0lBZFRZ8ieJsp4Q=s176-c-k-c0x00ffffff-no-rj"
)
    Add_Dir(
        name="TVBusa - 萬能和弦", url="plugin://plugin.video.youtube/kodion/search/query/?q=萬能和弦+15634125+4536251", folder=True)

    Add_Dir(
        name="[COLOR red]---PIANO---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="顧峰銘｜Leo小顧老師 - 電子琴教學/從零開始學好伴奏琴", url="plugin://plugin.video.youtube/channel/UC_vUvjulSFR2YvOgbxtRRcQ/", folder=True,
        icon="https://yt3.ggpht.com/K-uRdbta6PW_pzpIamKardDjhGvmkYMTEqZ83Gyz4g3Qin1iJm70JPmdKDNFTjRYeXQmsr8c75M=s176-c-k-c0x00ffffff-no-rj"
)
    Add_Dir(
        name="TVBusa - The most overplayed piano songs", url="plugin://plugin.video.youtube/kodion/search/query/?q=The%20most%20overplayed%20piano%20songs", folder=True)

    Add_Dir(
        name="Jane - ***Check Playlist***", url="plugin://plugin.video.youtube/channel/UCidvz_O5zdX7z2mr4zkeL2g/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu_0iOmIhF6O6WbBT3CsgpfU1C1QN8BlV2SJRxlS=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="崔松钢琴", url="plugin://plugin.video.youtube/channel/UCeiBl3UA5t7256PBtSCAIYA/", folder=True,
        icon="https://yt3.ggpht.com/8RsC84_wIK64srfgCM6E_Wl7RcexjOe6cFn9T_WtTgL221M7Pisy3vyuV__u_Z3Jf1VcpbcXMzI=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="钢琴教学-小马老师", url="plugin://plugin.video.youtube/playlist/PL4rQPPPs3AS6DnpskUbTSBzg7Mr9aotY0/", folder=True,
        icon="https://yt3.ggpht.com/ls0mCopOHRuTJWq5KJh4c_4giNbS-J4J_JEstIgFNM28j6wz7lbM91jrwco1r17aJhWeF6AIeQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Easy Piano By Rachel", url="plugin://plugin.video.youtube/channel/UCVepD_8t4dN-6pgtbF9yczQ/", folder=True,
        icon="https://yt3.ggpht.com/6fJb5Yu761hfUtp6Qy4Pk443t6tbrb9T7U0QDoB5yN-nIp35TzgAIiOlRmXS2tTgX6knw6BVRg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="PianoSecrets", url="plugin://plugin.video.youtube/channel/UCoWephf6BHEEuWrDOra6_LA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu8YN83g4YZALP0jPt96w2cK3YtuoRThYnIuuQAf8w=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Jazz Classical Music Studio - JCMS", url="plugin://plugin.video.youtube/channel/UCZ_GpwojtS8ZFt4cA3aWv8g/", folder=True,
        icon="https://yt3.ggpht.com/uwVH2snILRRKANpJsGuj3CwBRawVYQeQiMI5M9X_-5w8YqsqOTpdzAEhjhhIi26MIrHkpXPp1Q=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="钢琴教学-音乐人生Music Life", url="plugin://plugin.video.youtube/playlist/PLhtGVmiShRe9PW2iFpAVmaE1WF3R_cWO6/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSiZm1q5ET22O7QBKaFRIcNg_P74NXVC8WdL9o=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="MasterClass Piano Studio", url="plugin://plugin.video.youtube/channel/UCyw8UzaFCV-GWkTMEjz2BYA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu90AmVa_-RXP3293JwEByHN6En2wtTfrKsCRTbI4w=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="茶玲Charlene Lynn", url="plugin://plugin.video.youtube/channel/UCARb7t-oS6Xy3hVZHzUpM2A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTNSueDV5HUrQyOU8sYs6gk79QuFBD19bqd7srIEA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="鋼琴自學曲（簡易）-Boon Chuan文川", url="plugin://plugin.video.youtube/playlist/PL7HhXwPfSUi_vUMOlUU2_NcqhYBInUYiL/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-yGYPCTCTtFCnBLT752bPWfZwJxqdMVS0dpkkloA=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Piano with Rachel", url="plugin://plugin.video.youtube/channel/UCWnpx4hwcPl_vaffPwbNm5A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu8bWAHGg4pBEDIFUpfTNMYh0SLHX7JWEfJ28__O=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="薛汀哲", url="plugin://plugin.video.youtube/channel/UCJhWjLYteCKBaiFdnrSnLUw/", folder=True,
        icon="https://yt3.ggpht.com/SCFu6zmpOStDU6O7tPY2RiynQ-grgO-tanAVqLVpNyrO7hLlx2jHAniKtSR5HsvWg5FPpgkE=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="钢琴大师装小白去蹭课，给老师整不会了", url="plugin://plugin.video.youtube/playlist/PLhtGVmiShRe_WGHK0rBR65CPBHK0taXqg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSiZm1q5ET22O7QBKaFRIcNg_P74NXVC8WdL9o=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Jacob's Piano", url="plugin://plugin.video.youtube/channel/UClQPk2WbC23z3eogxPbbOjw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR3mQRDPHYwCK8Eid6qKB0GkvU6zvlJT39F8EiV_A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Penney零基础学钢琴", url="plugin://plugin.video.youtube/channel/UCCnATk0U9H4sz-Bx1pfm7fA/", folder=True,
        icon="https://yt3.ggpht.com/OpgUpdQ2SBC2H_qcqGzZBtxXppdRuOfkYIqff8HFE4uPXaihHGxLKLzb3JbTvcf66-gu6yqP=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="artcclee", url="plugin://plugin.video.youtube/channel/UC5jzCKbpOx7L6fPVJedHsaA/", folder=True,
        icon="https://yt3.ggpht.com/PCPoW5u9T8uaG-Vv2D79dhWAhI5i1FYU7GLE0sDGxevp26OQyuA-KztFcvTJVDCWAv_8uOVd_V0=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Your Piano in April", url="plugin://plugin.video.youtube/channel/UCkGuU475pORu9Ti5t21tYWA/", folder=True, 
        icon="https://yt3.ggpht.com/ytc/AMLnZu_g_2Y7qdIMdl3Ce2lltOqfmcWrly9zPo8paC4v=s176-c-k-c0x00ffffff-no-rj"
)
    Add_Dir(
        name="TVBusa - Tommy Emmanuel Lessons", url="plugin://plugin.video.youtube/kodion/search/query/?q=Tommy+Emmanuel+lesson", folder=True)

    Add_Dir(
        name="Tommy Emmanuel", url="plugin://plugin.video.youtube/channel/UCL-0gAth4u6Wp-9_98XU3nA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQeIBMlqgQluDZ7HwJrtLcH5A9niGzOG9tSGiAUGg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="TVBusa - Pentatonic Scale Pattern", url="plugin://plugin.video.youtube/kodion/search/query/?q=How%20to%20Play%20Pentatonic%20Scale%20Pattern%20%23", folder=True)

    Add_Dir(
        name="Brian Kelly", url="plugin://plugin.video.youtube/channel/UCVD9PqYtkDkLUqKuzv4A5_Q/", folder=True,
        icon="https://yt3.ggpht.com/r67zBc0vC3LgXXmcUv5y1v2naDSuhxhUCKqkRsyzgci9M8QsfQBwki5rrIU91I0U7G1eigYE=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Karen Ramirez", url="plugin://plugin.video.youtube/channel/UCQ8YJp_aCOrdw6rEHoBhKFQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLT1lH5EYxX1eDj7k_T8tNCw4dzgNVv-LmdcsQVnxg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Joanne Cooper - scrolling guitar chords and lyrics", url="plugin://plugin.video.youtube/channel/UCjI7TEV4o-mrozJqp9Ltb2A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSydeQTzHHsYzyFrMRffISIFhn9puBSrQDAH93g=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Larry Lawver - scrolling guitar chords and lyrics", url="plugin://plugin.video.youtube/channel/UCHQxMXges2KEY1uuKicCiew/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSwQfs0wLLFSQBz4sx0S-x9CblL6N7OmFFRBUQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Mark Orwoll - scrolling guitar chords and lyrics", url="plugin://plugin.video.youtube/channel/UCkZ7-rgcOj76KjCtVMQAbjg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS-c-IOOeDkuTTtlUCsLosZML4Bu6y31bzpG_Pg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Celeste Sky - scrolling guitar chords and lyrics", url="plugin://plugin.video.youtube/channel/UCG5fqE_TsfYIeO7aZxyKSQw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSnw2aDhXfeSdv43TIiczvLyLbAmu2TjjJQ58u1Hw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Guitar Tutor - scrolling guitar chords and lyrics", url="plugin://plugin.video.youtube/channel/UC8goEmlfLhmvXpoMim7fstA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSplb6g8lZuqy2veNxMFfqlOM5qGInadANidfftzg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Eazy Chords - scrolling guitar chords and lyrics", url="plugin://plugin.video.youtube/channel/UCpGyAo6diwE-TazMsoun71w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTBrH1QaltjoPDgJya7x-zdM2zk0jhN4VNekrmP=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Top Culture - Most Popular Songs 50s-90s, Top 20 songs", url="plugin://plugin.video.youtube/channel/UCO9plH-xSTKb_B09W4-9WFg/", folder=True,
        icon="https://yt3.ggpht.com/DTpKCF6DHpMF519qgkpL-SRVS9RvRKCYW8Om_gAbZkl-dGzIfIJgsVieaDPszqRPk0ZLji2G=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Beatles - Piano", url="plugin://plugin.video.youtube/playlist/PLgFciijspCcbHk18iqy_LxC0p5MVS0pYe/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQIPYhhBvTEGzj-O7sP_FYZ8k5tMhwh8L4L-Q=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Beatles Guitar Secrets", url="plugin://plugin.video.youtube/channel/UCe8V_SYjLoXs33AybZypQfA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSNoJktduWIB2MA_Kyj81FiHctFLdnGHdgbp9p1=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="The Beatles", url="plugin://plugin.video.youtube/channel/UCc4K7bAqpdBP8jh1j9XZAww/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQtfVXxV5GWXfTAvbfQXml5WQiGjTXlGRWFY04pIg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Simon & Garfunkel", url="plugin://plugin.video.youtube/channel/UCvj9Q8jeaaXlj2OprcRraaw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRpi0_lycqLsmgCIRW27l7e2Jxg8aEVigER9oT1=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="BeeGees", url="plugin://plugin.video.youtube/channel/UCD9sCcKXnFxMeuFoNayVxeQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLRV6Vbd37lbpwF8dxhCiQpA-C39rLo8lpduQoHayA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Hermans Hermits 1965", url="plugin://plugin.video.youtube/channel/UC6UtQTcBGN6VEp5jtPR_u_w/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQJNDDD52AzLshfacbb6Ol6bhXIljAji5UwrWNC=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="The Rolling Stones", url="plugin://plugin.video.youtube/channel/UCB_Z6rBg3WW3NL4-QimhC2A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSu7WcE_ngO_tpQnZh-5dscheNaKvzwkOubAOxMwbQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Jamming - Beatles etc & Piano", url="plugin://plugin.video.youtube/channel/UCQqKnKnnRRMjisvuaEV7RTw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQIPYhhBvTEGzj-O7sP_FYZ8k5tMhwh8L4L-Q=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Backing Tracks - Best Songs Backing Tracks", url="plugin://plugin.video.youtube/channel/UCqW3saYRQTO8WzsKacgaJNQ/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQ7WB3068qHFE6UhsO_bHeirYtyzV1gQOBcednvHQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Backing Tracks - Innkeeper Studio Backing Tracks", url="plugin://plugin.video.youtube/channel/UC1_BayJnxHEaA1TrkWwSvNw/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQXx3K52iFglcNFCDJ9EFxC_Z1rfI8EDwwbchreZA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Backing Tracks - Guitar Backing Tracks For You", url="plugin://plugin.video.youtube/channel/UCd1PQd7qUTosxHNOwh5kHuQ/playlists/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLS26Ts_-7MESSxQajNFAXl60sMwvyqm61UzyC-2=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Backing Tracks - The Shadows & Others", url="plugin://plugin.video.youtube/playlist/PLYbiu-B7vr9eH99wpnAtVMj649swV24eX/", folder=True,
        icon="https://yt3.ggpht.com/LbAtahQgOtWfEpzs2ZFI_s-arBSEW6FbTrApN5L7ihlDRYNxhMQ_HIYSGzDEPkbsrRMKGaD4aw=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="StewMac-Guitar Repair", url="plugin://plugin.video.youtube/channel/UCdr6rJVSSx54ByuY5U2ohTQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTHkFbIKx4O4bRZunIJKPtObG-IiObYtRSQ5ott=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="ENYA MUSIC", url="plugin://plugin.video.youtube/channel/UCPGMkhNZfug9QjwCcEAyvLw/", folder=True,
        icon="https://yt3.ggpht.com/fcHhxAeo-leXEMazFOeu1RQJCRgL0E0Q6Epy3zBhcQaHG9NciYoLsqomkhD1J4xS6_D-xq7qbA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="LumBeat", url="plugin://plugin.video.youtube/channel/UCYr3b0FfZSWeEM-A85zf9HQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTOOvcg7bhjXlFjz9LX7I4pCSROsWotTdyCfn6Fbw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Jeremy See", url="plugin://plugin.video.youtube/channel/UCX_BIKUbuMXLq-VebU8LmBA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQPTtCIbOC6M7e0beuNXoLAqwJY-2NxZH9LOcHWjHc=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="工聯會譚sir教 電子琴", url="plugin://plugin.video.youtube/channel/UC8KSfrgWGXO3E9jJvqDSVoA/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AMLnZu-6Irh2fRfgC2vVlN07eUlDHto_eXPyAslCUA_CqbbncRKvaan0Qlsq1_IYPrmC=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="HDpiano", url="plugin://plugin.video.youtube/channel/UCCMo6F7pLIg_xF0wD-M6oHQ/", folder=True,
        icon="https://yt3.ggpht.com/LlDVpqMRwdsdW5JG74qm1F7DT3LLx7F0Pd0SvD5d-9ITHv0e44sLTrgKqY6uU2TyoKISo-ky2w=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="PHianonize", url="plugin://plugin.video.youtube/channel/UCts9lFixyOqwhGCEbXErPwA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSCphNi_wRaQdgjPGvXQi2BX_YbvHXTdjGhm-OWZQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Free Piano Tutorials", url="plugin://plugin.video.youtube/channel/UCBlE6pjsULp5gA7vl8-4F4A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR-ExK9s2lrz5tId6V9WUYEJYQ2QYkFDSf_xVfL=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Jacob's Piano", url="plugin://plugin.video.youtube/channel/UClQPk2WbC23z3eogxPbbOjw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR3mQRDPHYwCK8Eid6qKB0GkvU6zvlJT39F8EiV_A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Fur Elise Playlist", url="plugin://plugin.video.youtube/playlist/PLKBRHzyVsSQOh_BeFxLPh-MA1xGKs0IUM/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l785u6sQF-clevje6FwqIs0k81ZntWgXuSEnYg=s288-c-k-c0xffffffff-no-rj-mo"
)

    Add_Dir(
        name="Piano In 21 Days", url="plugin://plugin.video.youtube/channel/UCY_UFcJ5Mktc1fH1SNQwrUQ/", folder=True,
        icon="https://yt3.ggpht.com/-HnFVquKQugs/AAAAAAAAAAI/AAAAAAAAAAA/-vKIerhM5MI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg"
)

    Add_Dir(
        name="Lypur Piano-Theory", url="plugin://plugin.video.youtube/channel/UCpzgTNTgQsR9YYsyOm3k3KQ/", folder=True,
        icon="https://yt3.ggpht.com/-1KyjFXrXOvk/AAAAAAAAAAI/AAAAAAAAAAA/h6vqXQ-DI5s/s100-c-k-no-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="PlayPianoTODAY.com", url="plugin://plugin.video.youtube/channel/UCA-oSxA0_mTwtvEdOX4yMdA/", folder=True,
        icon="https://www.playpianotoday.com/images/play-piano-today-logo_segno.png"
)

    Add_Dir(
        name="Learn piano in 10 lessons", url="plugin://plugin.video.youtube/user/danthecomposer/", folder=True,
        icon="https://yt3.ggpht.com/-bS0JaBhU1rw/AAAAAAAAAAI/AAAAAAAAAAA/Y26mWoChix0/s100-c-k-no-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="The Online Piano and Violin Tutor", url="plugin://plugin.video.youtube/user/theonlinepianotutor/", folder=True,
        icon="https://yt3.ggpht.com/-6h1R3UqbjE4/AAAAAAAAAAI/AAAAAAAAAAA/GzBJZ8gN4DA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="ImprovPianoTips", url="plugin://plugin.video.youtube/user/ImprovPianoTips/", folder=True,
        icon="https://yt3.ggpht.com/-2m0gbpt80dA/AAAAAAAAAAI/AAAAAAAAAAA/jmsVzjyotpQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="InstantPianoGenius", url="plugin://plugin.video.youtube/user/InstantPianoGenius/", folder=True,
        icon="https://yt3.ggpht.com/-TKw8d4JevQA/AAAAAAAAAAI/AAAAAAAAAAA/NvPGW0VxoXk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="[COLOR red]---GUITAR---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="JustinGuitar Songs", url="plugin://plugin.video.youtube/channel/UCcZd_G62wtsCXd-b7OhQdlw/", folder=True,
        icon="https://yt3.ggpht.com/-J5JjwMbMlbg/AAAAAAAAAAI/AAAAAAAAAAA/79T6mW1XlKU/s100-c-k-no-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="JustinGuitar", url="plugin://plugin.video.youtube/channel/UCBNkm8o5LiEVLxO8w0p2sfQ/", folder=True,
        icon="https://yt3.ggpht.com/-5lZN4lWqIJ4/AAAAAAAAAAI/AAAAAAAAAAA/OTjz43hchDk/s100-c-k-no-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="MyTwangyGuitar", url="plugin://plugin.video.youtube/user/MyTwangyGuitar/", folder=True,
        icon="https://yt3.ggpht.com/-gyXJb8NWsdM/AAAAAAAAAAI/AAAAAAAAAAA/xxpA9QXdgAM/s100-c-k-no-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="Paul Davids", url="plugin://plugin.video.youtube/channel/UC_Oa7Ph3v94om5OyxY1nPKg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR2-EU0Trb-w4N-jvypFVSvuww6k5mIPrPMSNQhYFA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Shutup & Play", url="plugin://plugin.video.youtube/channel/UCAwuvzhah0KUw5QNihSkEwQ/", folder=True,
        icon="https://yt3.ggpht.com/a/AGF-l7_JFfWodMR50UkfIBtBXdeSPqh4VAFcjUZT5A=s288-mo-c-c0xffffffff-rj-k-no"
)

    Add_Dir(
        name="Six String Country", url="plugin://plugin.video.youtube/user/sixstringcountryhd/", folder=True,
        icon="https://yt3.ggpht.com/-ymMAMBus87Y/AAAAAAAAAAI/AAAAAAAAAAA/dkTJASKtEp4/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="The-Art-of-Guitar", url="plugin://plugin.video.youtube/user/PitchfeverAcademy/", folder=True,
        icon="https://yt3.ggpht.com/-N3rRevMqvTc/AAAAAAAAAAI/AAAAAAAAAAA/7ZmUK9fvLuI/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="Music is Win", url="plugin://plugin.video.youtube/channel/UCshiNtfJ7Dj3nlh41a6M-kg/playlists/", folder=True,
        icon="https://yt3.ggpht.com/-sPtteb8ZlvU/AAAAAAAAAAI/AAAAAAAAAAA/CHIkPrlQWCA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="GuitarZoom.com", url="plugin://plugin.video.youtube/channel/UCpuRSQ79vgNyg2H4M_JVFew/playlists/", folder=True,
        icon="https://yt3.ggpht.com/-MnBmUASpw70/AAAAAAAAAAI/AAAAAAAAAAA/apQY4Y0GlgY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="Guitar Tricks", url="plugin://plugin.video.youtube/user/Guitartricks/", folder=True,
        icon="https://yt3.ggpht.com/-G1Fdflt3Od0/AAAAAAAAAAI/AAAAAAAAAAA/p9r8ykQCBQI/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="Brandon Acker", url="plugin://plugin.video.youtube/channel/UC-GiI_5U-WkPIKqsq056wvg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLT6ZJisZ1xP5B3keGhhnwQdwy4exBEyK0qX0i5qVA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="LoremaryluGT", url="plugin://plugin.video.youtube/user/loremarylugt/", folder=True,
        icon="https://yt3.ggpht.com/-L4Z7tEQfvLU/AAAAAAAAAAI/AAAAAAAAAAA/tcEVhiRPXPs/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="EricBlackmonGuitar", url="plugin://plugin.video.youtube/user/EricBlackmonGuitar/", folder=True,
        icon="https://yt3.ggpht.com/-1LYFNwMrM40/AAAAAAAAAAI/AAAAAAAAAAA/6Nsk4qlvSOU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="Music is Win", url="plugin://plugin.video.youtube/channel/UCshiNtfJ7Dj3nlh41a6M-kg/", folder=True,
        icon="https://yt3.ggpht.com/a/AATXAJx7cWXWvF_7IlE8OKpMW9hDB6BeWCZYOr-YgZannw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="好和弦", url="plugin://plugin.video.youtube/channel/UCVXstWyJeO6No3jYELxYrjg/", folder=True,
        icon="https://yt3.ggpht.com/-hz6hRRT9waU/AAAAAAAAAAI/AAAAAAAAAAA/w1JVkBPKBGQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="嘎老師(唱歌)", url="plugin://plugin.video.youtube/channel/UCJdMrdkCXs5FkR3DHlor81w/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAzE4oFWMFoNayQWRo24ygpTOwqs8IyLQed4qg=s288-mo-c-c0xffffffff-rj-k-no"
)

    Add_Dir(
        name="Steven Law", url="plugin://plugin.video.youtube/channel/UCG_HoVmf9ygvZOtWJt8_6VA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwngqEpojQRFIxnO2p1bpPMoFBgZjcbIdMIslQKfIgw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="樂活道", url="plugin://plugin.video.youtube/channel/UC-h2ZboS8gY4RXRXxJi2n9A/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwnh5a9SmpcSdYCMRPA7jxEy4csqY-LQzzWuTeUIz=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Tommy Chan", url="plugin://plugin.video.youtube/channel/UC8OoNLr6n4E8Gb6EEq68AnQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLTDd4zL5N8IrjjXrm8YaGkLCWHFHefmvGT8YM0Qqg=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="葉宇峻彈吉他", url="plugin://plugin.video.youtube/channel/UCGIe9rj-cpg9rskn0kwlF2Q/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR9_OTVLb5M8RgogEMNtaUdFkNqSRJImhoQP1JtaWA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Guitar Josa 喬莎宏", url="plugin://plugin.video.youtube/channel/UCqLpLJT7CrR6SawBFwy_Tww/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQgGIAwSFvnebXEkq1-_uKZhVjFwKXtVHWFl4QWAw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="The Ukulele Teacher", url="plugin://plugin.video.youtube/channel/UC1HlihY-iNtOemAlYQq3GXQ/", folder=True, 
        icon="https://yt3.ggpht.com/-7PP4UcxiVCc/AAAAAAAAAAI/AAAAAAAAAAA/rKKKi4-cc6M/s100-c-k-no-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="吹口琴的小园园", url="plugin://plugin.video.youtube/channel/UCsVX4NKKFhUjjlvG3Ks1uXQ/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9rpMc2ov6d2myimK1eWMN42A3q_F-QSUe-c37J=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="[COLOR red]---DRUM---[/COLOR]", url="", folder=False)

    Add_Dir(
        name="Drumeo", url="plugin://plugin.video.youtube/channel/UCBiJBaDaM3K6vPVggLhTyWA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AAUvwniunA-ENhFfzXiIu3IjOfOzopLEPPOueP8IVY6U=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Chinaguitarsceptic", url="plugin://plugin.video.youtube/channel/UCc0X6O--9ahFR2mD6cSjtFg/", folder=True,
        icon="https://yt3.ggpht.com/-ggZXfHNcnFw/AAAAAAAAAAI/AAAAAAAAAAA/MKdY5Jl1aT4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg"
)

    Add_Dir(
        name="Studio Hacks", url="plugin://plugin.video.youtube/channel/UCwGi6MHx2xagkcQXpDCxARA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu-RlLz5kRgyMSqtMldPjUnQMSJUHD8At2bqfsBO=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="David Bennett Piano ", url="plugin://plugin.video.youtube/channel/UCz2iUx-Imr6HgDC3zAFpjOw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLR07przZZD38vGiUE0vxWBEevn47I-wnNeAG1nJGQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="伍仲衡 Harry Ng", url="plugin://plugin.video.youtube/channel/UCm0bgg5Ihdv8vA4SWIFn1Vg/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLQ6-xiX5_FfiHUyYNhzpvHIB1ZyqgeAu_MbA5M7=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="The Clark Family Creative", url="plugin://plugin.video.youtube/channel/UCDA5r8KAXgg1lJasipG0fRA/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AKedOLSWD6_73_FJQk9MW1ZbyLWpqDdGiwVzGiqLGOOo=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Emily Linge", url="plugin://plugin.video.youtube/channel/UCW1W7bKWpL9k-V00HG4v_mQ/", folder=True,
        icon="https://yt3.googleusercontent.com/4ZnqLWZRytQZqp_GunTb9H28-CDgsimlTRWa31s-RZZmhPp40ZvnaYFb7TvrIXHK7_zz7e0kskQ=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="老歌专递", url="plugin://plugin.video.youtube/channel/UCL_e2VOdcyFzKUr1JQD2-og/", folder=True,
        icon="https://yt3.ggpht.com/DueR-XvXMaVYudatWBXcZ4Fc1ktLUoymLMkMIoyjOG0n6dg2Zb_czVJ5X6_VTiWMyZOC5VWR8g=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="EDM Music One Hour", url="plugin://plugin.video.youtube/channel/UCVczud9dhs1HQewgIzPwMZw/", folder=True,
        icon="https://yt3.ggpht.com/ytc/AMLnZu9I4o7o7hMMB9w2ep6ImaxBMCYg0CvjnuThbxOX=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="moving music", url="plugin://plugin.video.youtube/channel/UCiMsgKFzK7NOV7icRyEKS7A/", folder=True,
        icon="https://yt3.ggpht.com/rqagKHbYpP4RRCqmDrR8yGeofzPbhu49QYDGhCF7Htm6UKdcDr1pMLPTEVZbk4JYduJxKMqHBw=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="大胜歌歌", url="plugin://plugin.video.youtube/channel/UCQRzD4XXt069cITkNUwcbXA/", folder=True,
        icon="https://yt3.googleusercontent.com/G5FwTJExb7FP-O05mZ-rmAKDXV66O-D62W3ORHud4ErNOGvjByMIjimrHzOxYBYqnUg2w9YwBA=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="旗凡-流行歌曲", url="plugin://plugin.video.youtube/playlist/PLkHe1BBmtZOxYO8jlIO-zgPkDbe_MllC6/", folder=True,
        icon="https://yt3.ggpht.com/5CPb_cfuYFtdz9S5opB4FLUCTOV_OJGvzBUkQ5I_ej15f0isJ6sa1wV_GAwO3tq1dkJJySu6gJs=s88-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="nganhp", url="plugin://plugin.video.youtube/channel/UCxiqWDueaYFYju-ZiiIo6HQ/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJX6DyNul8qItcha_4-ZhuQYcgY1FbXCKobiithX2A=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="M&S Band", url="plugin://plugin.video.youtube/channel/UCBn0JJophOYziYAdyFn3KNw/", folder=True,
        icon="https://yt3.googleusercontent.com/ytc/AL5GRJUP1j2Qm_CowIvd94L65d8pDFvUaUtwhROwpKia=s176-c-k-c0x00ffffff-no-rj"
)

    Add_Dir(
        name="Tommy Emmanuel Teaches Variations in Freight Train", url="plugin://plugin.video.youtube/kodion/search/query/?q=rxF_gkKVJ1s", folder=False)
    Add_Dir(
        name="如何彈一首歌 yesterday", url="plugin://plugin.video.youtube/kodion/search/query/?q=UOBljA2ghnw", folder=False)
    Add_Dir(
        name="John Mayer 的 finger style", url="plugin://plugin.video.youtube/kodion/search/query/?q=Tqr2B4STP0Q", folder=False)
    Add_Dir(
        name="專業 funk mute 線技巧", url="plugin://plugin.video.youtube/kodion/search/query/?q=NktSJt1jeXQ", folder=False)
    Add_Dir(
        name="Sweep Picking is Easy!!! Fix your sweep picking in 3 steps!", url="plugin://plugin.video.youtube/kodion/search/query/?q=updKgh2vZtU", folder=False)
    Add_Dir(
        name="怎樣彈fusion rock sweep picking", url="plugin://plugin.video.youtube/kodion/search/query/?q=kgGJXke1eco", folder=False)
    Add_Dir(
        name="如何 Sweep picking and tapping", url="plugin://plugin.video.youtube/kodion/search/query/?q=Dwpot1xQQ64", folder=False)
    Add_Dir(
        name="吉他教學#02 - 如何把五聲音階的指型 全部串聯起來 !!!", url="plugin://plugin.video.youtube/kodion/search/query/?q=JQ8Bs5AyqlI", folder=False)
    Add_Dir(
        name="2022年學習指南", url="plugin://plugin.video.youtube/kodion/search/query/?q=av0I-VW4xIo", folder=False)
    Add_Dir(
        name="Guitar Loop Pedal for one second", url="plugin://plugin.video.youtube/kodion/search/query/?q=627_yZVs1Pw", folder=False)
    Add_Dir(
        name="萬能和弦15634125手到拿來", url="plugin://plugin.video.youtube/kodion/search/query/?q=ZJ1kUPJ6RL4", folder=False)
    Add_Dir(
        name="萬能和弦 4536251 原理解析", url="plugin://plugin.video.youtube/kodion/search/query/?q=HPDmw9N8Vws", folder=False)
    Add_Dir(
        name="萬能和弦 15634125 卡农万能和弦15634125，学会就能伴奏上百首流行歌曲", url="plugin://plugin.video.youtube/kodion/search/query/?q=94qM6NpoEYk", folder=False)
    Add_Dir(
        name="萬能和弦 15634125 学会这个和弦，轻松弹奏一百首流行歌！", url="plugin://plugin.video.youtube/kodion/search/query/?q=dOhWZN7Gq38", folder=False)
    Add_Dir(
        name="新万能和弦 6451", url="plugin://plugin.video.youtube/kodion/search/query/?q=mE2MnqU4O6s", folder=False)
    Add_Dir(
        name="5 things I wish I'd known when learning piano [IMPORTANT]", url="plugin://plugin.video.youtube/kodion/search/query/?q=jg_Nf_26R7c", folder=False)
    Add_Dir(
        name="学会这些技巧，即兴你也行！(要有肌肉记", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="【钢琴】双手协调的正确打开方式", url="plugin://plugin.video.youtube/kodion/search/query/?q=QpwLZcQzcgw", folder=False)
    Add_Dir(
        name="【钢琴】万能左手伴奏模式", url="plugin://plugin.video.youtube/kodion/search/query/?q=C50om8wfvVQ", folder=False)
    Add_Dir(
        name="三招左手伴奏织体 弹唱无数首流行歌曲", url="plugin://plugin.video.youtube/kodion/search/query/?q=1Q3Z48fuVUc", folder=False)
    Add_Dir(
        name="【一次性搞懂钢琴核心技术 】成人学琴从零开始进阶之路", url="plugin://plugin.video.youtube/kodion/search/query/?q=vSqoWFauosM", folder=False)
    Add_Dir(
        name="【周杰伦】最伟大的作品 钢琴教学", url="plugin://plugin.video.youtube/kodion/search/query/?q=1pWzd7AfOp4", folder=False)
    Add_Dir(
        name="Flea Waltz - Flohwalzer - EASY Piano Tutorial", url="plugin://plugin.video.youtube/kodion/search/query/?q=4RTOIp8kr3g", folder=False)
    Add_Dir(
        name="HOW TO PLAY - Flea Waltz (Flohwalze", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="'Heart and Soul' Absolute Beginners Piano Lesson Song 1", url="plugin://plugin.video.youtube/kodion/search/query/?q=lljsbdifaOs", folder=False)
    Add_Dir(
        name="Heart and Soul Piano Tutorial - Both Parts!", url="plugin://plugin.video.youtube/kodion/search/query/?q=LtU1bw0U42U", folder=False)
    Add_Dir(
        name="Play Heart and Soul (Famous Piano Duet", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="The Most Overplayed Piano Songs Pt.1", url="plugin://plugin.video.youtube/kodion/search/query/?q=oRKRewJlyuk", folder=False)
    Add_Dir(
        name="The Most Overplayed Piano Songs Pt.2", url="plugin://plugin.video.youtube/kodion/search/query/?q=ooG62I7mvTs", folder=False)
    Add_Dir(
        name="The Most Overplayed Piano Songs Pt.3", url="plugin://plugin.video.youtube/kodion/search/query/?q=MkBDNEb3rHQ", folder=False)
    Add_Dir(
        name="The Most Overplayed Piano Songs Pt.4", url="plugin://plugin.video.youtube/kodion/search/query/?q=redOPfAvlpg", folder=False)
    Add_Dir(
        name="Proper Hand Posture At The Piano", url="plugin://plugin.video.youtube/kodion/search/query/?q=rZznie6UU_o", folder=False)
    Add_Dir(
        name="《哈农》引言 坐姿手型在钢琴学习中的重要性 第一集（持续更新中）", url="plugin://plugin.video.youtube/kodion/search/query/?q=iZc3-nANh1Q", folder=False)
    Add_Dir(
        name="看五线谱还在从中央C开始数音？一个视频记住超多音符！", url="plugin://plugin.video.youtube/kodion/search/query/?q=o5p15cvndPw", folder=False)
    Add_Dir(
        name="【快速学会弹钢琴】初级一度音阶练习||快速打好弹琴基础||调号，半音，大调音阶，升号，降号，8度", url="plugin://plugin.video.youtube/kodion/search/query/?q=bl8gvxiu4SU", folder=False)
    Add_Dir(
        name="How To Read Music", url="plugin://plugin.video.youtube/kodion/search/query/?q=w3QwUaJai8c", folder=False)
    Add_Dir(
        name="How To Read Notes", url="plugin://plugin.video.youtube/kodion/search/query/?q=gEI7uYOCQXo", folder=False)
    Add_Dir(
        name="How To Read Accidentals (Sharps, Flats, Natural", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="Chord Substitution", url="plugin://plugin.video.youtube/kodion/search/query/?q=IGBcnFSJb4c", folder=False)
    Add_Dir(
        name="How to play River Flows In You", url="plugin://plugin.video.youtube/kodion/search/query/?q=jWifCal6LxI", folder=False)
    Add_Dir(
        name="How To Play: Yiruma - River Flows In You | Piano Tutorial Lesson + Sheets", url="plugin://plugin.video.youtube/kodion/search/query/?q=UtcZPv2IV8M", folder=False)
    Add_Dir(
        name="How to play RIVER FLOWS IN YOU on Piano Tutorial - EASY - Full Song - Yiruma", url="plugin://plugin.video.youtube/kodion/search/query/?q=9T8cnch9Klg", folder=False)
    Add_Dir(
        name="River Flows In You - Yiruma | EASY Piano Tutorial", url="plugin://plugin.video.youtube/kodion/search/query/?q=w7mole4Cfak", folder=False)
    Add_Dir(
        name="Track in Time - Dennis Kuo", url="plugin://plugin.video.youtube/kodion/search/query/?q=8pziPr0F9T4", folder=False)
    Add_Dir(
        name="如何彈好夢中的婚禮", url="plugin://plugin.video.youtube/kodion/search/query/?q=puPxy8qLXik", folder=False)
    Add_Dir(
        name="假如爱有天意", url="plugin://plugin.video.youtube/kodion/search/query/?q=m4jofCKHoMY", folder=False)
    Add_Dir(
        name="3 Easy Classical Piano Pieces - Canon Moonlight Prelude", url="plugin://plugin.video.youtube/kodion/search/query/?q=E-r8eM887Yg", folder=False)
    Add_Dir(
        name="Alan Walker - Faded | EASY Piano Tutorial", url="plugin://plugin.video.youtube/kodion/search/query/?q=iWbKrq-oEJo", folder=False)
    Add_Dir(
        name="成人学钢琴一年可以弹成什么样？", url="plugin://plugin.video.youtube/kodion/search/query/?q=M5rS0AN1aCA", folder=False)
    Add_Dir(
        name="無歌係執唔到", url="plugin://plugin.video.youtube/kodion/search/query/?q=xmVzeLcf7Zc", folder=False)
    Add_Dir(
        name="How to Play By Ear INSTANTLY 🎹 [Ear Training Explained]", url="plugin://plugin.video.youtube/kodion/search/query/?q=3sXrWz763J8", folder=False)
    Add_Dir(
        name="How to Easily Learn Songs by Ear", url="plugin://plugin.video.youtube/kodion/search/query/?q=e1a74c-9m6M", folder=False)
    Add_Dir(
        name="Easy Acoustic Guitar Songs EVERYONE Should Know How to Play!", url="plugin://plugin.video.youtube/kodion/search/query/?q=cdkCB6czek8", folder=False)
    Add_Dir(
        name="How To Learn Songs By Ear On Guitar", url="plugin://plugin.video.youtube/kodion/search/query/?q=B6T1nMvMy4k", folder=False)
    Add_Dir(
        name="Instantly SOLO In ANY KEY Over Your ENTIRE Fretboard", url="plugin://plugin.video.youtube/kodion/search/query/?q=jCXyfkfubjM", folder=False)
    Add_Dir(
        name="The Shadows - Instrumental Show", url="plugin://plugin.video.youtube/kodion/search/query/?q=l9bEpib1roE", folder=False)
    Add_Dir(
        name="NEXG - world’s first SMART AUDIO GUITA", url="plugin://plugin.video.youtube/kodion/search/query/?q=ccDQx95Hzv4", folder=False)
    Add_Dir(
        name="NUX Stageman II - The Acoustic Guitar Amp with ENDLESS Features", url="plugin://plugin.video.youtube/kodion/search/query/?q=lofupyKpZdo", folder=False)
    Add_Dir(
        name="NUX Mighty Air Wireless Guitar & Bass Practice Amplifier", url="plugin://plugin.video.youtube/kodion/search/query/?q=HBAucSZspek", folder=False)
    Add_Dir(
        name="NUX AC-80 Stageman II 開箱", url="plugin://plugin.video.youtube/kodion/search/query/?q=Pxr0DbhNY6A", folder=False)
    Add_Dir(
        name="號稱中國的Taylor！！Kepma A1-GA、B1-GA 全單板吉他開箱分享!", url="plugin://plugin.video.youtube/kodion/search/query/?q=owd8TXzaKlw", folder=False)
    Add_Dir(
        name="《摇滚卡农》（带谱分析）", url="plugin://plugin.video.youtube/kodion/search/query/?q=KWyFT99QJhs", folder=False)
    Add_Dir(
        name="The producer of ", url="plugin://plugin.video.youtube/kodion/search/query/?q=nNnSLScmyCs", folder=False)
    Add_Dir(
        name="优化琴枕高度", url="plugin://plugin.video.youtube/kodion/search/query/?q=HoLCaUCpkE4", folder=False)
    Add_Dir(
        name="How to start playing piano or keyboard", url="plugin://plugin.video.youtube/kodion/search/query/?q=a_kVafB-0C4", folder=False)
    Add_Dir(
        name="The Most Overplayed Piano Songs Part1", url="plugin://plugin.video.youtube/kodion/search/query/?q=oRKRewJlyuk", folder=False)
    Add_Dir(
        name="The Most Overplayed Piano Songs Part2", url="plugin://plugin.video.youtube/kodion/search/query/?q=ooG62I7mvTs", folder=False)
    Add_Dir(
        name="The Most Overplayed Piano Songs Part3", url="plugin://plugin.video.youtube/kodion/search/query/?q=MkBDNEb3rHQ", folder=False)
    Add_Dir(
        name="Alan Walker - Faded", url="plugin://plugin.video.youtube/kodion/search/query/?q=iWbKrq-oEJo", folder=False)
    Add_Dir(
        name="3 Easy-Yet-Beautiful Chord Progressions Every Beginner Should Know", url="plugin://plugin.video.youtube/kodion/search/query/?q=7WS_wasGBxA", folder=False)
    Add_Dir(
        name="BEETHOVEN: Für Elise - SUPER SLOW", url="plugin://plugin.video.youtube/kodion/search/query/?q=cadeOFQYnhU", folder=False)
    Add_Dir(
        name="How to Play Canon in D PachelbelPiano Tutorial", url="plugin://plugin.video.youtube/kodion/search/query/?q=xDObxlDeeRk", folder=False)
    Add_Dir(
        name="The Beatles - LET IT BE Piano Lesson", url="plugin://plugin.video.youtube/kodion/search/query/?q=WX5OaMa5kM4", folder=False)
    Add_Dir(
        name="10分钟学会给流行歌曲配和弦、配伴奏！", url="plugin://plugin.video.youtube/kodion/search/query/?q=cLESaZyDKlU", folder=False)
    Add_Dir(
        name="Matching Piano Chords To Melodies", url="plugin://plugin.video.youtube/kodion/search/query/?q=SRSKjJSeVJw", folder=False)
    Add_Dir(
        name="Adding Chords to a Melody on the Piano - Music Composition", url="plugin://plugin.video.youtube/kodion/search/query/?q=cDuA6RcMDw0", folder=False)
    Add_Dir(
        name="4 Best Casio Keyboards for Beginners", url="plugin://plugin.video.youtube/kodion/search/query/?q=n04xkswmMFo", folder=False)
    Add_Dir(
        name="Absolute Beginners Piano Lesson Song 1 'Heart and Soul'", url="plugin://plugin.video.youtube/kodion/search/query/?q=lljsbdifaOs", folder=False)
    Add_Dir(
        name="Simple Easy Piano shred that will amaze and astound!!", url="plugin://plugin.video.youtube/kodion/search/query/?q=NEwK-DgTeyc", folder=False)
    Add_Dir(
        name="3 FAKE piano skills that make BEGINNERS sound like PROS", url="plugin://plugin.video.youtube/kodion/search/query/?q=KjqWuu7vqxU", folder=False)
    Add_Dir(
        name="Easy Piano Improvisation to Impress Your Friends", url="plugin://plugin.video.youtube/kodion/search/query/?q=FCKaf3FVer8", folder=False)
    Add_Dir(
        name="Boogie Woogie Piano: Beginners Easy Tutorial", url="plugin://plugin.video.youtube/kodion/search/query/?q=SIX2-2_ALaQ", folder=False)
    Add_Dir(
        name="5 Classical Pieces Beginners Shouldn't Skip", url="plugin://plugin.video.youtube/kodion/search/query/?q=DfToq0rPZE4", folder=False)
    Add_Dir(
        name="Play with 2 hands on piano (Practice these 10 easy exercise", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="How A Nice Cup of Tea Helped With My Rhythm", url="plugin://plugin.video.youtube/kodion/search/query/?q=WKKScJt-QOs", folder=False)
    Add_Dir(
        name="The PERFECT Piano Practice Morning Routine (For Beginner", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="1 Day Vs 10 Years of Playing Piano", url="plugin://plugin.video.youtube/kodion/search/query/?q=SxGuFZS6dzI", folder=False)
    Add_Dir(
        name="大提琴的「聖經」!? 巴哈的無伴奏組曲為什麼經典?", url="plugin://plugin.video.youtube/kodion/search/query/?q=jXr04qMtTBA", folder=False)
    Add_Dir(
        name="This guitar is worth $275,000", url="plugin://plugin.video.youtube/kodion/search/query/?q=fixMWe-O5u4", folder=False)
    Add_Dir(
        name="Every Guitar Technique in One Solo", url="plugin://plugin.video.youtube/kodion/search/query/?q=0lPXiIvCXZM", folder=False)
    Add_Dir(
        name="How To INSTANTLY Solo In Any Key", url="plugin://plugin.video.youtube/kodion/search/query/?q=tC-Ne_IriNc&t=1232s", folder=False)
    Add_Dir(
        name="Two ICONIC Guitar Riffs Are Actually.... CHORDS? Guitar Riff Lesson", url="plugin://plugin.video.youtube/kodion/search/query/?q=oWEG63qHETc", folder=False)
    Add_Dir(
        name="Teaching My Girlfriend How To SLAP BASS", url="plugin://plugin.video.youtube/kodion/search/query/?q=a70dbulRjx0", folder=False)
    Add_Dir(
        name="HOW TO SLAP BASS (beginner, intermediate and BOSS leve", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="INTRO TO SLAP BASS | How to Play SLAP BASS for Beginners", url="plugin://plugin.video.youtube/kodion/search/query/?q=0AbtEDBgBY0", folder=False)
    Add_Dir(
        name="INTRO TO SLAP BASS | Exercise 5, 6, 7, 8", url="plugin://plugin.video.youtube/kodion/search/query/?q=sEb4IvXZ4zs", folder=False)
    Add_Dir(
        name="Guitar Solo In 5 Minutes", url="plugin://plugin.video.youtube/kodion/search/query/?q=KorP9lq1voU", folder=False)
    Add_Dir(
        name="How to play hundreds of easy acoustic guitar songs", url="plugin://plugin.video.youtube/kodion/search/query/?q=Uy7juNXHnjk", folder=False)
    Add_Dir(
        name="Acoustic Guitar - EPIC RIFFS | Why does this sound so AWEsome", url="plugin://plugin.video.youtube/kodion/search/query/?q=sVckD28ZxZg", folder=False)
    Add_Dir(
        name="Play Jazz with Just Six Chords - Gateway to Jazz Guitar", url="plugin://plugin.video.youtube/kodion/search/query/?q=yIC2BjE2rDo", folder=False)
    Add_Dir(
        name="The Most Important Scale Exercise In Jazz", url="plugin://plugin.video.youtube/kodion/search/query/?q=2Ze22BNftAA", folder=False)
    Add_Dir(
        name="Drum lesson - How to twirl a drum stick!", url="plugin://plugin.video.youtube/kodion/search/query/?q=y19L8b_cHV8", folder=False)
    Add_Dir(
        name="12 Major Scales and Easy Drum Beats Exercise", url="plugin://plugin.video.youtube/kodion/search/query/?q=U67oZvRJHfY", folder=False)
    Add_Dir(
        name="drummer at the wrong gig", url="plugin://plugin.video.youtube/kodion/search/query/?q=GdcbF_vzK9g", folder=False)
    Add_Dir(
        name="Why is Stairway to Heaven BANNED in Guitar Stores?", url="plugin://plugin.video.youtube/kodion/search/query/?q=QsRqC0kOywI", folder=False)
    Add_Dir(
        name="Ringo Starr Reveals The Secret Of His Distinctive Rhythm", url="plugin://plugin.video.youtube/kodion/search/query/?q=98_gMcma9hY", folder=False)
    Add_Dir(
        name="Ringo Starr Shows How to play Ticket to Ride, Come Together and Back off Boogaloo", url="plugin://plugin.video.youtube/kodion/search/query/?q=vl9188EPdLI", folder=False)
    Add_Dir(
        name="Super Fun Acoustic Guitar song by the Beatles... Plus a triad intro", url="plugin://plugin.video.youtube/kodion/search/query/?q=VRxw1F0oySs", folder=False)
    Add_Dir(
        name="All My Loving Acoustic Guitar Lesson with STRUMMING PATTERNS", url="plugin://plugin.video.youtube/kodion/search/query/?q=CE8h9Q2_7rI", folder=False)
    Add_Dir(
        name="大排档歌手", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="在电梯里唱歌", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="愛唱歌的騾子", url="plugin://plugin.video.youtube/kodion/search/query/?q=  #action=", folder=False)
    Add_Dir(
        name="postmoderndisco - with Esther Khew", url="plugin://plugin.video.youtube/kodion/search/query/?q=kshap22FcLo", folder=False)
    Add_Dir(
        name="Acoustic Guitar Mass Production Process", url="plugin://plugin.video.youtube/kodion/search/query/?q=0JSnvUaBUTc", folder=False)
    Add_Dir(
        name="Process Of Making Acoustic Guitar. South Korean Instrument Master", url="plugin://plugin.video.youtube/kodion/search/query/?q=e_lRqTsSPkc", folder=False)

#xbmcplugin.endOfDirectory(plugin_handle)
    
#==========================================================================================================
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r

#====================================================

params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===== YOUTUBE VIDEO =====


if mode==50:
    時政熱點()
    
elif mode==51:
    新聞及娛樂() 

elif mode==52:
    飲食頻道()
    
elif mode==53:
    Miscellaneous()
    
elif mode==54:
    Languages()

elif mode==55:
    ElectronicRepair()

elif mode==56:
    Music()
                
elif mode==None:
    Main()
        
xbmcplugin.endOfDirectory(plugin_handle)
