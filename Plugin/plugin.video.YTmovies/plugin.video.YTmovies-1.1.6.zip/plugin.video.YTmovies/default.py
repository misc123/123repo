﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT Movies
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTmovies'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


# Entry point
def run():
    plugintools.log("YTmovies.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTmovies.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="腾讯视频 - 华语经典剧场",
        url="plugin://plugin.video.youtube/channel/UC3PKcYXUAhao3p4kuNS4_9w/playlists/",
        thumbnail="https://yt3.ggpht.com/15IbaBAT5v4-H8ByIrdMUAD6ydUNe1GXVeKO7x9CjCjKnks4BCwlPtJpv7K60tithezo3Rsjuw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="优优独播剧场",
        url="plugin://plugin.video.youtube/channel/UCteBLoijWzlVFSR5BBtS_2Q/playlists/",
        thumbnail="https://yt3.ggpht.com/S4FHybeAASgDFb3qrCOoSMKVyCkvavdbqGNa2uaLjF8Cesqbz4M5X_tJH-mgqQv0ZljqfZCU-g=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="劇好看",
        url="plugin://plugin.video.youtube/channel/UCdOun-snJIWclxwjmUG7u_A/playlists/",
        thumbnail="https://yt3.ggpht.com/PqAo4x99rVhegcwBAuU5kP8jheixdrRrWIuTs73tW-9ABYCE6gp7O1zI3Z8jLQrHCFyvkw47=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="华策影视",
        url="plugin://plugin.video.youtube/channel/UCAMrnDQlsPnrScHun5PgrXw/playlists/",
        thumbnail="https://yt3.ggpht.com/PVRM0xCXzomgf7x3Y1mTM28-iKDojt6rZZnptnd5AZr_nSDh-sDD9X6Ixwb4b7JWOFVNqbmFtA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="捷成華視—經典劇",
        url="plugin://plugin.video.youtube/channel/UC4BVFK_Vs5BzvZxL2JLI1Jw/playlists/",
        thumbnail="https://yt3.ggpht.com/bg137I1yyY6OmqZAqMeh7uYdhTc5VozDdvCpGJgt89-cgTXXnwm3qTwkZQvndNpGAufrdBXQpA=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="经典热播剧场",
        url="plugin://plugin.video.youtube/channel/UCGZgY9urf-stkr7cRUbQI1Q/playlists/",
        thumbnail="https://yt3.ggpht.com/Q3JqcdjUAjJfBSzzd6LhPo6jiTBAsmWKpiF2YVeokqc6T7HwfG9VGdOk7RMOJF7nfHr2cKH5m_E=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="甜宠追剧社",
        url="plugin://plugin.video.youtube/channel/UCdpka2ZttvQsOpUgPlTEkag/playlists/",
        thumbnail="https://yt3.ggpht.com/ytc/AMLnZu8-iYOnKDWeM1-7PnCFpzHJkPXgdcwHTeg-VQM=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="出色中国电视剧",
        url="plugin://plugin.video.youtube/channel/UC1WPfASy_zV0jj7PlafgELg/playlists/",
        thumbnail="https://yt3.ggpht.com/ytc/AMLnZu-jNn1dhyC2VvpgrVqg2UOSfUClWuD8MX_9F5ot=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="China Zone 剧乐部",
        url="plugin://plugin.video.youtube/channel/UC0jYsshDZfOBZC9nIJn94Cg/playlists/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTa9hWJPYFBxHIxqYny3_iHAUC9QO3mI3YmoBVtxw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Caravan中文剧场",
        url="plugin://plugin.video.youtube/channel/UC5-YbNL-MUy1_tC9KSkEShw/playlists/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLRge170h9wXXQH9PcZoN-S5kNCNuMlJyyJusEMd=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="經典熱播劇場",
        url="plugin://plugin.video.youtube/channel/UCGZgY9urf-stkr7cRUbQI1Q/playlists/",
        thumbnail="https://yt3.ggpht.com/Q3JqcdjUAjJfBSzzd6LhPo6jiTBAsmWKpiF2YVeokqc6T7HwfG9VGdOk7RMOJF7nfHr2cKH5m_E=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="精品電視頻道",
        url="plugin://plugin.video.youtube/channel/UCbOmEx8EeQ4PZpfRXHt-xJQ/playlists/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLRauaL4g0SBQHG-VOHJsRy6uPbQcaeLZL4cfQFk4A=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="華劇場精選",
        url="plugin://plugin.video.youtube/channel/UCCxMNXfmWlukwNRRxPO-P9A/playlists/",
        thumbnail="https://yt3.ggpht.com/WsysYOr7Z9AnIVi_sOBfH3i6D8DF76DUQJ_NT3lvucFfnZqsGIE_AlikDWoN8AcQVItiznZd=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="網劇獨播",
        url="plugin://plugin.video.youtube/channel/UCixrmTfMM_YjeDHtXXcsg4w/playlists/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTrWkIzoE9RuQQ8XPv8T-Hi4M8EgV7C4VITsAgG=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="出色中国电视剧",
        url="plugin://plugin.video.youtube/channel/UC1WPfASy_zV0jj7PlafgELg/playlists/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLQoQjMKUal6_4D3VYmCw42acWvK6LSfxz5_SORS=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Alex Cheng",
        url="plugin://plugin.video.youtube/channel/UC1pThebWi1K86SOd9o-wewQ/playlists/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLQkaO1FOTVoaF_sB8hGYaW_2TreYB0PsgLjI1cr=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="乐视视频官方频道",
        url="plugin://plugin.video.youtube/channel/UCUuZe7OB0yHSYAfu8annGKQ/playlists/",
        thumbnail="https://yt3.ggpht.com/5oYw3Ie3p9XEtRrUNCFRJF2XNdvx_mm5IHpJ_RSvL8Ap602J60Xzm-MmLjON6jzWsRYvS36uijk=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="中剧独播",
        url="plugin://plugin.video.youtube/channel/UCAqDX_XjLlvhjY0eDqHpVQw/playlists/",
        thumbnail="https://yt3.ggpht.com/LajZNdYp96Du0xfboFsK9MbvalTcFjY61BaSBvSbntGviJfHRYA1lFtY8Nr5bIHMALhEyYOTTw=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="大劇獨播",
        url="plugin://plugin.video.youtube/channel/UCNORTw_uosRNGgdEjwdHvuw/playlists/",
        thumbnail="https://yt3.ggpht.com/-ONpJ-FuL14Y/AAAAAAAAAAI/AAAAAAAAAAA/ja4pf5PLQPc/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="大劇獨播Plus",
        url="plugin://plugin.video.youtube/channel/UCC5TlXzHiGi5L5KPbybIJrw/playlists/",
        thumbnail="https://yt3.ggpht.com/-dilMxQaE7sc/AAAAAAAAAAI/AAAAAAAAAAA/dPAtljTdAKY/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="特工皇妃楚乔传",
        url="plugin://plugin.video.youtube/channel/UCtwHZjbJlnvPO_FdJ8nyNjg/playlists/",
        thumbnail="https://yt3.ggpht.com/-0V7dyPn9KxU/AAAAAAAAAAI/AAAAAAAAAAA/aVIw2x8rf9I/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="NewTV偶像剧场",
        url="plugin://plugin.video.youtube/channel/UCSTsji9cUBBD6SOfw2fh5KA/playlists/",
        thumbnail="https://yt3.ggpht.com/-pqQfvAD7q-0/AAAAAAAAAAI/AAAAAAAAAAA/v9OI464JRKk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="NewTV热播剧场",
        url="plugin://plugin.video.youtube/channel/UCKn4SloJmZYNYNq6RgzgrHw/playlists/",
        thumbnail="https://yt3.ggpht.com/-3I2MApIMLHM/AAAAAAAAAAI/AAAAAAAAAAA/4vVxqjO5FZ4/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="香港经典電影粵語",
        url="plugin://plugin.video.youtube/channel/UCMChq4sDciMlSWyD6ZRLBbg/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTRcEKgeI3eYAi3__XeVPhup2luUVbJh7IN2Auo=s176-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="周星驰电影",
        url="plugin://plugin.video.youtube/playlist/PLQpuAoYiMfLqjecowgK9rfsMG4qihx4GE/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLRtNifww5Wan1xMrauY9bcY-JI5alD7HjEIdg=s88-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="周星驰电影 粤语版",
        url="plugin://plugin.video.youtube/playlist/PLOfODbUDgknVEkAt964AnH0ac31sUYtRI/",
        thumbnail="https://yt3.ggpht.com/ytc/AKedOLTTAjBOAtQjGmsBu2FUU21vIyJ4k7oMNk62kkS8DA=s88-c-k-c0x00ffffff-no-rj",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="粵語電影1",
        url="plugin://plugin.video.youtube/channel/UCuKO160G7i-F4DNLHluzxAQ/playlists/",
        thumbnail="https://yt3.ggpht.com/-JnpfGgbZmVk/AAAAAAAAAAI/AAAAAAAAAAA/dstjUg4IoVs/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="粵語電影2",
        url="plugin://plugin.video.youtube/search/?q=hong%20kong%20movies%20cantonese/",
        thumbnail="https://upload.wikimedia.org/wikipedia/zh/thumb/f/fe/My_Lucky_Stars.jpg/220px-My_Lucky_Stars.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="韓國電影1",
        url="plugin://plugin.video.youtube/channel/UCE-Az3DaIYjP9lqxSmQJUCw/playlist/PLx6zdlARSHzb7F26GQaDfvKHa7wiRW_VB/",
        thumbnail="https://upload.wikimedia.org/wikipedia/commons/1/13/KoreaSfilm.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="韓國電影2",
        url="plugin://plugin.video.youtube/search/?q=korean%20movies%20chinese%20subtitles/",
        thumbnail="http://www.hancinema.net/images/logo_hancinema_pure.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="日本電影",
        url="plugin://plugin.video.youtube/search/?q=japanese%20movies%20subtitles/",
        thumbnail="https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Japan_film_icon.svg/80px-Japan_film_icon.svg.png",
        folder=True )

run()