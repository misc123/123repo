﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT Food
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTfood'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


# Entry point
def run():
    plugintools.log("YTfood.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()
   
# Main menu
def main_list(params):
    plugintools.log("YTfood.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="張媽媽廚房",
        url="plugin://plugin.video.youtube/user/mamacheung/",
        thumbnail="https://yt3.ggpht.com/-wuwa4F3RyBE/AAAAAAAAAAI/AAAAAAAAAAA/Yugf9xG3bMc/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item(
        #action="", 
        title="田园时光",
        url="plugin://plugin.video.youtube/channel/UCEkG-qWrskKVdawEFA99koA/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyaEmzF6KHsoHErDYOX1kQAlKk4hObwx_uRmw=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="寶寶滋味館",
        url="plugin://plugin.video.youtube/channel/UCCrXv19nZEi95F0UZ-LyXDg/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mCZyNXpLJJ7qFs4R4-HGbbd52ht039dhVtgvA=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item(
        #action="", 
        title="越煮越好",
        url="plugin://plugin.video.youtube/channel/UCDfTo6oLw_ZcVfepgTgD_Kg/",
        thumbnail="https://yt3.ggpht.com/-y81UYUbzl6k/AAAAAAAAAAI/AAAAAAAAAAA/tTEP3Td-bsE/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )

    plugintools.add_item(
        #action="", 
        title="明聰",
        url="plugin://plugin.video.youtube/channel/UCZ3X7wpqu7aKdgDCpyQgDyw/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJwGfv94DsXVuP2gwG3n3Thf75JRpc65YghDCw=s100-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item(
        #action="", 
        title="疫境廚神",
        url="plugin://plugin.video.youtube/playlist/PL6xnAvlFTCA2ibLkS3Uih6mm_2R2mwPHZ/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJyrcChFpzJm3kpa_inzd0JZARIi_MLD-iiOcQ=s88-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item(
        #action="", 
        title="點 Cook Guide",
        url="plugin://plugin.video.youtube/user/dimcookguide/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mDsd7YaWCAZMRgOmdm0EqQ0rH2sYkhR09UFGg=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item(
        #action="", 
        title="Jing Sang's Kitchen",
        url="plugin://plugin.video.youtube/channel/UCSfcTjOJPBWZvGZe4JV2KDw/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJy38vPRESpI1fqxEFU9Iy-GQoAogzQ-dmr_xw=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item(
        #action="", 
        title="李晨曦",
        url="plugin://plugin.video.youtube/channel/UCE2fFvG2dwKWE3VyD4bkOZQ/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mDrGXfXBZg4OYk_4KdUgZx0NuTr4oh7lEwUow=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )
		
    plugintools.add_item(
        #action="", 
        title="米太廚房手記",
        url="plugin://plugin.video.youtube/channel/UCcMOC9SMClz663otoRQdObQ/",
        thumbnail="https://yt3.ggpht.com/-yXmurm9KMPw/AAAAAAAAAAI/AAAAAAAAAAA/wYFwQJwT4kE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="日日煮",
        url="plugin://plugin.video.youtube/channel/UCYDVigTy-NE2KyCqVCiJb_Q/",
        thumbnail="https://yt3.ggpht.com/-bccB1jY_CJo/AAAAAAAAAAI/AAAAAAAAAAA/gLoRzxLDN0k/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="飲食男女",
        url="plugin://plugin.video.youtube/search/?q=%e9%a3%b2%e9%a3%9f%e7%94%b7%e5%a5%b3/",
        thumbnail="https://yt3.ggpht.com/-UTIHiP9Qp00/AAAAAAAAAAI/AAAAAAAAAAA/a3-HMfQ28wY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="入廚秘技",
        url="plugin://plugin.video.youtube/channel/UCeqUUXaM75wrK5Aalo6UorQ/playlist/PLQcmGU2t4gsp9DBQlqPWjhUy3kr-OwoM-/",
        thumbnail="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="港飲港食",
        url="plugin://plugin.video.youtube/channel/UCeqUUXaM75wrK5Aalo6UorQ/playlist/PLQcmGU2t4gsphUkfAHyO-jPkR5dbR_1Nt/",
        thumbnail="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="飲食籽",
        url="plugin://plugin.video.youtube/playlist/PLBtDO8vnUizoFs2546t1DhockqKoC0i1T/",
        thumbnail="https://yt3.ggpht.com/-qADe85YpptY/AAAAAAAAAAI/AAAAAAAAAAA/czgngNBS3FI/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        		
    plugintools.add_item( 
        #action="", 
        title="真英雄素食",
        url="plugin://plugin.video.youtube/channel/UCryUWjfZLd3Q_aiq677kuGA/",
        thumbnail="http://www.realherokitchen.com.hk/online_lesson_youtube/realherokitchen.gif",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wantanmien",
        url="plugin://plugin.video.youtube/channel/UCsy5tUhFYchN8BFdXJtECRQ/",
        thumbnail="https://yt3.ggpht.com/-mboGmDJr-c4/AAAAAAAAAAI/AAAAAAAAAAA/gtR0e3mpOQM/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Cooking With May Lynn",
        url="plugin://plugin.video.youtube/channel/UCAXO1tbQzZ5kOUg3BVl0eYw/",
        thumbnail="https://yt3.ggpht.com/-8efBzKvUTuU/AAAAAAAAAAI/AAAAAAAAAAA/2P-lSNWHqOI/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Helen's Recipes-Vietnamese",
        url="plugin://plugin.video.youtube/channel/UCMmZEL8jV1B61NKAXcyW87A/",
        thumbnail="https://yt3.ggpht.com/-lXWCk1JjtDQ/AAAAAAAAAAI/AAAAAAAAAAA/WimPbqGFPHw/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="CookingWithDog-Japanese w/sub",
        url="plugin://plugin.video.youtube/channel/UCpprBWvibvmOlI8yJOEAAjA",
        thumbnail="https://yt3.ggpht.com/-SixK-U1jMsg/AAAAAAAAAAI/AAAAAAAAAAA/n76jU-5KaTk/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Maangchi-Korean",
        url="plugin://plugin.video.youtube/channel/UC8gFadPgK2r1ndqLI04Xvvw/",
        thumbnail="https://yt3.ggpht.com/-d0KStw-ZOOM/AAAAAAAAAAI/AAAAAAAAAAA/0Im0I-Sr9cg/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Food Wishes",
        url="plugin://plugin.video.youtube/channel/UCRIZtPl9nb9RiXc9btSTQNw/",
        thumbnail="https://i1.ytimg.com/sh/M0InoNcVcRA/showposter.jpg?v=508859c4",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="How to Make yummy",
        url="plugin://plugin.video.youtube/channel/UCECA8Jct_FI6l2tIBLuK7QA/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mBJ-yJRDVb8aeE-ZQPnFoNbylYCYY77ZpNCvQ=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Josephine's Recipes",
        url="plugin://plugin.video.youtube/user/Everydaypossible/",
        thumbnail="https://yt3.ggpht.com/a-/AAuE7mDf8GRm90gl3axHcLYpGxyIPbcMoJ0NlyWDkg=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Nickos Kitchen-Bakery",
        url="plugin://plugin.video.youtube/channel/UCffs63OaN2nh-6StR6hzfiQ/",
        thumbnail="https://yt3.ggpht.com/-R-PA4kxVgkE/AAAAAAAAAAI/AAAAAAAAAAA/JOEZ7x59uWE/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="BBQ Pit Boys",
        url="plugin://plugin.video.youtube/channel/UCjrL1ugI6xGqQ7VEyV6aRAg/",
        thumbnail="https://yt3.ggpht.com/-w5MgnW1qxCw/AAAAAAAAAAI/AAAAAAAAAAA/ywS4ukZBIaM/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
run()