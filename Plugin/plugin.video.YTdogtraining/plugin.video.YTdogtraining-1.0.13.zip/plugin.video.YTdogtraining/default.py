﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT Dog Training
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTdogtraining'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


# Entry point
def run():
    plugintools.log("YTdogtraining.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()
   
# Main menu
def main_list(params):
    plugintools.log("YTdogtraining.main_list "+repr(params))

plugintools.add_item(
    #action="",
    title="練狗術師",
    url="plugin://plugin.video.youtube/channel/UC_q7e5XYJB0JDGagcF0KW0w/playlist/PLIpRvnEkgEeWx1PCIxB-1N8hIK06M_EQZ/",
    thumbnail="",
    folder=True )

plugintools.add_item(
    #action="",
    title="寵物狗救星",
    url="plugin://plugin.video.youtube/channel/UCws0PUT-Au3dDo07u9yRhsA/playlist/PLybVnI8RtkqI6DfjSrm1GYJ6gvwu8QmOp/",
    thumbnail="",
    folder=True )	

plugintools.add_item(
    #action="",
    title="寵物ER",
    url="plugin://plugin.video.youtube/channel/UCws0PUT-Au3dDo07u9yRhsA/playlist/PLybVnI8RtkqLYqK0DSPpyszXXitB4jT5N/",
    thumbnail="",
    folder=True )	

plugintools.add_item(
    #action="",
    title="Cesar's Millan Recruit : Asia Season 2 Semi Final",
    url="plugin://plugin.video.youtube/play/?video_id=Uv92IKLuL2Y",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="Cesar's Millan Recruit : Asia Season 2 FINALE",
    url="plugin://plugin.video.youtube/play/?video_id=Ss-A6LHOjec",
    thumbnail="",
    folder=False )	
	
run()