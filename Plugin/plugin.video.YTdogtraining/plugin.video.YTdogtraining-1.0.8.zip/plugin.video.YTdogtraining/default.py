﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT Dog Training
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTdogtraining'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


# Entry point
def run():
    plugintools.log("YTdogtraining.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()
   
# Main menu
def main_list(params):
    plugintools.log("YTdogtraining.main_list "+repr(params))

plugintools.add_item(
    #action="",
    title="練狗術師1 第一集",
    url="plugin://plugin.video.youtube/play/?video_id=uk3TIym3k5c&t",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="練狗術師1 第二集",
    url="plugin://plugin.video.youtube/play/?video_id=AEUqMU3PRSg",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="練狗術師1 第三集",
    url="plugin://plugin.video.youtube/play/?video_id=2MABFgLf_Xc",
    thumbnail="",
    folder=False )
	
plugintools.add_item(
    #action="",
    title="練狗術師1 第四集",
    url="plugin://plugin.video.youtube/play/?video_id=H-dRvJqYII4",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="練狗術師1 第五集",
    url="plugin://plugin.video.youtube/play/?video_id=Zldg6F6gq_s",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="練狗術師1 第六集",
    url="plugin://plugin.video.youtube/play/?video_id=PhzLCE97yrQ",
    thumbnail="",
    folder=False )
	
plugintools.add_item(
    #action="",
    title="練狗術師1 第七集",
    url="plugin://plugin.video.youtube/play/?video_id=jgBhgg0DOGY",
    thumbnail="",
    folder=False )	
	
plugintools.add_item(
    #action="",
    title="練狗術師1 第八集",
    url="plugin://plugin.video.youtube/play/?video_id=CoUXSjqBSDs",
    thumbnail="",
    folder=False )	
	
plugintools.add_item(
    #action="",
    title="練狗術師2 第一集",
    url="plugin://plugin.video.youtube/play/?video_id=0qkXZ1qydbc",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="練狗術師2 第二集",
    url="plugin://plugin.video.youtube/play/?video_id=ku5XrpHXU_A",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="練狗術師2 第三集",
    url="plugin://plugin.video.youtube/play/?video_id=aum1RytC--8",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="練狗術師2 第四集",
    url="plugin://plugin.video.youtube/play/?video_id=NN71OBFvB08",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="練狗術師2 第五集",
    url="plugin://plugin.video.youtube/play/?video_id=UFsIG9-SzZc",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="練狗術師2 第六集",
    url="plugin://plugin.video.youtube/play/?video_id=oWdjETG6HyY",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="練狗術師2 第七集",
    url="plugin://plugin.video.youtube/play/?video_id=A2qSkM_zqr0",
    thumbnail="",
    folder=False )
		
plugintools.add_item(
    #action="",
    title="寵物狗救星 第一集",
    url="plugin://plugin.video.youtube/play/?video_id=GMhl4FYg8uU",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="寵物狗救星 第二集",
    url="plugin://plugin.video.youtube/play/?video_id=2avyNFviZSc",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",,
    title="寵物狗救星 第三集",
    url="plugin://plugin.video.youtube/play/?video_id=uFOFr5ubl1Y",
    thumbnail="",
    folder=False )

plugintools.add_item(
    #action="",
    title="寵物狗救星 第四集",
    url="plugin://plugin.video.youtube/play/?video_id=i_MSBgqc22k",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="寵物狗救星 第五集",
    url="plugin://plugin.video.youtube/play/?video_id=qrikhyzmZW8",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="寵物狗救星 第六集",
    url="plugin://plugin.video.youtube/play/?video_id=mfLM1ALIO-U",
    thumbnail="",
    folder=False )	
	
plugintools.add_item(
    #action="",
    title="寵物狗救星 第七集",
    url="plugin://plugin.video.youtube/play/?video_id=2VF4MsY-k50",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="寵物狗救星 第八集",
    url="plugin://plugin.video.youtube/play/?video_id=QpPjVaq88WI",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="Cesar's Millan Recruit : Asia Season 2 Semi Final",
    url="plugin://plugin.video.youtube/play/?video_id=Uv92IKLuL2Y",
    thumbnail="",
    folder=False )	

plugintools.add_item(
    #action="",
    title="Cesar's Millan Recruit : Asia Season 2 FINALE",
    url="plugin://plugin.video.youtube/play/?video_id=Ss-A6LHOjec",
    thumbnail="",
    folder=False )	
	
run()